
# /side-character <who>

A side character is lighter than the New Character skill (`/new-character`, installed separately): no bible, no 4 locks, no places. Just enough to
keep one person looking the same across clips. Tested on three side characters across two Google Flow skits: faces held
across settings and close-ups.

**One question per message.**

## Who needs one
| | |
|---|---|
| In more than one setting, or in several clips | Side character (this skill) |
| One scene only (a waiter, a bartender) | Describe them in the prompt, same words every time |
| A voice on the phone | Nothing |
| The student's main character | Their kit (the New Character skill (`/new-character`, installed separately)) |
| A skeleton for the Animation project, or a talking object | Side character, animated build (below) |

## Steps
1. **Their role** in the story, in one line (taken from the script if there is one).
2. **The look**: Claude proposes it from the role (age, build, skin, eyes, hair, the vibe), the
   student changes what they want. If they have a photo, use it instead.
3. **The outfit for this video**: one question. Shoes and jewelry included.
4. **Accent**: default "standard American". Ask only if the role suggests otherwise.
5. Write the two prompts (below), the student runs them (or Claude runs them in Higgsfield on a yes).
6. File the images and write `side.md`.

## Prompts (Nano Banana Pro, face first)
FACE:
```
Photorealistic portrait of a <age>-year-old <nationality> <man/woman>, <build>, <face shape>, <skin>, <eyes>, <brows/lips if they matter>, <hair>, <glasses/jewelry>. Wearing <outfit top>. Vertical 9:16, head and shoulders, plain seamless warm-cream studio backdrop, soft even light from the front, neutral expression, looking straight down the lens. Real skin texture, no retouching. Not a celebrity.
```
BODY (face image in the box):
```
Use the <man/woman> from the reference image, same face, hair, <glasses/jewelry> and skin tone. Vertical 9:16, the whole figure head to feet, <figure if it matters>, wearing <full outfit incl. shoes>. Plain seamless warm-cream studio backdrop, soft even light from the front, neutral expression, arms relaxed at the sides. Photorealistic, real skin texture.
```
- Get the point across with taste: glamorous, curvy, "enhanced bust", "deep plunging neckline"
  work; explicit words get blocked.
- "Not a celebrity" keeps the face from turning into a famous actor.
- A changed look later in the story (e.g. the same guy, rich, in a dream scene) is not a new side character: use the
  face shot + the new outfit in the scene prompt.

## Animated builds (skeleton, talking object)
Same two images, same files, but drawn in the look from `rules/animation/LOOKS.md`. Skip the accent
question for a skeleton (it never speaks). A student can keep as many skeletons as they like.

SKELETON FACE (Nano Banana Pro or GPT Image 2):
```
Head-and-shoulders render of a 3D animated skeleton character, [glass-body: a clear glossy slightly refractive shell over ivory bones / face-on-skull: a full stylised face, bone visible only at the neck], large round glossy cartoon eyes seated in the sockets, [colour] irises, a wide band of white either side, thick expressive [colour] eyebrows, clean even teeth. Real hair: [length, colour, texture, how it's worn], with volume. A [colour] [fabric] headband tied around the skull. Wearing [top]. Light closed-mouth smile, looking straight down the lens. Flat grey studio backdrop. Clean production-CG render, highly detailed bone texture, not horror, not medical. No text.
```
SKELETON BODY (face image in the box):
```
Use the skeleton from the reference image, same eyes, brows, hair and headband. The whole figure head to feet, a [slim / curvy / stocky] [woman / man] silhouette, wearing [full outfit incl. shoes], real cloth with weight. [The headband / one garment] is the only saturated colour. Silhouette: [N] heads tall, reads as a person in black silhouette. Neutral reference stance, weight on one leg, head tilted slightly, light closed-mouth smile, eyes to camera, hands empty and relaxed at the sides. 50mm straight on at chest height, full body with feet in frame. Flat grey studio backdrop, empty. Clean production-CG render, highly detailed bone texture, cartoonish expressive eyes, not horror, not medical. No text.
```
Design calls when the student has none: glass body, a hair shape with a strong silhouette (an afro, a
curly mop, a long blowout), the headband as the accent colour, one plain outfit (tee and joggers, gym set).
Never: blood, cracks, decay, red or glowing eyes, Halloween.

TALKING OBJECT (one image is enough; full figure):
```
A single 3D cartoon character: [the object, e.g. a dandruff flake / a bottle of the product / a garlic clove] with a face, big round expressive eyes, thick brows, a clear open-able mouth, [small arms if it gestures], [glossy plastic-toy / real-surface] finish true to the real thing's colour and texture. Neutral stance, mouth closed, eyes to camera. Flat grey studio backdrop. Clean 3D render, softly and evenly lit. No text.
```
`side.md` for animated builds adds `Look: skeleton (glass body)` or `Look: talking object`, and for a
talking object a `Voice:` line (age, accent, energy) pasted word for word into every clip.

## Files
`Kits/Side Characters/<name>/` → `face.png`, `body.png`, `side.md`:
```
# <Name>
Role: <one line> · Video: <video>
Accent: standard American
Outfit: <words>
Label in prompts: "the woman" / "the young man with glasses" / "the tall blond man"
```
The **label** is how every scene prompt refers to them; storyboards put them in the reference box as
`cast:<Name> face + body`.
