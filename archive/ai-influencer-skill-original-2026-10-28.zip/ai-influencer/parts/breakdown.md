
# /breakdown <link | file>

Same method and output as `parts/pull.md` (read `parts/pull.md`
and follow its phase 1, phase 2 and grading steps). Only the intake and the save step differ.

Tools: `tools/vidtools.py`.

## Intake (replaces parts/pull.md step 1)

- **Link:** `vidtools.py fetch-link <url> [name]` → `<name>/source/video.mp4`, then `breakdown.py` cuts it:
  `breakdown/shots.txt` (raw cuts), `shots/`, `contact_sheet.jpg`, and a Whisper transcript with timings
  (`breakdown/audio.srt`, `audio.txt`). About 2 minutes.
- **File:** make `Videos/_work/<name>/source/`, copy the file in as `video.mp4`, write `row.json` as
  `{"link": "<file name>"}`, then `python3 ~/.claude/skills/ai-influencer/scripts/breakdown.py <name>` from `Videos/_work/`.

Then continue at parts/pull.md step 2. `vidtools.py strips <name>` makes one strip per raw cut; there are usually
more cuts than clips, so grouping (step 4) matters more here. Use the .srt timings to place each beat.

## Save (replaces parts/pull.md step 10)

Adding a link to the Video Database happens in the student's own Video Database bot (Discord), not here. Keep the breakdown in the video folder.
3. `vidtools.py upload <name>`: PNGs land in that row's Drive folder under `breakdown/`.
Without that, the PNGs stay in `Videos/_work/<name>/`.
