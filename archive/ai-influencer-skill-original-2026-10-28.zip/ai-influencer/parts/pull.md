
# /pull <row>

Reverse-builds a video that the Video Database bot already processed. The bot did the download,
transcript, scene cuts and first frames; this skill turns that into clips a student can regenerate.

**Read first:** `rules/METHOD.md`. Its rules are
the source of truth and are style + tool specific; follow the ones tagged for the video's style.

Tools: `python3 ~/.claude/skills/ai-influencer/scripts/vidtools.py <cmd>`
Work folder = `Videos/_work/row<N>/`.

## Phase 1 · raw clip map (always image-to-video: one still per clip)

1. `vidtools.py fetch-row <N> [tab]` (tab = the sheet tab named by the student, e.g. `styles full`;
   no tab = Videos). It NEVER re-downloads the video from the platform: it copies the bot's local
   folder when there is one, otherwise the row's zip from Drive (video.mp4, transcript.txt, scenes.txt,
   frames/, storyboard.jpg). Read the bot's storyboard.jpg and scenes.txt first; they are the starting
   point, not a redo. If the row has no folder yet, switch to parts/breakdown.md on its link.
2. **Script first.** Split the transcript into beats (one sentence / one instruction each). Recipes: count
   the ingredients, expect that many clips.
3. `vidtools.py strips row<N>`: one 5-frame strip per DB scene. Read every strip (Read tool) before writing
   Action. One frame is never enough. Use `vidtools.py strip row<N> <a> <b>` for any range you are unsure of.
4. **Group DB scenes into clips** (one clip = one generation = one still animated). Cuts, zooms, punch-ins
   and re-stitches inside a clip are edits, not rows.
   **Hooks:** check the first ~12s at a frame every 0.5s. A before shot and an after shot are separate clips
   (a time-jump line like "this is her four months later" = new clip); count every setup in the hook. Same character, outfit, set, light and prop state +
   only a zoom/crop/trim = same clip. Test + result = one clip.
5. Write `row<N>/clipmap.json` (format in vidtools.py header): per clip time, structure (hook / body / CTA
   + named step), exact dialogue, still (what is on screen), action (physical verb + tool in hand +
   target, the whole clip), frame (seconds for the card image). `label` = "Videos row N · <style> ·
   phase 1", `tool` = what you saw, e.g. "8 clips, edited in CapCut".
6. `vidtools.py render row<N>` → `clip-map.png` + `storyboard.png`. Show both PNGs in chat (Read them)
   plus the clip table as markdown.

## Phase 2 · which tool, then regroup

7. **Format check (free, uses the strips you already read):** if the same talking person sits keyed in a
   corner while the background clips change (and usually goes full frame at the end), say "This looks like a
   green screen video" and offer the Long Form skill (`/long-form`) (it asks Omni or HeyGen next). Only build it on a
   yes. Otherwise, or if they decline, continue:
   Ask with a plain question in the chat: **"Which tool do you want to recreate this in?"** Options: Google Omni (Flow)
   · Seedance 2.5 · Kling · other. Never guess the tool. Say what you think the original was made with and
   why in one line, but the student's pick decides the layout. (Automatic tool rules come later, once
   every format has been torn down.)
8. Regroup for the pick:
   - **Omni / Kling (image-to-video):** keep phase 1 as is.
   - **Seedance:** group clips into scenes, each ≤30s and one generation (set `"scene": "S1"` etc. on each
     clip). A continuous setup with several angles is one scene. Re-render; the storyboard shows scene bands.
   - Anything else: ask how that tool generates (one shot or many per generation), then group.
   Set `label` to "… · phase 2 · <tool>" and re-render.
9. The student checks the table. Every correction they make becomes a rule in METHOD.md, tagged with the style
   and tool it came from. Re-render after fixes.

## Save

10. Once the student is happy: `vidtools.py upload row<N>` puts `breakdown/clip-map.png` and
    `breakdown/storyboard.png` into the row's Drive folder (replaces older ones). It never edits the
    sheet.

## Hand-off

The phase 2 table is the input for the format's make-it skill (one per format, built as each format is
torn down). Name that next step at the end if it exists.
