
# /stitch <clips folder> [script]

(Was stitch; the old name still works. It joins any clips, not only Omni.)


## Steps
1. **Find the clips.** Usually the newest `download (N)/` folder or `hf_*.mp4` files in `~/Downloads`. Copy them into the video's working folder `clips/` (never edit in Downloads).
2. **Script:** write the script the clips were made from to `script.txt` (from the storyboard / prompts). Without it the clips go in filename order.
3. Run:
   ```
   python3 ~/.claude/skills/ai-influencer/scripts/stitch.py <folder>/clips --script <folder>/script.txt --out <folder>/stitched.mp4
   ```
   Flags: `--speed 1.15` (pitch kept) · `--pad 0.3` (seconds kept after the last word).
4. Show the order table it prints. Send the video (SendUserFile if it's available) and drop a copy in `~/Downloads`; say the path.
5. Ask one question: **speed it up?**

## Rules
- **Skits (and any video with action between lines): default = plain join, no trims, no speed-up, no edits** unless the student asks (word-based trims cut skits in the wrong places). Join every clip whole, in story order, with each clip's own audio. In a zsh or bash shell write `${i}` before `:a`/`:v` in ffmpeg filter labels (`$i:a` is a zsh path modifier).
- Cut after each clip's last word. Also cut glitches inside a clip (a doubled word like "Step two, two", a stumble) with a short jump cut. Read every clip's word timings to spot them.
- A clip that repeats its last phrase gets cut after the first copy.
- Voice levelled to -16 LUFS (Omni clips come out at different volumes).
- Voice swap (Higgsfield) happens **after** the stitch and **before** the edit, so the captions are timed to the final voice.
