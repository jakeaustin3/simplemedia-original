
# /script-remix <topic> + <sample>

The small, fast version of scripting. A full scripting system can replace it later; keep this lean.

## Inputs
- **Topic** (required): what the new video is about, and the product if there is one (`Kits/Products/<name>/product.md`).
- **Sample:** a DB row (`vidtools.py fetch-row N` → transcript), a link (`parts/breakdown.md` transcript), pasted text, or a sheet (Drive `read_file_content`; pick the top 3 by outlier score and ask which one, or match the topic).
- **Creator file:** if `creator.txt` in the video folder names one (or `Kits/Creators/<handle>/creator-<handle>.md` exists for the sample's creator), read its **Script templates** first and pick the closest. The template is the sample; a pasted sample is optional then.
- **Character:** kit `bible.md` voice line (accent, how they talk).

## Steps
1. **Skeleton** (show it, 4–8 lines): hook type (step-by-step promise · "X just did Y for me" · contrast/"instead of" · cost flip · myth bust · question) → the beats with their job (promise, proof, step 1..n, payoff) → CTA type.
2. **Ask one question only if needed:** the CTA (follow · comment a word · link in bio). Default: what they said, else "Follow for more".
3. **Write** with the 20% rule:
   - Keep: the hook shape, the beat order, the rhythm (sentence lengths, "Let's go", "Step one:"), the length (±10% words).
   - Change: every noun and claim to the new topic, the tools to ours, the CTA, light flavor of the character's voice.
   - Never copy a line that only makes sense for the original topic. Never invent results or money claims.
4. **Hand off:** split at sentence breaks into ≤30-word Omni clips (or one block for HeyGen), numbers spelled out. Save as `<video folder>parts/script.md.txt`.

## Output
Skeleton → the script (one block) → the clip split. Nothing else.
