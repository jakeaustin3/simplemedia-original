
# Seedance movie

Idea in, Seedance 2.5 prompts out. Nothing is generated here — this writes the prompts and hands
them over, and the person runs them on whatever platform they use.

**Read before writing anything:**
- `references/prompt-layout.md` — the limits, the block order, the shot rules, the banned words,
  and the known-issues table. Read §7 every time; it is the record of what has actually gone wrong.
- `references/formats/<format>.md` — the format chosen in step 0.
- `references/character-lock.md` — before writing any CHARACTER block.
- `references/script-template.md` — the beat form and the word budget, before writing phase 1.
- `references/post-spec.md` — the music, sound, caption and graphics spec handed over at the end.

Three phases: **script → break → prompts.** The break is not optional and not a formality — it is
where the model's hard limits decide the shape of the film, and skipping it is how people waste
money.

---

## 0. Inputs — one ask, then go

Ask for whatever is missing, in one message, then work:

1. **The idea, or the script.** An idea is enough — a sentence describing who gets humiliated and
   what they find out. If a script came through, use it and don't rewrite its voice.
2. **Format.** `movie-drama` (several characters, one to four locations, pain-driven, ends on a
   hook or a CTA) or `movie-two-hander` (two people, one location, twist punchline). If it's
   ambiguous, ask this one question. Nothing else in this list is worth blocking on.
3. **Characters.** Who needs a reference image, and does it exist yet? Anyone without one gets a
   text lock (`references/character-lock.md` §2).
4. **Target length.** Default 30 s. Say what that costs before writing anything.

Propose the setting, the cast and the ending rather than asking. They are easier to react to than
to specify.

## 1. Script

**From an idea:** write it in the format's beat structure. Open on the accusation — no narrator,
no establishing beat, no setup. Every character gets one job. Then list it back for cuts.

**From a script:** keep the words and the character's voice and grammar, including "wrong"
grammar. Fix punctuation and line breaks so it reads as spoken lines. Any change to an actual
**word** gets listed under "What I changed", with the reason. Likely speech-to-text slips get
fixed and flagged.

Either way:
- Contractions always. Numbers as words. No em dashes inside a spoken line.
- **~3 spoken words per second.** A 30 s film is about 90 words. Count them — this is the single
  most common reason a finished clip feels slow.
- Every name or brand goes on the pronunciation list.

**Stop here.** Show the script — dialogue only, no shot lists, no staging — and wait for it to be
approved before going near phase 2. A prompt built on an unapproved script wastes the writer's
time and, if it runs, their money. Phases 2 and 3 do not begin until the words are signed off.

## 1b. Cast — lock every face before any prompt is written

Do this **after the script is approved and before anything else.** Skipping it is the single most
expensive mistake available: a text-locked lead comes back as a famous actor and drifts between
generations, and by the time you can see it you have already paid for every clip.

List every speaking character and sort them:

| | What they need |
|---|---|
| Appears in **more than one generation** | **Image lock — required.** Face reference + body reference. |
| Appears in **one generation only** | Text lock is fine (`references/character-lock.md` §2). |
| Any product the story points at | Image lock — required. |

**If the writer already has references**, take them, confirm the @Image order, and go.

**If they do not**, write two Nano Banana Pro prompts per character and stop until the images
exist. Do not write Seedance prompts against a face that has not been generated and approved.

```
FULL BODY  — vertical 9:16, the whole figure head to feet, plain seamless warm-cream studio
             backdrop, soft even light from the front, neutral expression, arms relaxed at the
             sides, complete wardrobe including shoes and jewelry.
FACE       — vertical 9:16, head and shoulders, same backdrop, same light, same wardrobe at the
             neckline, neutral expression, looking straight down the lens.
```

Rules that make the reference usable:

- **Plain seamless backdrop, always.** A room in the reference leaks into the generated video.
- **Build the body the story needs, in the body reference.** If the premise is physical — a person
  who cannot fit a seat, a person who has lost weight — that has to be visible in the reference,
  because the Seedance prompt cannot argue a body into existence with adjectives (§7).
- Generate, **look at it**, approve it, and only then write the prompts. A reference you have not
  looked at is a text lock with extra steps.
- Once approved, the CHARACTER block describes **what the reference actually shows**, not what was
  asked for.

## 2. Break it into generations

Apply in this order (`references/prompt-layout.md` §2):

1. **Every change of location is a new generation.** Always, no exceptions.
2. Then split on the **30 s cap**, aiming for 15–25 s.
3. Then split on the **4–5 shot ceiling**. More than five shots means two generations, never one
   crowded one.
4. Every clip starts and ends on a **complete line.** Rapid back-and-forth stays in one clip.
5. Anything under ~8 s merges into a neighbour.

Then show the map before writing a single prompt:

| Clip | Location | Covers | Shots | Seconds |
|---|---|---|---|---|

Flag here, not later: any location running past ~25 s spans several generations and **the room
will change between them**. Say so, and give the choice — move the cut, test last-frame chaining,
or rewrite the scene to fit one generation.

## 3. Write the prompts

Follow the block order in `references/prompt-layout.md` §3 exactly. Then:

- **Byte-identical blocks.** Everything except "in this clip" and the SHOTs is pasted in full,
  character for character, in every clip of a scene. CHARACTERS, PRONUNCIATION and AUDIO stay
  identical across the *whole video*, including across locations. Never write "same as clip 1" —
  each generation sees only its own prompt.
- **Shot timings add up** to the clip length, and each shot is timed to its line plus one beat.
- **Hands, eyes and sides of frame spelled out** in every shot.
- **The look preset comes from the location**, not from the video (`formats/movie-drama.md` §6).
  A flat fluorescent shop does not get creamy bokeh.
- Character blocks come verbatim from the locks, with the @Image numbers filled in.

Then check every prompt against §7 before handing it over:

- [ ] 4–5 shots, no more
- [ ] no `or` anywhere in STAGING or in an "in this clip" line
- [ ] nobody who speaks is stacked behind someone else
- [ ] the exit rule is in STAGING if anyone leaves frame
- [ ] no prop is handed between two characters
- [ ] nothing in frame needs to be legibly readable
- [ ] wardrobe allows every action in the shots
- [ ] no banned words (`prompt-layout.md` §5)
- [ ] every attached image is named in the prompt, and nothing else is

## 4. Deliver

TL;DR first. Then, in this order:

1. **The reference table** — `@ImageN | who | face or body` — and the reminder that upload order
   is what matters, not filenames.
2. **Every prompt in full, one code block per clip**, ready to copy. Never a summary, never a
   diff against another clip.
3. **The settings line** for each clip:
   `Settings: Seedance 2.5 · 9:16 · 720p · <N>s · audio ON`
   Audio is ON for any clip with dialogue.
4. **The run table:**

   | Clip | Seconds | Credits |
   |---|---|---|

   720p ≈ 63 credits/s and 480p ≈ 28 credits/s are kie.ai's logged rates. On another platform,
   say which rate was used or ask for it — never invent one.
5. **The one riskiest shot**, named, with what will probably go wrong and what it costs to fix.
   Re-running a single broken shot as its own short clip is almost always cheaper than the clip.
6. **The post spec**, from `references/post-spec.md`, cued to this build's beats: where the music
   enters and where it drops out, the two or three sound accents, the caption style, and any
   graphic that has to be composited. Never just say "add music in CapCut" — say what and where.

For a new format or an expensive build, recommend running **one clip at 480p first**. It is less
than half the price and it catches character drift before it is paid for at full rate.

Nothing runs from this skill. After a generation comes back, add any new failure as a row in
`references/prompt-layout.md` §7 — that table is the reason this works, and it only stays useful
if it keeps growing.
