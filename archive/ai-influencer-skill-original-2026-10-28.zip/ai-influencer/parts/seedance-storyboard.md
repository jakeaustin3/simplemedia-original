
# /seedance-storyboard <row N | folder>

A phase-1 pull treats every clip as its own still + generation (Omni / Kling). Seedance doesn't work like
that: one generation renders the whole run end to end (several shots, angles and the dialogue), from the
character kit as reference images, the setting written out, and the original video as reference for the look.
This skill re-groups the pull for that and draws it in the Simple Media board style.

**Needs:** `Videos/_work/<name>/clipmap.json` + `source/video.mp4` (run parts/pull.md or parts/breakdown.md first).
Tool: `python3 ~/.claude/skills/ai-influencer/scripts/seedance_board.py <name> [--max 30] [--plan]`

## Steps
1. Run `seedance_board.py <name>`. It packs clips in order into generations of at most 30s (aim 20-30s):
   - fits in 30s → **one generation**, end on the last frame.
   - longer → G1 ends ON the first frame of the clip that doesn't fit (green hand-off card); G2 uses
     that end frame as its start frame. Same chain for G3... A single clip over 30s is cut into parts.
   Writes `seedance-plan.json` + `seedance-storyboard.png`.
2. Show the PNG (Read it) and a 3-line summary: generations, seconds each, start / end frame.
3. **Offer the trim option** when the video is 30-45s: "or cut the script to 30s and do it in one
   generation" (proven: clove water 45s → 30s, one generation, graded usable).
4. If the student moves a clip between generations, edit `seedance-plan.json` and re-run with `--plan`.
5. Hand-off: `parts/seedance-prompt-builder.md` writes one prompt per generation from this plan + the character kit
   (`Kits/Characters/<name>/locks`, 4 images) + the setting. Ask which character and setting if
   not given. Recipe rules: METHOD.md › "Seedance recreation path".

## Mixed tools (Omni + Seedance)
Set `"tool": "omni"` on clips in clipmap.json that should be made in Google Omni (Flow), one still per clip
(e.g. a before/after hook, where the same body must look different). They draw as a purple group joined to
the Seedance generations by a hard cut. Everything else is Seedance. Ask when a video has a before/after.
For a long body in Omni (interview, product authority: a short hook, then a minute+ of one talking head),
board only the Seedance hook here and hand the body to `parts/omni-storyboard.md`. Side characters are described in
the prompt, no kit; a before → after person is "the obese woman from the first shot, now slim and strikingly
beautiful" (same face, eyes, skin, hair, age).

## Split rules
Fewest generations that fit 30s, sizes as even as possible, cuts only at clip boundaries and never
between two recipe steps (a tiny 7s tail generation is wrong; 0-14 talk + 14-36 recipe is right).
