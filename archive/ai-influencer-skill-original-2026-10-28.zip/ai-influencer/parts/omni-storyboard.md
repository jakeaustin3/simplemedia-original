
# /omni-storyboard <row N | teardown folder>

**Talking-head videos only** (one person talking to camera). **Skits are different**: several
people talking to each other, one master image per setting, side characters in the box, cuts
inside each clip, camera held still, speakers named in every line. For a skit, stop and use
`parts/flow-skit-storyboard.md`. Same builder, different rules.

**Talking object** (from the Animation project): the speaker is the object from `parts/side-character.md`; every image
prompt ends with the look tail from `rules/animation/LOOKS.md` (*Talking objects*), its mouth visible in
every start image, its Voice line in every clip.

Pulled video in → one artifact out. The student copies each prompt into Nano Banana Pro (images) and
Google Flow Omni (clips), then edits the clips themselves. **Output = the artifact only. No PNG.**

**Needs:** the video folder from parts/pull.md or parts/breakdown.md (`clipmap.json` or clip-map + transcript + frames).
**Prompt rules:** everything needed is in this file (distilled from AI Influencer Part 1 07-recreation-engine §6–7). Don't open the project files; that's slow. New rules go here.
**Builder:** `python3 ~/.claude/skills/ai-influencer/scripts/omni_board.py <folder>` reads `<folder>/omni-plan.json`, writes `omni-storyboard.html`; publish it with the Artifact tool (republish same path to update).

## Steps (ONE question per message, never a second question at the bottom)
1. **Read the breakdown.** Look at the frames/contact sheet + transcript. Count **setups** not dialogue lines: same still in a row = one image animated several times. Recipe/ingredient beats = one still each.
2. **Character?** Kit at `Kits/Characters/<name>/` (locks, bible.md, outfits). Recreation = **change** the character, the outfit, and the location (if asked); **recommend** a prop change when it helps (e.g. a product swap). **Keep** framing (incl. how close the camera is), choreography, camera movement and the script word for word. Exception: if the original talks with the face out of frame, show the face (lip sync).
3. **Outfit?** (then, as its own message: **Location?** keep the original or a reference image the student sends, which goes in the box of the first image in that location)
    Always ask. Offer the kit's `outfits/` rows from bible §5 (not the lock outfit unless chosen) or "random". The outfit is **described in words** inside the anchor prompts only; the outfit image is not put in the box.
4. **Other people** in the video (client, mask, friend) = props: describe them distinctly in the first image they appear in (age, ethnicity, hair, wrinkles, clothes). Later images get that generated image in the box ("real-life version of the mask in the reference image").
5. Write `omni-plan.json` (shape in omni_board.py docstring), run the builder, publish, give the link + 3 lines (images, clips, what goes in each box). **Image 1 (the start image) is always on the page with its prompt**, even when it was already made (then add the note "done"); never give it only as a separate chat prompt. Copy the reference images to `~/Downloads/` numbered (`rules/DOORS.md`). Tell the student to run image 1 first and send it before the rest.

## Reference box (location rule)
- **First image in a location** = anchor, made raw: character face lock only (`locks/02_front_close_up.jpg`).
- **Every later image in the same location** gets that location's first image in the box, even a new anchor (different framing, same store). New location = raw again.
- Chained beats in one setup (ingredient 2, 3, 4…) all chain off that setup's anchor, never off a chained output.
- **Never** put original video frames in the box by default (students can't pick the right frame out of 10). Describe framing + environment in words. Original frame = fallback only if a generation comes out wrong.

## Image prompts
- Anchor: "Use the woman from the character reference, wearing <outfit>." + where she stands, framing, props on the table with left/right **of the frame**, her action frozen mid-motion, "She looks straight into the camera, mouth open mid-sentence." Tail: "Natural candid iPhone 14 Pro Max photo, handheld, slight tilt. Vertical 9:16. Deep focus, entire frame sharp, no bokeh, no background blur. No readable store names or brand logos."
- Delta: "Same exact image, except <what's gone> and <what's new>. <action>. <state of the container that received something>. She looks straight into the camera, mouth open mid-sentence." + "Same lighting as the reference image. Natural candid iPhone 14 Pro Max photo."
- **Face always on camera**: every talking frame shows her face, chest up, looking into the lens, even when the original crops to hands (e.g. chin-down blender shots). Better for continuity and lip sync.
- **Location reference image in the box**: it copies that photo's framing and people. Say "Use only the room from the second reference image, not its framing and not its people" and spell the framing out explicitly (e.g. "camera at arm's length: head and shoulders fill the top half, hands the bottom half").
- Continuity: the used item is put away / set down; the bowl shows everything poured so far.
- Never describe the **subject's** face, hair, body or the lighting. Prop people DO get described.
- **Side characters (interview, skits): no kit.** Describe them inside the anchor (age, build, skin, eyes, hair, clothes). Before → after person: the after image's box = lock + the before image's output, prompt "Same woman, same face, eye color, skin tone, hair color and age, except now she is <slim, styled, new outfit>". New people (e.g. the husband) are described fresh. Tested on Styles FULL row 21.
- **Mixed video** (e.g. Seedance hook, Omni body): this skill only boards the Omni part. The Seedance part comes from `parts/seedance-storyboard.md`; say so at the hand-off.

## Omni prompts (one per clip)
- Format: `The camera <holds steady | pushes forward toward the subject | tilts down slightly toward the X> as she <one simple action>. She says in a <accent from bible §7, default "standard American"> accent: "<exact line>" Natural movement, natural audio.`
- **Action and line are two sentences** (". She says…", not "and says…"): with "and says" Omni did the action first, then spoke.
- **Regional slang pulls the accent**: words like "chuck in", "the lot", "mate", "reckon" (Australian/British originals) made the character switch to an Australian accent. When the character's accent differs from the original creator's, swap those words for plain equivalents ("add in", "it all") and tell the student which words changed.
- **Accent in every clip**, from the character bible (§7 Voice). No pronunciation or delivery notes.
- **Minimal hand movement**: one simple action that continues what the still shows. No lifting things toward the lens, no handoffs, no extra gestures (they glitch). Clips re-animated off one still can repeat the same action.
- Word budget: <9 words 4s · 9–15 6s · 17–25 8s · 27–35 10s; split long talking at sentence breaks (~30 words max).
- **Hook**: no default push. Write an eye-catching action from the video (e.g. green liquid oozing from the syringe onto the forehead) and set the image's `note`: "Hook note: tailored to this video. Adjust the action until it grabs attention. Not every hook needs a push."

