
# /talking-head

One person talking to camera. Recipe, product authority and explainer are built **the same way** (one
Omni storyboard). The kind only changes where it's filmed and what the person is doing, so use it to
suggest the place and the actions. Interview is the one that differs: it has two people.

Arrives from the start of this skill with the product, character, clip map (if copying) and `script.md` in the video
folder. Anything missing: ask for it first, one question per message.

**One question per message.** Offer your best guess. Skip what the breakdown already shows.

## Steps (say where you are; when one is done, offer the next)
1. Which kind · 2. Where it's filmed · 3. Outfit · 4. How to make it · 5. **The storyboard** (image 1 =
the start image, then every image and clip on one page), then make · 6. Stitch, captions, save.
Follow `rules/DOORS.md`: you lead, prompts never go out as a file, reference images go to Downloads.

## 1. Which kind?
Copying: say which kind the breakdown looks like and ask them to confirm. Own idea: ask.

| Kind | Example | Usual place |
|---|---|---|
| **Recipe** | making a drink or a dish, step by step | their kitchen |
| **Product authority** | in a store (like Costco) talking about a product on the shelf | a store aisle |
| **Explainer** | teaching something, like why salmon that turns pink with lemon is bad | kitchen, home, or a store |
| **Interview** | someone asks a question, the character answers | the hook somewhere else, then the talking part |

## 2. Where is it filmed?
Suggest the usual place for the kind (copying: the original's place). A photo or a Video Database frame
they like can be the place reference.

## 3. Which outfit?
Offer the kit's outfits (`bible.md` §5), or "random". The start image (the character wearing that outfit
in that place) is **image 1 on the storyboard**, not a separate prompt before it. The student makes
image 1 first and sends it back; every other image builds on it.
Interview: also ask who asks the question (an off-camera voice, or a second person: `parts/side-character.md`).

## 4. How do you want to make it?
- **Google Flow by hand** (cheapest, recommended): Claude writes every prompt on one copy-paste page; the
  student makes the images and clips in Flow.
- **Seedance** (Claude can run it for you on kie.ai or Higgsfield; costs credits): up to 30 seconds per
  generation.
- Interview: the hook (the question) in Seedance or Flow, then the talking part in Flow.

## 5. Storyboard and make
- **Flow:** `parts/omni-storyboard.md` with the folder (it skips the character, outfit and place questions,
  already answered). **Image 1 is the start image**, with its reference images listed; then one image per
  setup, chained; one Omni prompt per clip; all on one page. Copy the reference images to `~/Downloads/`
  numbered. Say: "Make image 1 first and send it to me; if it looks right, run the rest." If image 1
  needs a fix, fix it on the same page and republish.
- **Claude makes image 1** (if they'd rather): show the cost, generate it, show it, then build the page
  with it marked done.
- **Seedance:** `parts/seedance-storyboard.md` (skip the character, outfit and place questions, already answered; packs it into 30-second generations), then
  `parts/seedance-prompt-builder.md`. Show the cost, run on a yes (one clip first), or hand over the prompts.
- **Interview:** the hook first (Seedance or Flow), then the talking part as one image animated in Omni
  clips.

## 6. Then
The ending from the start of this skill: stitch (`parts/stitch.md`, also joins Seedance generations or the interview
hook to its body), captions on the video, post caption, save.
