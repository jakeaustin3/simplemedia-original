
# /script

Gets the video to a script the student is happy with. Runs after the style is known (a script is written for a
style, so ask the style first if it isn't settled). Skip for transformation (no words).

**One question per message.** Plain English, full sentences, no skill or pattern names unless asked.
Everything already settled (product, character, style, creator, the video folder) comes from the start of this skill; don't
ask it again.

## Read first
- The style's library file, if there is one:
  | Style | Library file |
  |---|---|
  | Talking head recipe, green screen or overlay recipe, recipe hands video | `rules/scripts/recipe.md` |
  | Skit, animated skit | `rules/scripts/skit.md` |
  | Anything else | no file yet: use `rules/scripts/README.md` rules and the creator file or a Video DB sample |
- `rules/scripts/README.md` (rules for every script).
- The product's `product.md` if there is one: **the buyer's words** (workarounds, doubts, results), the label
  wording, the price, the comment word. These are the best lines in the script.
- The character's `bible.md` voice line.
- `creator.txt` in the video folder, if set: that creator's **Script templates** count as extra patterns.

## Way 1 · The student has a script
Use it as it is. Don't point out fixes unless they ask for feedback. Save it.

## Way 2 · Copying a video
Run `parts/script-remix.md` with the original as the sample: same structure and rhythm, about 20% changed for their
character, product and topic. Show it, loop only if they ask for changes, then save it.

## Way 3 · An idea, no script
### A. Get the idea sharp (only if it's loose)
If the student gave a topic, not a clear idea ("something about lemon trees"), offer: "Want me to throw a bunch
of ideas at you first?" Then, one step per message:
1. **Many ideas:** 15–20 one-line ideas, fast, weak ones included, numbered.
2. **Sharpen one:** they pick a number. Show a chain of about 5 versions, each changing one thing (a word, more
   specific, a clearer promise). Every version still fits the style.
3. **Push it, then pull it back:** they pick one. Show it pushed too far, past the limit, and pulled back to
   something the character can film.
Skip any step the student doesn't want. A clear idea goes straight to B.

### B. Ask for what they already have
"Is there anything that has to be in it? Key lines, points, a story, how it ends." One question; whatever they
give goes into every option.

### C. Write the options
1. **Pick three patterns** from the style file (and the creator file) that fit the idea. Never ask the student to
   pick a pattern. For skits, match the idea to the closest card; if none fits, say so and ask for a reference
   video rather than inventing a structure.
2. **Write 3 scripts side by side** (up to 5 if they ask), one per pattern, split into the **same named
   sections** (Hook, then the pattern's beats, then the CTA) so they can mix and match. Skits are written as
   dialogue blocks, one per option, with the same beat labels in the margin.
3. **Length follows the pattern** (the style file says how long). Don't cut a skit short to fit.
4. Under the options, one line per script: which pattern it follows and which desire it leans on.

### D. The loop
Do what they ask, then show the result the same way:
- "Number 2" → that one is the script.
- "Hook from 1, the rest from 3" → join them, smooth the seams.
- "Five more like 2, but change X" → five new versions of 2.
- "Only redo the hook / the ending / this line" → change only that, show the full script.
- "None of these" → ask one question about what's off (hook, voice, story, pitch), then a new round.
Keep going until they say it's good.

## Save
1. `script.md` in the video folder: the final script, plain text, numbers spelled out.
2. `script-log.md` in the video folder:
   - the pattern the final script follows (`recipe R1`, `skit S1`, a creator template, or their own)
   - the script exactly as Claude last wrote it
   - a line: "Student's final version: same as above" (update it if they edit it later)
3. Tell the student in one line it's saved, and hand back to the start of this skill (or the door that called this).

The style's door splits the script for its tool (Omni ~30-word clips, Seedance generations, HeyGen) and, for
skits, turns it into a screenplay. This door doesn't.
