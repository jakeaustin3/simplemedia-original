
# Seedance 2.5 Prompt Builder

Use whenever Max wants a Seedance ("Seedance", "Sedance", "Cedense", "Seed-Ans") prompt: recreating a video he sends, continuing a clip he generated, or building a new scene from character reference sheets. Output ONE copy-paste prompt per clip in the exact template below, then a one-line settings note. Never trim the prompt when he asks for "the whole thing" — paste it complete.

## Step 0 — Analyze before writing

If a reference video is attached, extract frames before writing anything (ffmpeg is available):
- Contact sheet: `ffmpeg -i in.mp4 -vf "fps=1,scale=270:-1,tile=6x6" contact.jpg` — read it to map shots, framing, locations, props, beats.
- Caption strip if the video has burned-in captions: `ffmpeg -i in.mp4 -vf "fps=4,crop=iw:ih*0.14:0:ih*0.50,scale=480:-1,tile=3x23" caps.jpg` (adjust crop band to where captions sit; use fps=6 for one-word-at-a-time captions). Reconstruct the script from the captions and mark any words that fell between frames as guesses.
- Whisper/model downloads are blocked in the sandbox — rely on captions and visuals.
- Report the shot list you read back in one sentence ("wide → OTS → OTS → wide, 7 shots, 20s") so Max can correct it.

If Max attaches character sheets, list which one maps to which @image_N. Ask nothing you can infer; if something is missing (a scene, a prompt version, settings), ask for exactly that and nothing else.

## The template (keep field order and headings)

```
Reference Mapping:
@image_1 = [Who/what — short physical description incl. wardrobe]. ["Use exactly as shown." | "USE FACE AND BODY ONLY — wardrobe is replaced below."]
@image_2 = ...

---

FORMAT: [N]s / [K] SHOTS / [one-sentence logline]

SUBJECT: [Name] from @image_1 — [emotional state / energy].
SECONDARY SUBJECT: ...
WARDROBE: Exactly as shown in @image_N. [or the override outfit]. Same outfits in every shot.
HERO PROPS: [Each key object described once, in a fixed spec that is repeated in every shot it appears; product bottles referenced by @image_N with "label never redrawn or altered, label to camera".]
ENVIRONMENT: [Location(s) with 5–8 concrete anchors; time of day; light.]
MOOD: [Arrow arc: a → b → c.]
MUSIC: No score. [Ambience only; voice "clean and forward".]
COLOR LOGIC: [Palette + the one accent color.]
STYLE: [Look + lenses + camera behaviour + "hard cuts only".]
LOGIC RULE: [Head count; faces identical to references; locked positions/sides; who speaks when; eye-line rules; "no text on screen".]
PRONUNCIATION: Every word in quotes is spoken exactly as written, hyphenated words are single words spoken smoothly with no pause at the hyphens: ["x-y-z" = word, ...].
NEGATIVE PROMPT: [extra people, duplicate characters, face morphing, wardrobe change, text, captions, subtitles, watermark, slow motion, fade in, fade out, zoom into face, distorted hands, extra fingers, plastic AI skin + scene-specific items]

---

SHOT 1 — 0:00 to 0:0X, [WS|MS|MCU|CU|ECU] [over X's blurred shoulder], [24|35|50|85]mm, [locked|handheld|slow push-in|tracking].
[Action in prose, 1–3 sentences, max 2–3 actions.]
[Name]: "[line]"

... (next shots)

DIALOGUE ASSIGNMENT — CRITICAL: Shot 1 only X. Shot 2 only Y. ... Whoever is not assigned keeps their mouth closed. [Name] has zero lines.

No text overlays. Ultra realistic [cinematic | handheld smartphone | front-camera phone] footage. Lip sync matches dialogue exactly. Not AI looking. If this looks AI generated it has failed.
```

After the prompt, one line: `Settings: Seedance 2.5, [N]s, 9:16, 1080p, High, Elements on, references in order — [list].` Then at most two short fallback notes.

## Hard rules learned

- **30-second cap.** Seedance generates max 30s. Over that, split into clips of ≤30s; split at a location change or a beat boundary, never mid-line. Each clip gets the full header again with timestamps restarted at 0:00.
- **Timing.** 2–3s per short line, ~8s for a 30-word emotional line, 1–2s for a silent reaction. Count words: ~2.5 words/sec at natural pace. If the script is shorter than the requested duration, stretch with silent inserts and physical beats, and say so.
- **Dialogue close-ups are OTS**: "MCU over [listener]'s blurred shoulder, 85mm, locked". Wides (24–35mm) only to establish or exit. Never zoom into a face.
- **Lock positions and sides** ("Keisha camera-right, Monique camera-left, never swap").
- **One speaker per shot**, always restated in DIALOGUE ASSIGNMENT. Off-screen lines are marked "(off-screen)" and listed there too.
- **No captions ever** from the generator: "text, captions, subtitles, watermark" in negatives + "No text overlays" closing line. Max adds captions in CapCut.
- **Eyes on the lens when he asks for it**: state it in SUBJECT, LOGIC RULE and DIALOGUE ASSIGNMENT (three places on purpose). For a seminar/room, put the camera "in the third row of the audience" so addressing the room = looking into the lens.
- **American accent**: write "clear American accent" in SUBJECT and again in DIALOGUE ASSIGNMENT.

## Pronunciation (Seedance mispronounces these)

Always respell in the dialogue AND add to the PRONUNCIATION block, lowercase hyphenated, no capital stress marks:
- Rhodiola Rosea → `roh-dee-oh-lah roh-zay-ah` (confirmed working)
- Salvora → `sal-vor-ah`
- thyroid → `thigh-royd` (fallbacks: `thy-royd`, `thai-roid`)
- iodine → `eye-oh-dine`; selenium → `seh-lee-nee-um`
- Brand initialisms: MakeUGC → `make-you-gee-see`; "$1" → `one dollar`
- Any other scientific or brand word: respell the same way. Whiteboards/labels keep normal spelling — phonetics are for spoken lines only.
- Known audio-fail words: "beer" → "drink"; brand-name drugs (Ozempic) → "the injections" as fallback.

## Character references

- Sheets are 4-panel (front / ¾ / profile / rear) from GPT Image 2 via the `character-reference-sheet` skill; a 3-panel variant is fine.
- To reuse a face in a different outfit: `USE FACE AND BODY ONLY — wardrobe is replaced below` + full outfit in WARDROBE + old outfit (e.g. "swimsuit", "green satin dress") in NEGATIVE PROMPT + a LOGIC RULE sentence "X never wears the [old outfit]".
- A transformed character (weight loss) gets a NEW sheet; never attach the old sheet to that clip; add "body shape changing" to negatives and "her body is the slim athletic body from @image_1 — never heavier" to LOGIC RULE.
- Minor characters who appear once (a doctor) need no sheet — describe in text.
- Product bottles: attach the label photo as its own @image and reference it everywhere the bottle appears; "fills at least 30% of frame" for the hero product shot.

## Continuation trick (the most valuable pattern)

When a long prompt breaks in its second half, or a scene must continue: keep the good clip, screenshot its last over-the-shoulder frames of each character, attach those frames as @image_1/@image_2 (plus any key-frame still), and write the new clip with "SHOT 1 starts on the exact framing of @image_1 — same seat positions, same lens, same lighting". Split prompts where the location changes so the model only holds one set of faces/props per clip.

For a phone showing a video: generate the phone-video scene as a GPT Image still first, reference it as @image_N, write "the phone screen shows exactly the @image_N scene, nothing else", then hard-cut to the still's composition full-screen.

## Single-reference optimisation (no prop references)

When only the person is referenced: cut shot count, allow only TWO camera positions (name them POSITION A / B and reuse), merge hands-only inserts into 1–2 shots, describe food/props once in HERO PROPS as a fixed spec and repeat that spec verbatim in every shot they appear, add "camera moving between shots", "different bowl/tray", "cookies changing size, shape or color between shots" to negatives. Tell Max continuity of un-referenced props is the weakest link and to run twice and keep the matching roll.

## Style presets

- **Cinematic story ad** (pool / bar / park / office): 35mm wides, 85mm OTS, "soft grain, hard cuts only", moody practical light or golden hour; "Same look as the [previous] scene".
- **Documentary seminar / healer**: 35mm locked wide from the audience, 50mm slow push-in, 85mm CU; audience "seen only from behind"; whiteboard text listed explicitly.
- **Direct-to-camera UGC (seated)**: 50mm MCU locked on a phone tripod, one 24mm wide of the room, product held beside the face label-out.
- **Front-camera selfie UGC**: "ultra-wide selfie lens with slight edge distortion, handheld in her own hand for the entire clip", ECU face filling frame, macro fabric insert, arm's-length body shot, over-the-shoulder back turn, low-angle shoes, optional mirror selfie; "no tripod, no propped phone" in LOGIC RULE and negatives; she talks in every shot, voice continues off-screen in inserts.

## Flag avoidance

Body-shaming lines ("you look like a whale") and bare torsos can trip filters. Fallback order: soften the insult → cover the torso ("fitted white tank top") → change location. Never write "shirtless"; say "exactly as shown in @image_N". Women in scenes are min. 25 unless the sheet says otherwise.

## Delivery

- New scene: give a short SCRIPT block first (character: line, with tone in parentheses), then the prompt, so Max can edit the script separately.
- Recreation: give the reconstructed script in one paragraph, flag guessed words, then the prompt.
- Always state duration per clip and reference upload order. Keep commentary to 2–4 sentences after the prompt; flag factual risks in ad claims once (e.g. Rhodiola is not an African plant) and offer the accurate wording.