# Seedance Movie — install and use

Turns a script into finished Seedance 2.5 prompts for a movie-style short video.

## Install

Upload this folder as a skill to your Claude Project, or drop it in `.claude/skills/`.

## Have ready before you start

1. **Your script.** Dialogue is enough. The skill will time it and break it up.
2. **Reference images for anyone who appears in more than one clip** — a face close-up and a
   full-body shot per person, on a plain backdrop. Without these your characters come back looking
   like famous actors and change between clips. This is the single most common way a build goes
   wrong.
3. **A product photo**, if the video points at a product.

## What you get back

- One complete prompt per generation, ready to paste
- A settings line and a credit estimate before anything runs
- A post spec: where the music enters, the caption style, what to composite

## The four rules behind all of it

Learned from thirty logged generations. If you only remember four things:

1. **Five shots per generation, maximum.** More than that and the model averages them into one
   repeated setup. This is the number one cause of a video looking fake.
2. **Name your camera setups and reuse them.** Two to four, declared once, referred to by name in
   every shot. Ad-hoc framings do not cut together.
3. **Thirty seconds is a hard cap**, and speech runs at about three words per second. A 30-second
   clip is roughly 80 words.
4. **A setting does not reproduce between generations.** Same world, not the same room. Put your
   cuts where a new angle is expected anyway.

## What the model cannot do

- Render text it has to invent. Labels, signs and names come back as gibberish — composite them in
  post. Text copied from a reference image reproduces much better.
- Hold a face from a text description alone.
- Hand a prop from one character to another without glitching.

## Where the rules live

| File | What is in it |
|---|---|
| `SKILL.md` | The workflow: script → cast → break → prompts |
| `references/script-template.md` | Beat structure, stakes, the word budget |
| `references/character-lock.md` | How to lock a face, a wardrobe and a product |
| `references/prompt-layout.md` | Block order, shot rules, look presets, and §7 — every logged failure and its fix |
| `references/formats/` | movie-drama and movie-two-hander |
| `references/post-spec.md` | Music, sound, captions, graphics — all added in CapCut |

**`references/prompt-layout.md` §7 is the most valuable file here.** Every row came from a
generation somebody paid for. Add a row whenever something breaks.

## Status

`movie-drama` is validated across eleven generations. `movie-two-hander` carries rules proven over
twelve earlier generations but has not yet been run in this form. Last-frame chaining, mentioned in
§2, is untested — try it at low resolution before relying on it.
