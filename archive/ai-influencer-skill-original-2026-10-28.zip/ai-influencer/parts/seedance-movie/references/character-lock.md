# Locking characters

A character who changes between clips destroys the illusion faster than any other error. There are
two ways to hold one, and a movie-style video normally needs both.

---

## 1. Image locks (for anyone whose face must be exactly right)

Two reference images per character: **face** (head and shoulders) and **body** (full length,
complete wardrobe including shoes). Generate them once, reuse them forever.

**Reference order is the whole game.** The model ignores filenames and reads upload order only.
Decide the order once, write it into every prompt of the build, and never change it mid-scene:

```
@Image1  lead — face
@Image2  lead — body
@Image3  second character — face
@Image4  second character — body
…        props last
```

State in the prompt which number is which. Every attached image must be named somewhere in the
prompt, and nothing may be named that is not attached.

**The CHARACTER block, filled from the references:**

```
<NAME> — the <man/woman> in @Image{BODY} and @Image{FACE}. Same face, same <distinguishing
features>, same <makeup / facial hair / jewelry> as @Image{FACE}. Wardrobe exactly as
@Image{BODY} in every shot: <every garment, top to bottom, including shoes>. Voice: <two or three
adjectives, then "the same voice in every shot">.
```

### Making the reference images

Vertical 9:16, **plain seamless warm-cream studio backdrop** — a room in the reference leaks into
the generated video. Soft even light, neutral expression, complete wardrobe including shoes and
jewelry. If you are working from a photo you already have, open with "Use the attached image as
the character reference", list exactly what to keep, then state the ONE thing that changes.

### Wardrobe override — reusing a face in different clothes

When the same person appears in a new outfit, don't fight the reference. Overrule it and put the
old clothes in the negatives:

```
<NAME> — the woman in @Image3 and @Image4. USE FACE AND BODY ONLY — the wardrobe in @Image4 is
replaced below. Wardrobe in every shot: <new outfit, head to toe>.
…
EXCLUSIONS: … She never wears <the old outfit from @Image4>.
```

## 2. Text locks (for everyone else)

Side characters — a cashier, a doctor, a security guard, a friend — do not need reference images.
They need a paragraph, pasted **byte-identical into every clip they appear in**.

A text lock that holds carries all seven of these. Drop one and that is the one that drifts:

> age · height · build · skin tone · **hair colour AND hairstyle** · complete wardrobe top to
> bottom including shoes · voice

```
DOCTOR — a man of about fifty-five, six foot, lean build, fair skin, short silver-gray hair combed
back, clean shaven, thin gold-rimmed glasses. Wardrobe exactly the same in every shot: a white
lab coat over a pale blue button-down shirt, navy trousers, brown leather shoes. Voice: even,
unhurried, slightly bored American man's voice.
```

**Two characters in a scene must differ on hair colour AND hairstyle.** Matching either one and
they blend into each other by clip two.

### The rule that most people get wrong

**Lock what the model produced, not what you asked for.**

A salesman was written as "charcoal suit, lanyard, badge". He came back in a gray polo with no
lanyard. Rewriting the lock to describe the gray polo — the thing that actually appeared — held
him perfectly across every later clip.

So: generate clip 1, look at what you got, and rewrite the text lock to match it before writing
clip 2. Fighting the first generation costs money. Adopting it is free.

## 3. Pronunciation

Every name, brand or unusual word gets a PRONUNCIATION line in every prompt. The model will
otherwise say it differently in every clip.

```
PRONUNCIATION: Saoirse is pronounced SEER-sha. Nuvella is pronounced noo-VELL-uh.
```

Keep a running list for your build as words fail, and carry it into every later prompt:

| Word | Write it as | Why |
|---|---|---|
| a brand name | spelled phonetically, stress in CAPS | invented words get read letter by letter |
| a character name | rhyme it with a common word | unusual spellings get anglicised |
| any number | words, not digits | "12,000" gets read as "twelve comma zero zero zero" |

## 4. What cannot be locked

**Text.** Not a name badge, not a logo, not a price, not a label on a bottle. Seedance renders
letter-shaped gibberish. If a product or a sign has to be readable, design it to read by **shape**
— silhouette, colour, the way it is held — and composite the real graphic in post.
