# The script template

A form, not a generator. The writer fills the slots; this file stops them writing something the
model cannot shoot. Fill it in, then hand it to phase 2 of the skill.

Derived from three finished videos that performed (18 s, 29 s and 95 s) plus one validated 20 s
build. Every rule below is a pattern all of them share, not a preference.

---

## First: the budget

A length buys a fixed number of shots and a fixed number of words. Work these out **before**
writing a line.

| Length | Generations | Shots | Words |
|---|---|---|---|
| 20 s | 1 | 5 | ~55 |
| 30 s | 1 | 5 | ~70 |
| 60 s | 2–3 | 5 each | ~150 |
| 90 s+ | 5–7 | 5 each | ~280 |

**Words = (length in seconds − silent seconds) × 3.** A 30 s clip with one 4-second silent beat is
78 words, not 60. Do not leave yourself slack "for reaction beats" — the beats live inside the
lines. A clip written at 2 words per second comes back feeling slow, and that has now happened
twice in the log.

## The cast — one job each, four speakers maximum

| Role | Job | Must be |
|---|---|---|
| **PROTAGONIST** | the viewer. Gets humiliated in public. | **Sympathetic.** See the sympathy rule. |
| **ACCUSER** | says the first line. Does not back down until the turn. | Certain, never cartoonish |
| **MIRROR** | arrives at the turn carrying the mechanism | Calm. Has been where the protagonist is. |
| **WITNESSES** | look. Never speak. | Silent, staged, in EXCLUSIONS |

Everyone who speaks needs a clean eyeline to the lens. Nobody speaks from behind someone else.

## The beats

Fill each slot. Stay under each word cap. A slot with no words is a **silent beat** — leave it
silent, do not fill it.

```
BEAT 1  ACCUSATION   [≤ 16 words]  Spoken BY the accuser, ABOUT the protagonist, IN PUBLIC,
                                   landing before 0:03. No narrator, no setup, no establishing
                                   shot. This is frame one.
                                   ALSO WRITE: the OPENING IMAGE — see below.

BEAT 2  ESCALATION   [≤ 12 words]  It gets worse and the witnesses register it. The protagonist
                                   may answer once — and does not win.

BEAT 3  LOW POINT    [silent]      The protagonist absorbs it. Hold on the face. No line.

BEAT 4  THE TURN     [≤ 12 words]  Someone reverses the situation. THIS IS THE VIDEO. Cut
                                   anything else before you cut this.

BEAT 5  RELEASE      [≤ 16 words]  The mechanism, and then absolution: say plainly that it was
                                   never their fault. Optionally the symptom read — describe
                                   their day back to them before they have said it.

BEAT 6  THE ASK      [≤ 10 words]  The CTA, or the hook. Never before BEAT 5.
```

## The opening image

The accusation is **audio**. The opening **image** is a separate decision and it is the one that
decides whether anyone watches.

**Frame one must show the thing being accused, not the person accusing.** A flight attendant
saying "you're over the armrest" over a close-up of the flight attendant tells the viewer nothing —
they see a woman telling off a blurry stranger. The same line over a shot of the man wedged into
the seat explains the entire video in one second, before a word lands.

So for BEAT 1, write both:

```
OPENING IMAGE:  what the viewer SEES in frame one — the premise, visible
OPENING LINE:   what the viewer HEARS over it — the accusation
```

**Write the premise as geometry, never as an adjective.** "Very heavy" is an opinion the model
rounds down. "Fills the seat completely and continues past its edge into the next seat, which
cannot be used" is a fact it has to compose around. Whatever the accusation points at — a body in
a seat, a bag in an aisle, a stain on a shirt — describe where it is and what it touches.

If the premise cannot be seen, the wardrobe or the staging is wrong. Fix it there, not by adding
an explaining line. **Anything the accusation refers to must be visible while it is spoken** —
including the protagonist's body when the scene is about their body. Loose clothing that hides the
premise is a continuity error, not modesty.

**Six beats do not fit in five shots.** At 20–30 s, fold BEAT 3 into BEAT 2 as an action note on
the face, and give BEATS 4 and 5 to the same speaker in one shot. At 60 s+ every beat gets its
own shot and BEAT 2 can become a whole failed-fix scene with an authority figure.

## The stakes rule

**The protagonist must be about to lose something real, in public, in the next sixty seconds.**

Not be embarrassed. Not be inconvenienced. Lose something. If the worst outcome is that they pay
some money or feel awkward, there is no video — the viewer has nothing to be afraid of on their
behalf, and fear is what holds them to the end.

What the references actually threaten:

| Reference | What is about to be lost |
|---|---|
| Walmart | Arrested for shoplifting. Strip-searched in a back room. |
| Pool / Salvora | Her marriage, out loud, in front of the woman replacing her. |
| Dinner date | Rejected to her face in a full restaurant. |

**Name the loss out loud in the dialogue.** "I'm going to have to ask you to come with me" is a
stake. "You'll need to purchase a second seat" is an invoice. Same scene, and only one of them is
a video.

Three ways to raise stakes that already exist in your scene, in order of strength:

1. **Removal.** The protagonist is about to be made to leave — the flight, the restaurant, the
   store — and walk past everyone to do it.
2. **Authority.** The accuser has power over them, not just an opinion. A manager, an officer, a
   member of staff. Someone whose word actually makes it happen.
3. **Witnesses who join in.** The room stops being background and becomes a participant.

### The third-person line

The single cruellest move in the references, and it appears in all of them:

> **A bystander refers to the protagonist as "he", "she" or "that", to someone else, while the
> protagonist is right there.**

*"Is that **thing** your wife?"* · *"Is somebody going to move **him**?"*

Being talked about as an object in public is worse than being insulted directly, because there is
nothing to answer. Put exactly one of these in, at the top of the escalation, and give it to
someone who is not the accuser.

## The rescue

**The turn should be an action, not a speech.** In Walmart the reversal is that she lifts the
shirt — the accusation collapses on its own, and nobody explains it. A character who simply starts
talking has not earned the right to be listened to.

So the mirror **solves the immediate problem first**, physically, at some cost to themselves.
They give up the seat, they pay, they step in. Only then do they say the real thing — and by then
the protagonist is listening, and so is the viewer.

## The sympathy rule

**In all three references the accuser is proved wrong, or the protagonist is vindicated.**

The officer who demanded the shirt be lifted apologises. The woman mocked at the pool is the one
who ends up with the answer. That reversal is the entire difference between a video people send
each other and a video about being cruel to someone.

So the protagonist is never the one at fault, and never obnoxious. They can be wrong about the
*cause* — that is what the mirror is for — but they are never the villain. If the accuser turns
out to be correct and the protagonist simply deserved it, there is no turn, and without a turn
there is nothing to share.

The viewer has to be able to think *that could be me.* Nobody thinks that about someone they are
being invited to dislike.

## Dialogue

- Contractions always. Fillers where a real person would use them — "honestly", "I mean", "look".
- People talk past each other and interrupt. **Nobody makes a speech except the mirror at BEAT 5.**
- No em dashes inside a spoken line; the model reads the pause wrong.
- Numbers as words.
- Say the lines out loud and time them. **Three words per second** is faster than it feels.
- Every brand or unusual name goes on the pronunciation list.

## Before handing it over — check

- [ ] the first line is an accusation, spoken by someone else, in public, before 0:03
- [ ] frame one SHOWS the premise — not the person delivering the accusation
- [ ] word count is (length − silent seconds) × 3, not less
- [ ] the protagonist is sympathetic and the accuser does not simply turn out to be right
- [ ] the protagonist is about to LOSE something concrete, and the loss is said out loud
- [ ] one third-person line, from a bystander, at the top of the escalation
- [ ] the turn is an ACTION the mirror takes, before it is a thing the mirror says
- [ ] there is a turn, and it is not the last beat
- [ ] the CTA comes after the mechanism, never before
- [ ] word count is under the budget for the length
- [ ] beats ≤ shots available, after folding
- [ ] four speakers maximum, each with a clean eyeline
- [ ] nothing in the story depends on readable text on screen
