# The post spec

Seedance gives you picture, dialogue and room tone. **Everything below is added in CapCut and
none of it goes in the prompt.** Music in a prompt muddies the dialogue — that is settled, from
twelve logged runs — but "add music in post" is useless advice on its own. So the skill hands
over this spec with every build, cued to the beats.

---

## Music

One track, entering **under the accusation, not before it.** Silence for the first half second,
then the bed. A clip that opens with music already running reads as an advert; a clip where the
music arrives *with* the first line reads as a film.

| Beat | Cue |
|---|---|
| **Accusation** | Low sustained string or synth pad, one note, quiet. Enters half a second after the first word. No melody yet. |
| **Escalation** | The same note, a fifth up, or a second voice under it. Nothing rhythmic. |
| **Low point** | **Drop everything.** The silent beat is silent in the music too. This is the loudest thing in the edit. |
| **The turn** | A single low piano note or a soft pluck on the first word of the turn line. One note. |
| **Release** | Warm pad comes up underneath, slow. First time anything resolves. |
| **The ask** | Hold the pad. Do not swell it. A swell on a product name sounds like an advert. |

Keep the whole bed **under −18 dB** relative to dialogue. If you can name the tune, it is too loud.

## Sound design

Seedance already generated the room. These go **on top**:

- a low sub-drop on the cut into the low point
- a soft cloth or movement accent on the physical beat — the elbow coming in, the bottle coming out
- a very short reverse-swell (~0.4 s) leading into the turn line
- nothing on the accusation. It lands dry. Dry is what makes it uncomfortable.

No whooshes between every cut. One or two accents in a thirty-second clip, not six.

## Captions

Burned in, because the model cannot spell. Follow the reference videos:

- **Two to four words on screen at a time**, centred, lower third
- Heavy sans, white, thin dark outline or a soft shadow
- **One word per line highlighted** in yellow as it is spoken — the key word, not every word
- Captions on the dialogue only. **The silent beat has no caption.**

## Graphics

Any text that has to be exact — a product label, a name, a price, a URL — is composited here, not
generated. A product reference image gets the shape, colour and large type close (§7), so a
post graphic normally only needs to sit over the label rather than replace the whole object.

## The ending card

If the ending is "follow for part 2", that is a card over the final frame in CapCut. Never ask
the model to render it.
