# Format: movie drama

A short narrative film. **4–6 characters, one to four locations, driven by a pain the viewer
already has.** It opens on someone being humiliated in public, puts them through a failed attempt
at fixing it, and ends on a hook or a call to action.

"Movie" here means *multi-scene narrative* — not polished. Two of the three reference videos are
deliberately flat and unglamorous. See **Look** below; picking wrong is the single biggest
give-away.

**Not this format:** two people talking in one room with a punchline (`movie-two-hander.md`), or
anyone speaking to camera.

---

## 1. The opening line

The first line is spoken **by someone else, about the protagonist, in public, inside three
seconds.** It is an accusation or a humiliation. The protagonist is the viewer's proxy — the
shame has to be the viewer's own.

> "Your profile said athletic build. Those pictures are not you."
> "Ma'am, stop right there. I need to see what's under your shirt."
> "Wait — is that *thing* your wife?"

No narrator. No setup. No establishing shot before the line. The accusation is frame one.

A protagonist who is merely *inconvenienced* does not work. They have to be exposed.

## 2. Cast

Four to six people, each doing exactly one job:

| Role | Job | Locked how |
|---|---|---|
| **Protagonist** | carries the pain; the viewer | image lock (face + body) |
| **Accuser** | delivers the opening humiliation | image lock if they recur, text lock if one scene |
| **Authority** | doctor, officer, manager — tries the obvious fix and fails | text lock |
| **The mirror** | solved this already; explains the real cause | image lock |
| **Bystanders** | react; never speak more than a line | text lock |

The **mirror** is the mechanism of the whole format. The protagonist cannot solve their own
problem — someone who has already been where they are has to name the real cause. Without this
character you have a complaint, not a story.

## 3. Beat structure

The long form, roughly 95 s across four locations. Cut whole acts for shorter runs:

| Act | Beat | Runtime | Location |
|---|---|---|---|
| 1 | **Humiliation.** The accusation, in public, with witnesses. | 0:00–0:17 | A |
| 2 | **The wrong fix.** An authority gives the obvious advice. It has already been tried. | 0:17–0:35 | B |
| 3 | **The mirror.** A chance meeting with someone who looks how the protagonist wants to look. | 0:35–0:53 | C |
| 4 | **The mechanism.** The real cause, named. *"You've been fighting a hormone with a treadmill."* | 0:53–1:16 | C |
| 5 | **The fix, then the ask.** | 1:16–1:35 | C |

**Act 4 is the payload.** It is the longest beat and the only one carrying information. Everything
before it exists to make someone listen to it. Two things make it land:

- **Absolution.** Say plainly that it was never their fault. The whole first half was the viewer
  blaming themselves; Act 4 takes that away.
- **The symptom read.** The mirror describes the protagonist's day back to them without being
  told — *"exhausted by three, can't sleep, jeans fit in the morning and cut into you by dinner."*
  Recognition beats explanation. Write three specific symptoms, never a general claim.

### Short forms

- **18 s, one location, three scenes.** Act 1 only. Ends on a silent reaction.
- **29 s, one location.** Act 1 plus an immediate reversal — the accuser is publicly wrong and has
  to apologise. Ends on a hook.

## 4. Endings — pick one and commit

| Ending | Last beat | Use when |
|---|---|---|
| **Silent reaction** | Hold on the protagonist's face. No line. | The humiliation is the whole point. |
| **"Follow for part 2"** | A card over the final frame — **added in CapCut, never generated.** | The reversal lands but the story isn't finished. |
| **Hard CTA** | The mirror names where to get it, straight to the protagonist. | There is a product. Only earn this after Act 4. |

Never put a CTA before the mechanism. The viewer has to be given something first.

## 5. Staging

One location per generation, always. Within a scene pick **three or four** named setups:

```
ON <PROTAGONIST> — 50mm over <accuser>'s shoulder. Their <colour> shoulder soft at the <side>
  edge of frame. <Protagonist> looks just off-lens toward frame <side>. <what is soft behind>.
ON <ACCUSER>   — 50mm over <protagonist>'s shoulder, mirrored. …
WIDE           — 35mm medium-wide. <who> left, <who> right, everyone fully in frame, upper
  bodies visible, generous room on both sides.
REACTION       — 50mm on the bystanders, <side> of frame, watching. They do not speak.
INSERT         — 100mm on <the prop>. The voice continues over it.
```

Rules that came out of real failures:

- **Fixed sides.** Each person keeps one side of frame for the entire scene. Name it in STAGING
  and again in every shot. They never swap.
- **Everyone who speaks gets a clean eyeline.** Never stack a speaking character behind another —
  the camera pulls back to see them both and the close-ups die.
- **Never write "or" into a staging instruction.** "Out of frame or soft at the edge" gave the
  model an out and it took it.
- **Exit rule, always in STAGING:** *"When someone walks out of frame, the camera stays put: same
  framing, the empty space where they were, never a wider shot."*
- Bystanders are staged but silent. Give them a REACTION setup and put them in EXCLUSIONS:
  *"The people watching never speak."*

## 6. Look — pick the preset from the location

| Location | Preset | Why |
|---|---|---|
| Restaurant, hotel, bar at night, showroom, poolside | **POLISHED** | Aspirational. Shallow, warm, lit. |
| Supermarket, clinic, waiting room, office, anywhere fluorescent | **FLAT / REAL** | The point is that this could be happening to you. Gloss kills it. |

Full blocks in `../prompt-layout.md` §5. A video crossing both — a poolside act and a clinic act —
**switches preset per location.** That contrast is doing work; do not smooth it out.

The failure to avoid: writing "premium commercial grade, creamy bokeh" over a supermarket. It
turns a story into an advert, and the viewer stops believing it in about a second.

## 7. Multi-location continuity

Characters carry across locations. The room never does.

- Every CHARACTER block, the PRONUNCIATION block and the AUDIO block stay **byte-identical in
  every clip of the whole video**, across locations.
- SETTING, STAGING and LOOK are byte-identical **within a location**, and rewritten at each
  change.
- Wardrobe changes between acts are fine and read as time passing — but each new outfit is a
  wardrobe override (`../character-lock.md` §1) and then stays locked for the rest of that act.
- A location running longer than ~25 s spans more than one generation and **will change rooms.**
  Plan the cut where a new angle is expected, or test last-frame chaining
  (`../prompt-layout.md` §2).

## 8. Dialogue

- Contractions always. Fillers where a real person would use them — "honestly", "I mean", "look".
- People talk past each other and interrupt. Nobody makes a speech except the mirror in Act 4.
- No em dashes in a spoken line; the model reads the pause wrong.
- Numbers as words.
- **~3 words per second.** A 95 s video is roughly 280 spoken words. Count them.
- Every brand or unusual name goes in PRONUNCIATION, every clip.

## 9. Sound

In the prompt: the room, ducked under every line — a supermarket's hum and distant beeps, a
clinic's air conditioning, bar murmur and glassware — plus the prop sounds belonging to a shot.
Add "No music."

In CapCut: music, whooshes, stings, the record scratch on the reversal, **and every caption.** The
karaoke captions on the reference videos are all post. The model cannot spell.
