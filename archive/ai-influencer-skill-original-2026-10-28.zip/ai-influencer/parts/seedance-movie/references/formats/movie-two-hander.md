# Format: movie two-hander

**The most proven format here** — twelve logged generations behind every rule below.

Two characters (plus at most one waiter, valet or bystander) in **one location**, almost all
dialogue, **one twist at the end**. Locked camera, polished look. 45–75 s, normally three clips.

**Not this format:** several locations, a cast of five, a fight, or anyone speaking to camera.
Multi-location stories are `movie-drama.md`.

---

## 1. Script

- **One location. No narrator. No exposition.** The twist at the end is the joke — never explain
  it, and never have a character react to it out loud.
- Two characters want different things and only one of them knows it. That gap is the scene.
- **One burst of energy per scene is enough.** The calm character gets a piece of business — a
  napkin, a glass, a phone face-down — while delivering the sharpest line. Stillness reads as
  confidence.
- A background character stays neutral. Neutral is funnier than reacting.
- Keep each character's voice and grammar exactly as written, including "wrong" grammar. Tidy the
  punctuation and nothing else.
- Don't over-tighten: 29 s of solid dialogue in one clip came back feeling rushed. 15–25 s.

## 2. The twist

It arrives in the last five seconds and recontextualises everything before it. Three shapes that
have worked:

| Shape | How it lands |
|---|---|
| **The reveal** | Something in frame turns out to mean the opposite. A focus rack to it, no line. |
| **The flat callback** | A line from the top of the scene repeated straight, now meaning something else. |
| **The quiet correction** | The confident one is corrected in one short sentence and does not recover. |

The twist should be **visible or audible, never explained.** If it needs a line to land, it isn't
built right yet.

## 3. Staging

Pick two to four setups and name them. Everything in the shots refers to these names:

```
ON HIM   — 85mm over her shoulder. Her <colour> shoulder and <hair> soft at the right edge of
  frame. He looks just off-lens toward frame right. <what is soft behind him>.
ON HER   — 85mm over his shoulder. His <colour> shoulder soft at the left edge of frame. She
  looks just off-lens toward frame left. <what is soft behind her>.
WIDE     — 35mm medium-wide from the end of the table. Him left, her right, everyone fully in
  frame, upper bodies visible, generous room on both sides.
INSERT   — 100mm on a prop. The voice continues over it.
```

- He is always frame-left, she frame-right, or the reverse. **They never swap.**
- 85mm close-ups for dialogue. 50mm mediums, waist up, when a third person is present.
  **Close-ups escalate, mediums release.**
- **One camera move per scene at most** — a slow push-in on the final shot, or a focus rack to the
  reveal. Prefer the rack; the camera stays put and it works first try.
- **Exit rule, always in STAGING:** *"When someone walks out of frame, the camera stays put: same
  framing, the empty space where they were, never a wider shot."*
- Never write "or" into a staging instruction.
- Don't stack a speaking character behind another.

## 4. Look

**POLISHED**, always — the full block is in `../prompt-layout.md` §5. This format lives in
restaurants, bars, hotel entrances and showrooms, and the gloss is the point.

Adapt the key light and the palette per setting, and keep the rest byte-identical:

- name the key, the fill and the rim explicitly
- **lifted soft blacks with shadow detail** — the line that stops it looking cheap
- one saturated accent per scene; say which surface is the brightest in frame
- windows and sunsets to the side or behind camera, never behind a face

Settings that have worked: an upscale steakhouse bar at night, backlit amber bottle wall as the
key. An oceanfront restaurant at dusk against a floor-to-ceiling glass wall. A beachfront hotel
entrance at sunset, low sun to the side plus wall sconces. A glass-walled car showroom at midday,
daylight from the glass with white bounce off the floor.

Write the location out in full every time. Never name a real venue.

## 5. Clip plan

Three clips of 15–25 s is the shape that works.

| Clip | Carries | Ends on |
|---|---|---|
| 1 | The premise and the first exchange | a question |
| 2 | The escalation — this is where the wanting shows | the line before the turn |
| 3 | The turn and the twist | the twist, then nothing |

**Four to five shots each, hard ceiling.** Rapid back-and-forth stays inside one clip. Every clip
starts and ends on a complete line.

Same-location continuity applies: the room will differ slightly between clips
(`../prompt-layout.md` §7). Put the cut where a new angle is expected anyway — after a reaction,
on a new speaker — and keep SETTING byte-identical regardless.

## 6. Sound

In the prompt: room tone ducked under every line — murmur, cutlery, glassware — plus the prop
sounds belonging to a shot: a fork set down, a chair scrape, heels, a menu closing, a pen on a
notepad. "No music."

In CapCut: the whoosh on a focus rack, the sparkle on jewellery, the record scratch on the twist,
the sting, and all music and captions.
