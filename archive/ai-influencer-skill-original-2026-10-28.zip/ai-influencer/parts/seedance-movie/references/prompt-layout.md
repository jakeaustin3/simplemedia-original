# Seedance 2.5 prompt layout: the rules every format shares

The core playbook. Format-specific rules live in `formats/`. When this file and a format file
disagree, **the format file wins for that format**.

Built from 19 logged generations (bar, dinner, hotel, helmet, vetting, starstruck). Every row in
§7 came from a clip someone actually paid for.

---

## 1. Hard limits

| Thing | Limit | Why |
|---|---|---|
| Clip length | 1–30 s per generation | Model cap. Anything longer is several clips stitched in CapCut. |
| Shots per generation | **4–5, hard ceiling** | 8 shots in 27 s collapsed into one repeated medium two-shot. See §7. |
| Speech | **~3 spoken words per second** in conversation, ~1.5 with action | Faster than you think. Never pad a 3-word line out to 3 s. |
| Locations | **One setting per generation** | A setting does not reproduce across generations. See §7. |
| References | Images named `@Image1…@ImageN` in upload order | File names mean nothing to the model. The order is everything. |
| Legible text | **Impossible** | No names, logos, price cards, QR codes, small print. See §7. |

**Cost.** 720p ≈ 63 credits/s, 480p ≈ 28 credits/s, audio included — these are kie.ai's logged
rates. On Leonardo or any other host, look up your own per-second rate and multiply by total
seconds. Always give the number before anything runs.

## 2. The break: turning a script into generations

This is the step people skip, and it is where most of the money gets wasted.

1. **Split on location first.** Every change of setting is a new generation, always.
2. **Then split on the 30 s cap**, aiming for 15–25 s.
3. **Then split on the shot ceiling.** If a chunk needs more than 5 shots, it is two generations,
   not one crowded one.
4. A clip starts and ends on a **complete line**. Never cut mid-sentence to finish it next clip.
5. **Rapid back-and-forth stays inside one clip.** Dialogue across a seam feels disconnected.
6. Under ~8 s, merge it into a neighbour rather than padding it.

### When the beats outnumber the shots

A fixed length buys a fixed number of shots: **a shot is one camera setup, and five is the
ceiling.** Two people answering each other in separate close-ups costs two shots — but the same
exchange held in **one WIDE costs one**. That is the cheapest way to buy a beat back, and it reads
as a release after a run of close-ups. Use it once per clip, never for a long speech (§7).

Count the beats first. When there are more beats than shots, cut in this order and stop as soon as
it fits:

1. **Transit and arrival.** Walking to the car, getting in, driving off, entering a building,
   sitting down. Cut these first, every time. The audience infers them for free, and they are the
   most expensive beats to shoot because nothing is said during them.
2. **Reaction-only beats.** A beat with no line rarely needs its own shot. Fold it into a
   neighbour as an action note on the face.
3. **The second of two beats doing the same job.** Two escalations, two refusals, two proofs —
   keep the stronger one.

**Never cut these, whatever the length:**

- **The opening accusation.** It is the hook, and without it the format does not work.
- **The turn** — the moment the situation reverses. This is the video.
- **The payoff or CTA**, when there is a product.

A cut beat does not have to vanish. It usually survives as **one action inside the shot beside
it**: a head tilted toward the car replaces walking to the car and costs nothing. Prefer that to
deleting it outright, and prefer both to writing a sixth shot.

**One scene, several generations.** When a single location runs longer than ~25 s it needs more
than one generation, and the room will change between them (§7). Three ways out, in order of cost:
- Write the scene so the cut lands where a new angle is expected anyway (after a reaction, on a
  new speaker), and keep the SETTING block byte-identical. Cheapest, imperfect.
- **Last-frame chaining:** pull the final frame of clip N and pass it as a reference image into
  clip N+1. Costs nothing extra to try. *Unverified — test it at 480p before betting a build on it.*
- Rewrite the scene to fit one generation. Always works.

## 3. Block order

```
Vertical 9:16 cinema-camera footage, full-frame look.   ← format line (format file may replace)

SETTING:      the location written out in full. Describe it, never name a real venue.
STAGING:      who stands where, which side of frame, eyelines, and the NAMED camera setups
              (ON HER / ON HIM / WIDE / INSERT). "Only N camera setups exist." Plus the exit
              rule: when someone leaves, the shot keeps its framing and never widens.
CHARACTERS:   one block per person. Locked characters point at @Image numbers. Everyone else
              gets a full written lock (age, height, build, skin, hair colour AND style,
              complete wardrobe including shoes).
PRONUNCIATION: every name, brand or unusual word, spelled how it should sound.
              e.g. Saoirse (pronounced SEER-sha). Required, not optional.
LOOK:         lenses, camera rules, light, palette, skin, capture. Pick a preset from §5.
AUDIO:        in-scene sound only, ducked under dialogue. "No music."
<NAME> in this clip:   one line per character: their attitude for THIS clip only.
SHOT n (m:ss–m:ss) — SETUP. action (face, hands, eyes). delivery note.
NAME: "line"
…
SAFETY:       stated, not implied.
EXCLUSIONS:   the negatives, including the shot count and the speaker rule.
```

Every block except "in this clip" and the SHOTs is **byte-identical across every clip of a
scene**. That is what makes separate generations cut together. Never write "same as clip 1" —
each job sees only its own prompt, with no memory of the last one.

Standing rules: no DURATION line. No logo or brand ban on wardrobe. No setting image and no
storyboard frame as a reference — character locks only.

## 4. Writing shots

- **Numbered, timed shots. The timings add up to the clip length.**
- Each shot, in this order: which named setup → what the face does → what the hands do → where
  the eyes go → the delivery note → the line last.
- **Spell out hands and their limits.** "Flicks his thumb back over his right shoulder. Thumb
  only, fingers curled, arm stays low. He does not turn around and does not stand." Vague
  gestures come back wrong every time — an index finger, or he stands up.
- **Name the side of frame** for every look and every exit. One side per person, all scene.
- **Prefer a focus rack to a pan.** The camera stays put and it works first try.
- **Inserts are their own shot** with their own lens ("100mm insert on the bottle"), with the
  voice continuing over them.
- Delivery notes carry intent, never volume: "genuinely offended, not shouting", "flat, certain,
  not a question".
- Numbers as words. "Twelve thousand", not "12,000".
- Wardrobe must allow the action. If a wrist has to show, write "right sleeve pushed up to
  mid-forearm" — a reference with sleeves down will fight it.
- **Never write "or" into a staging instruction.** See §7. Pick one and write only that.

## 5. Look language

Say what you want, then name the failure: "Faces fully readable in every shot. No one is
silhouetted against the sky."

**Lifted soft blacks with shadow detail** is the line that stops it looking cheap. Put windows and
sunsets to the side or behind the camera, never behind a face, unless fill is written in. One
saturated accent per scene — say which surface is the brightest.

### Two presets. Picking the wrong one is the difference between "an ad" and "someone filmed this".

**POLISHED** — restaurants, hotels, showrooms, bars at night. Anywhere aspirational.
```
LOOK, consistent across every shot: 85mm for close-ups, 100mm for inserts, 35mm for the wide.
Camera locked on a tripod, eye level, no handheld, no zooms. Shallow depth of field, T1.4–T2,
focus on the speaking subject's eyes, background in soft creamy bokeh. <key light>, <fill>, thin
warm rim on hair and shoulders. Medium-low key, lifted soft blacks, gentle highlight roll-off.
<palette>. Skin with natural texture and a satin finish, single soft catchlight. Clean digital
capture, zero grain, premium commercial grade.
```

**FLAT / REAL** — supermarkets, clinics, waiting rooms, offices, anywhere fluorescent. Everyday
places where the point is that this could be happening to you.
```
LOOK, consistent across every shot: 50mm for close-ups, 35mm for the wide. Camera at eye level,
very slight handheld float, no zooms, no stabiliser glide. Medium depth of field, T4 — the room
stays readable behind everyone. Flat overhead fluorescent light, no key, no rim, soft shadows
straight down. Even mid-key exposure, lifted soft blacks with shadow detail, no contrast
crushing. Desaturated everyday colour, nothing glamorous. Skin with natural texture, visible
pores, no smoothing. Clean digital capture, zero grain.
```

**Banned words** — cheap-looking or obviously AI. This list is backed by the logged runs; do not
add `cinematic` back in whatever another playbook says:
`photorealistic`, `hyperrealistic`, `8K`, `cinematic`, `cinematic lighting`, `dramatic lighting`,
`moody`, `bokeh balls`, `tack sharp`, `crisp`, `film grain`, `HDR`, `vibrant`, `vivid`,
`flawless skin`, `glossy skin`, `dewy`, `beautiful woman`, `stunning`.

## 6. Audio

- Seedance generates the dialogue and the in-scene sound: room tone, cutlery, a chair scrape,
  heels, keys, a laugh. Write those per shot in AUDIO.
- **No music in the prompt.** Generated music muddies the dialogue. Music, whooshes, record
  scratches, stings and sparkle "tings" all go on in CapCut.
- Audio must be ON for any clip with dialogue.
- **Captions go on in CapCut too.** The burned-in karaoke captions on every reference video are
  post. That is exactly why EXCLUSIONS bans on-screen text — the model cannot spell (§7).

## 7. Known issues: add a row after every run

| Issue | Seen | Fix |
|---|---|---|
| Frames tighter than specified; people cut off | bar | Pad every framing: "both fully in frame, upper bodies visible, generous room on both sides". |
| Too many words in a shot → rushed or dropped lines | bar 2 | Split the clip; move long speeches into their own close-ups. |
| A wide two-shot for a long pitch felt flat | bar 2b | Cut between over-the-shoulder close-ups instead. |
| Shot after a character exits goes WIDE and the room changes | dinner C, hotel | Exit rule in STAGING, plus in the shot: "same close-up framing as ON HIM, her empty chair in the right foreground, no wide shot". |
| Pointing comes back with an index finger / he stands up | dinner | Spell out the hand: thumb only, fingers curled, stays seated, does not turn. |
| Text-only side characters look different between clips | hotel | Lock them in full — age, build, hair colour AND style, skin, wardrobe including shoes — byte-identical every clip. |
| Two similar-looking characters blend into each other | coaching | Separate them on hair colour AND hairstyle, not one or the other. |
| Many shots in one clip collapse into a single setup | vetting 2–3 | **Cap a generation at 4–5 shots.** 8 shots in 27 s came back as one repeated medium two-shot with a blurred head parked in frame. The 4-shot clip held its 85mm over-the-shoulders exactly as written. Split into more, shorter clips — never more shots. |
| Dead air between lines; the scene drags | vetting 2–3 | Budget **~3 spoken words per second**, not 2.5. Time each shot to its line plus one beat and nothing more. 55 words in 27 s left ~5 s of gaps. |
| A prop handed between two characters glitches | vetting 3 | Avoid the handoff. Keep the prop in one person's hands throughout, or replace the exchange with a spoken line. |
| A locked side character came back in the wrong clothes | starstruck 2 | Text locks **do** reproduce — but only if you describe what the model actually produced, not what you originally asked for. A salesman written as "charcoal suit + lanyard" arrived in a gray polo; relocking him as the gray polo held him across every later clip. Generate first, then lock what you got. |
| A character drifted out of shot / stopped being staged | starstruck 2 | **Never write "or" into a staging instruction.** "out of frame or soft at the edge" gave the model an out and it took it. Pick one and write only that. |
| Close-ups died; the camera kept pulling back | starstruck | **Don't stack a speaking character behind another.** The camera widens to see them both. Give everyone who speaks their own clean eyeline to the lens. |
| Same room, different room | across all scenes | **A setting does not reproduce across generations**, even with a byte-identical SETTING block. Same world, not the same room. Plan the cut to land where a new angle is expected, or test last-frame chaining (§2). |
| Names, logos, signs came back as letter-shaped gibberish | starstruck, all | **Seedance cannot render legible text.** Design any payoff to read by SHAPE — a bottle silhouette, a colour, a gesture — or composite the real graphic in post. |
| Job sits in the queue 70+ min and the client gives up | hotel | The task is NOT failed. Resume polling the same task ID. Never resubmit — that is a double charge. |
| Upload 404s or fails with a TLS error | bar 3 | Transient, nothing is charged. Retry. |
| A text-locked lead came back as a famous actor | cologne, airplane | **Text alone cannot keep a lead off a celebrity face. Image-lock anyone the story depends on.** The cologne lead returned an unmistakable Michael B. Jordan. The airplane clip then tested the proposed fix — one specific un-famous detail, "a deep vertical crease between his brows" — and came back as an unmistakable Steve Carell. **The distinguishing-detail fix does not work.** What did reduce the pull was describing someone the casting pool is thin on: the heavy, balding, bespectacled passenger in the same clip came back as nobody in particular. So conventionally attractive lead + text lock = a famous face, every time. |
| Big label type reproduced from a product reference | airplane | An image-locked product tub came back correct — shape, white body, teal band, droplet — and **the large bold type on the label was mostly legible** ("BILLION PROBIOTIC"). The can't-render-text rule applies to text the model must invent. Text it can **copy from a reference image** reproduces far better, especially large bold type. Still composite the real label for anything that must be exact, but a product reference gets you most of the way. |
| A speaking character ended up stacked behind another in a WIDE | airplane | A WIDE specified as "from four rows ahead at standing height" was read as looking **down** the aisle, which put the standing attendant behind the seated passenger instead of beside him. In a corridor — a cabin, a train, a hallway — a wide down the length of it stacks people by depth. Say the camera is **across** the space, not along it, and name who is left and who is right inside the WIDE description itself. |
| A framing ban was only half honoured | airplane | "The camera never frames him below the chest" still returned waist-up framing. A negative about framing is weaker than a positive one. Write the framing you want — "framed from the shoulders up in every shot" — and put the ban in EXCLUSIONS as well. |
| A wardrobe override held four times and broke on the fifth | bar | The `USE FACE AND BODY ONLY — wardrobe is replaced below` pattern, with the old outfit in EXCLUSIONS, held a character in a replacement outfit across four generations and then reverted to the reference's own clothing in the fifth — a bar scene in gym clothes. **Budget a reroll for any override.** It failed in the clip where that character had only one of five shots, so reinforce it inside the shot line as well ("in her black wrap dress") rather than relying on the CHARACTER block alone. Note the reference's clothing also suppresses the body: the replacement dress read slimmer than the reference did. |
| Named setups plus a five-shot cap fixed the "looks fake" problem | bar | The same scene previously generated elsewhere as **ten shots with ad-hoc framings, a doubled lighting block and "premium drama grade"** came back plastic and posed. Rebuilt as five shots with declared, reused setups, a single key/fill/rim description and no grade adjective, it reads as real footage. Ranked by impact: shot count first, named setups second, look language third. Reference images changed **who** the people were, not how real it looked. |
| A low-key interior looked mushy where a flat interior looked real | bar vs flight | Both builds were five shots with named setups, so structure was not the difference. The **flight** (FLAT/REAL: 50mm, T4, even overhead light, medium depth) came back clean and readable. The **bar** (POLISHED: 85mm, T2, medium-low key, warm amber) came back with a third of some frames taken up by an out-of-focus foreground shoulder and large crushed-black areas. **Shallow depth of field over-the-shoulder needs resolution to pay off** — at 480p the bokeh has too few pixels to read as bokeh and reads as smear. Do not stack low key + T2 + over-the-shoulder in a dark interior: lift the key, open to T4, or shoot cleaner singles. A bright exterior at T2 (cologne) had no such problem. |
| A fine repeating pattern survived on an image lock | bar | A black-and-gold brocade blazer — the kind of high-frequency pattern that shimmers and morphs when described in text — reproduced cleanly across two generations when it came from a reference image. The banned-pattern advice applies to text locks; an image lock can carry one. |
| The premise was not visible; "very heavy" came back as merely heavy | flight | **Describe the premise as geometry, not as an adjective.** "Very heavy build, full round face, soft double chin" produced a heavy woman, not a woman who cannot fit in a seat — so the accusation had nothing to point at. Adjectives get rounded down. Spatial facts do not: "her hips and thighs fill the aisle seat completely and continue past its edge into the middle seat, so the middle seat cannot be sat in; the seat belt is at full extension." Write the relationship between the body and the object, in every shot that needs it. |
| A crowd reaction looked choreographed | flight | **Direct a crowd as a state, not as an action.** "First one head and then a whole row of heads turn" came back looking like a dance number. "Several passengers in the rows behind are already watching her" reads as a room caught mid-moment. The same applies to the accuser: a held, described gesture ("lifts one open hand toward the bin and holds it there") looks staged. People delivering bad news mostly do not move. |
| The product appeared in scenes it was never meant to be in | flight | **A prop's block and its reference image go ONLY in the clips where the prop appears.** The probiotic tub was described in the byte-identical CHARACTERS block and attached as @Image1 to all four generations, so the protagonist is holding it in her lap during her own humiliation — twenty seconds before the character who introduces it has spoken. Byte-identical means identical **for what is in the scene**. Anything absent must be absent from the prompt and unattached, or the model will stage it. |
| Wardrobe held across four generations, faces did not | flight | Four generations on text locks: **every garment reproduced exactly** — burgundy fitted top, oatmeal cardigan, navy waistcoat and red scarf — while **faces and hair drifted badly**. The same character went from full dark curls in clip 3 to a short gray crop in clip 4. So a text lock is a costume, not a face. Image-lock anyone who appears in more than one generation; text-lock only single-clip characters, and lean on wardrobe to carry the recognition. |
| A product label read clearly at 480p | flight | With a reference image and a 100mm insert, "60 BILLION PROBIOTIC" came back legible at 480p. Confirms the narrower rule: text copied from a reference reproduces; text the model must invent does not. An insert is the shot to spend on it. |
| A text-locked prop changed shape mid-clip | cologne | **Props need an image lock, not a description.** The cologne bottle was a small red bottle with a red cap in shot 3 and a larger bottle with a gold cap and gold panel in shot 5 — inside a single generation. Words hold a person across clips; they do not hold an object across shots. Any product that has to be recognisable gets a reference image. |
| The background changed between setups inside one clip | cologne | Setting drift is not only a cross-clip problem. Shot 3 was open pavement and palms; shot 5 had a white colonnade. Within a clip this reads as a different part of the same street and is usually acceptable — do not fight it, and never make a story point depend on what is behind someone. |
| Wardrobe override reverted in 1 of 3 clips; glasses dropped | ai-factory | Text override (ivory suit over a black-tee lock) held in gens 1–2 and reverted to the black tee in gen 3; glasses held in gen 1 only. **Give the lead a lock image already wearing the outfit** instead of overriding, and name glasses in every shot line. Invented UI text was partly legible ("$2,000") — never put a number on a screen you don't want read. |

Also carried over: a slap reads as violence where a grab reads as comedy; add "nobody is hurt" to
any fall or collision; and when a job comes back blocked, **change one thing** and retry, so you
learn which thing it was.
| Face-lock outfit leaked into one clip of two | the character office 3+4 | Clip 3 held the olive outfit image, clip 4 came back in the white embroidered blouse from the face close-up lock. **A face lock carries its own outfit.** When the outfit differs, send the outfit image only (it shows the face too), or write `@Image1 FACE ONLY` plus the face shot's outfit in EXCLUSIONS. |
