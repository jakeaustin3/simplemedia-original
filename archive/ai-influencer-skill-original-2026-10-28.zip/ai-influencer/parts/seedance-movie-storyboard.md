
# Seedance movie storyboard

Approved script + cast in → one board of key frames out. **One question per message.**

## 0. Before anything: check cast + wardrobe are settled

Every character who appears has: a face (kit lock, a supplied photo, or a new lock made now),
**and an answered wardrobe question** (never default the lead to the kit outfit). Extra people
(assistants, extras) have images or a one-line description. If anything is missing, ask it first
(one question each). A storyboard made before the wardrobe is decided gets redone.

## 1. Ask how to make the frames

> "Do you want me to generate the storyboard frames for you in Higgsfield (about 2 credits a frame,
> ~20 for a whole video), or give you the Nano Banana Pro prompts to paste into Google Flow
> yourself? In Flow you'd attach the reference photos by hand for each frame, easy with 1–2
> people, fiddly with 4+."

Recommend generating when 3+ characters are in the video.

## 2. Pick the frames: lean

- One frame per **new setup** (new place, new person, new key action). Never the same person or
  setup twice. A 60–90s video is usually 8–10 frames.
- Group them by Seedance generation (one generation per location, ≤30s, ≤5 shots).
- Include the insert only if a prop carries the story (a phone screen, a product).
- No dialogue on the board. Labels only: `1 Lobby`, `2 Erick: Phone`…

## 3. Write each frame prompt

`Cinematic movie still, vertical 9:16.` + setting (byte-identical per location) + who, with
"the man/woman from image N (same face, <wardrobe>)" + action + framing (wide / 85mm close-up /
insert) + light from the look block (`parts/skit/references/look-blocks.md`) + `No text.`
Attach only the people in that frame. Never put a number on a screen you don't want read.

## 4. Generate (if chosen)

Higgsfield `generate_image_batch`, model `nano_banana_pro` (it may run as Nano Banana 2; fine
for boards), role `image_references`. Upload local refs with `media_upload` → PUT with
`-H "If-None-Match: *"` → `media_confirm`. Save to `<video folder>/storyboard/0N_frame.png`,
stitch a labelled contact sheet `storyboard_sheet.jpg`, send it.

## 5. Review

Look at the sheet before sending: faces held? wardrobe right? anything crowded? Say what you'd
fix in 2–4 bullets, then one question: change frames, or go to prompts (`parts/seedance-movie.md`).
Keep the old version in `storyboard/v1/` when redoing.
