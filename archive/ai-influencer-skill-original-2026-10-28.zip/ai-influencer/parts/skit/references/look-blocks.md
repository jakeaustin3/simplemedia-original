# Skit look blocks (from AI Influencer Part 1 05-skits.md §1.2 + §7.4)

The student's movie/iPhone pick OVERRIDES parts/seedance-movie.md's location preset (movie-drama.md §6). Paste the block verbatim into LOOK, fill every bracket.

### 1.2 Movie look or iPhone look (Seedance scenes only)

The talking part of a mix is **always iPhone** (`07`). This choice is for the skit only.

| | MOVIE LOOK | IPHONE LOOK |
|---|---|---|
| Feels like | a short film, a TV drama | someone nearby filming on their phone |
| Camera | locked on a tripod, lens per shot size, one slow push-in at most | handheld by a named bystander, reactive, drifts and corrects |
| Focus | shallow, background soft | deep, everything sharp |
| Light | soft, motivated by a named source in the room | bright, even, daylight from the side |
| Cuts | shot and reverse shot, close-ups escalate | fewer cuts, wide and medium, the room stays readable |
| Best for | full skits, emotional drama, confrontations, restaurants, offices | mixes, public places, accidents, stores, gyms, parking lots |
| Look block | §7.4 MOVIE | §7.4 IPHONE |

**If the student says "you pick":** full skit → movie. Mix → iPhone, so the cut into the
talking part does not jump in style.

### 7.4 Look blocks

Each block carries the look, the light and the camera. Fill every bracket for this scene.

**MOVIE LOOK**
```
LOOK, consistent across every shot: 35mm for wides, 50mm for mediums, 85mm for close-ups, 100mm macro for inserts. Camera locked on a tripod, eye level. One slow push-in only, on the final shot. No handheld, no zooms, no orbit, no dutch angles. Shallow depth of field on faces, smooth soft background falloff, focus on the speaking subject's eyes. Soft motivated light from [this place's named light sources], key from [the side it comes from] slightly above eye level, soft fill from [a named surface], thin warm edge light on hair and shoulders. Faces fully readable in every shot. [Exteriors at sunset: No one is silhouetted against the sky.] Medium-low key with lifted soft blacks and shadow detail, gentle highlight roll-off on [the brightest thing in frame]. Palette of [four or five colours actually in this place]; [one wardrobe piece] is the single saturated accent. Skin with natural texture and a satin finish, single soft catchlight. Clean digital capture, zero grain. Premium drama grade.
```
If nobody's wardrobe is saturated, replace the accent clause with the darkest and brightest
things in frame (*"the black car is the deepest tone; her white sundress is the brightest
surface"*).

Never write in a movie prompt: `photorealistic`, `hyperrealistic`, `8K`, `cinematic
lighting`, `dramatic lighting`, `moody`, `rim light`, `glowing`, `bokeh balls`, `tack sharp`,
`crisp`, `film grain`, `35mm film`, `deep blacks`, `crushed shadows`, `high contrast`,
`vibrant`, `vivid`, `HDR`, `flawless skin`, `glossy skin`, `dewy`, `handheld`,
`dynamic camera`, `zoom in`, `vignette`, `beautiful woman`, `stunning`.

Movie shot grammar: close-ups raise the pressure, mediums release it. Use the pattern on
purpose. The two lines that stop it reading cheap: named light sources, and lifted blacks
with shadow detail.

**IPHONE LOOK**
```
LOOK, consistent across every shot: Filmed by [a bystander, placed: another shopper standing further down the aisle]. The camera is reactive and moving: it follows the action, steps in and out with the operator's feet, drifts and corrects, and reframes late on cuts. Keep the movement steady and readable, not violent. Eye level throughout. No stabilization, no gimbal smoothness, no digital zooms, no crane or drone moves, no tripod steadiness. Bright, even, well lit: [daylight / the store lights] from the side, falling across the front of everyone. Faces bright and fully exposed. No backlighting, no silhouette, no dark or underexposed subjects. Candid documentary realism, like unedited footage straight off the camera roll. Natural skin texture with pores, lines and imperfections. Deep focus, everything sharp front to back. No beauty smoothing, no color grading, no lens flare, no shallow depth of field, no film look.
```
Windows and bright doorways go to the side of the subject, never behind them.

Never write in an iPhone prompt: `cinematic` (not even as a negative), `bokeh`,
`shallow depth of field` as a goal, `film grain`, `35mm film`, `moody`, `dramatic lighting`,
`beautiful`, `stunning`, `flawless skin`.

---

