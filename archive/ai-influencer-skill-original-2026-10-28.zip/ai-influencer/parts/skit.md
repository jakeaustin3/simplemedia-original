
# Skit

Follow `rules/DOORS.md`: you lead (when a step is done, say so and offer the next), prompts never go out as a file (one prompt in the chat, many on the storyboard page), reference images go to Downloads numbered.

Idea (or script, or a pulled reference) in → approved script/storyboard → Seedance prompts
(+ Flow or Kling prompts for the rest when only the hook is Seedance).

**One question per message.** Never stack a second question at the bottom.

Reads: `references/look-blocks.md` (movie vs iPhone). Hands off to `parts/seedance-movie.md` for the
break and the prompts. That skill's `references/prompt-layout.md` §7 is the known-issues list.

**Animated skit** (from the Animation project): the picked look's Seedance look line + LOOK block from
`rules/animation/LOOKS.md` replace the movie / iPhone blocks; still prompts end with its look tail.


---

## 1. Route (one question each, skip what's already answered)

The student arrives (from the start of this skill) with a script, the characters and the product. This door
**refines the script into a screenplay**; it doesn't write it from scratch.

1. **Style:** **movie style** (tripod, shallow focus, motivated light, shot/reverse shot) or
   **iPhone style** (a bystander filming, handheld, deep focus, bright even light). Animated skits
   from the Animation project skip this (movie style by default, with the look's blocks). If `creator.txt` in
   the video folder is set, take the style from its **Visual recipe** and confirm in one line.
2. **How do you want to make it?** List them in this order, with the note:
   - **Seedance hook, then the rest in Google Flow** (most popular; recommended).
   - **Seedance end to end** (best quality, the most expensive; say the rough credit cost now).
   - **Images animated in Kling** (Claude does it for you): stills in GPT Image or Nano Banana Pro on
     Higgsfield, each animated in Kling, then stitched.
   - **Google Flow end to end** (the hardest; not recommended). Hand off to `parts/flow-skit-storyboard.md`
     for the whole build.

## 2. Refine the script into a screenplay

Take their script and fill in everything a good video needs. Propose it all; ask only for what you
can't work out from the script, the characters and the product (one question per message):

| | |
|---|---|
| Style | movie or iPhone (from step 1) |
| Cast | who is in it (main character, side characters) |
| Product | what's being sold, if anything (product kit) |
| Settings | every location, described in detail |
| Story | the narrative and its **beats**, the turn, the ending/CTA, **how long the video is** |
| Dialogue | who says what, word for word |
| Expressions | faces, body language, reactions per beat |
| What the audience sees | angles, framing, when it cuts |
| Voices | the tone of each voice |
| Tone + pace | the tone of the whole story, the speed and pacing |
| Sound | music, sound effects (optional) |

## 3. The script table (approve before anything else)

The screenplay laid out as one table, **one row per beat** (one moment of the story). Used for every
route: Seedance, Flow and Kling.

| # | Seconds | Shot (size · angle · camera) | Who / action / expression | Dialogue | Sound | Model |
|---|---|---|---|---|---|---|

- ~3 spoken words per second; count them (`parts/seedance-movie.md` script rules).
- "Model" column = Seedance, or Flow / Kling for the rest when only the hook is Seedance.
- **Seedance: ask how it breaks up.** Give the options for its length (a 60-second video: 2 × 30 s,
  3 × 20 s or 4 × 15 s) and recommend one. Each generation holds **at most 5 shots** (tested: 8 shots
  in 27 s came back as one repeated shot), so pick the split that keeps every part at 5 or fewer.
  A new location starts a new generation.
- **Stop and wait for approval.**

## 4. Outfits and characters (before any storyboard)

**Ask the outfit per person, one question each** (main character first: a kit outfit or something
new?). Then make **every person, main character included, wearing that exact outfit**: the main
character from their kit locks, everyone else through `parts/side-character.md`. These outfit images go in
the reference box of every image and clip. Never default the lead to the kit's default outfit.

| Situation | What they need |
|---|---|
| **One Seedance generation** (≤30 s) | The outfit images are still made (they keep the look right). One-scene extras can be described in the prompt instead (`parts/seedance-movie.md` character-lock §2). |
| **Two or more generations**, or Seedance → Flow/Kling | Outfit images for everyone who appears in more than one generation or crosses models. |
| **Setting** | No setting lock. Write one detailed SETTING block per location (layout, named light sources, colours, fixed props) and paste it **byte-identical** into every generation and every Flow/Kling prompt in that place. |

## 4b. Storyboard

Run `parts/seedance-movie-storyboard.md` (key frames, generate or Flow prompts). Approve before prompts.

## 5. Prompts

- **Seedance part:** run `parts/seedance-movie.md` from its phase 2 (break), with the approved table as the
  script. LOOK = the block from `references/look-blocks.md` for the student's pick, which overrides
  the location preset.
- **Hook only, rest in Flow:** when the hook frames are done, say "Next: your Flow storyboard for the rest." The rest goes through `parts/flow-skit-storyboard.md` (one still per beat,
  Omni clip per ~10 s / ~30 words). First still = last frame of the Seedance hook (screenshot it)
  + the character lock.
- **Hook only, rest in Kling:** one Nano Banana Pro still per beat (same anchor rule), one Kling
  prompt per ≤15 s clip, carrying the same SETTING block and the iPhone/movie look in plain words.
- **Images animated in Kling (whole skit):** the same as the Kling rest, from the first beat: one
  still per beat (GPT Image or Nano Banana Pro on Higgsfield, the outfit images in the box), one Kling
  prompt per ≤15 s clip. Claude runs it after showing the cost.
- Seedance runs: "Do you want me to run it for you on kie.ai or Higgsfield, or will you paste the
  prompts into the tool you use?" Show the cost first; suggest one clip at 480p for a new build.
- **Flow parts:** the student runs them by hand from the `parts/omni-storyboard.md` page.

## 6. After the run

Stitch every clip in story order with `parts/stitch.md` (Seedance generations, the hook and the Flow or Kling
rest), then the ending from the start of this skill: captions on the video, post caption, save.

