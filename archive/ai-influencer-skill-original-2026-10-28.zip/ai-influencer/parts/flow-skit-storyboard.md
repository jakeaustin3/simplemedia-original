
# /flow-skit-storyboard <script or teardown folder>

Not the same as `parts/omni-storyboard.md` (talking head, one person to camera). Same page builder
(`tools/omni_board.py`, `cast:<Name> face + body` slots in the box), skit rules.

Tested on two skits (a remake of a Video Database skit and an original dinner-date skit) and a dinner-scene test.

## Mixed videos
A skit hook into a different body (e.g. skit hook → recipe) follows each part's own rules: the hook
by this sheet, the body by that style's rules and storyboard (recipe = `parts/omni-storyboard.md`).
Side characters: `parts/side-character.md`.

## Animated skit (from the Animation project)
Every image prompt ends with the picked look's **look tail** from `rules/animation/LOOKS.md` instead of
the iPhone or movie line; every clip prompt adds that look's motion note. Characters are made in the look first.

## Order (ask everything before the storyboard; never go back to it)
Skip anything the start of this skill already settled (growth or product, cast, script): read `script.md` and the character kits.
1. (Settled) Growth or product.
2. Cast, only who is missing. Main character from a kit or a side character. Anyone in more than one setting gets a
   face + body lock (Nano Banana Pro prompts, plain cream studio backdrop; face first, then body
   with the face in the box). One-scene extras are described in the prompt.
3. Outfit for every character, one question each .
4. Script. Rough lines in, clean script out: lines per character, about 3 words per second,
   grouped by setting, split into 10 s clips.
5. Settings: one SETTING block per place, pasted word for word into every prompt there.
6. Look: movie or iPhone (if `creator.txt` in the video folder is set, take it from its **Visual recipe** and confirm in one line).
7. Then build the storyboard once (`tools/omni_board.py`, `cast:` slots in the box).

## Storyboard rules
- **One scene = one 10 s clip** when it fits. Don't split an action scene into several images;
  it comes out choppy. Fast, one continuous take, cuts written inside the prompt ("Cut to: …").
- One master image per setting. Later images in that setting get the master in the box.
- Going back to a setting = reuse its start image.
- **Anyone who speaks or gets a close-up in a clip must have their face visible in that clip's
  start image.** A clip that started over a man's shoulder and cut to his face lost his glasses.
  Wide two-shots cut to close-ups kept both faces.
- Dialogue longer than 10 s: the next clip starts on the start image that shows the next speaker.
- No contact or force words (slap, slam, shove, grab, hit): Flow blocks them. Use "leans in",
  "steps between them", "takes her hand", "grips the wheel".

## After the run
Join the clips whole, in story order, each with its own audio. No trims, no speed-up, no music
unless asked (`parts/stitch.md` skit rule). The user edits.

## Prompt rules from the review of "The Date"
Worked: the opening meet, "It's on me, I got us", the hand pat ("don't be shy"), the bill reveal
($2,000 came out clean), the Chad phone call, her leaving.
- **No camera moves in iPhone skits.** No push, zoom, pan or pull. Handheld and still; the cuts do
  the work. A push on her face looked too cinematic and too perfect.
- **Delivery = nonchalant and quick.** She sounded like a voice model. Write lines the way people
  talk: lists with commas, not full stops ("The lobster, the wagyu, the caviar, and your best
  champagne"), and say "says quickly, casually".
- **Name the speaker every time** ("the woman says", "the man with glasses says", "the waiter
  says"), never He/She. In the bill clip the lines went to the wrong person.
- **Cut extra stage directions:** no head tilts, glasses pushes, "writes quickly", "not at him".
  Only the action the story needs.
- **List the props in the start image and don't add new ones.** A champagne bottle appeared
  mid-clip.
- **Lines go to whoever would really say them** (the waiter asks "What can I get you guys?").
- **Blocking with walking and doors doesn't follow the prompt** (he backpedalled, she walked to a
  pillar). Keep one simple move, or give the move its own clip.
- **Drop clips that don't move the story** (the card fumble).
- **A phone call stays in one clip**: question, answer, her quick "Okay, sure." No pause-and-shrug.

## Clip prompt template (v2 of The Date, approved)
`The camera holds steady, handheld. [Props line if the table matters.] [One small action from the
still.] The woman says in a standard American accent: "[line]" Cut to the man with glasses. The man
with glasses says in a standard American accent: "[line]" Natural movement, natural audio.`
- No delivery words (nerdy, sarcastically, flatly). Google handles delivery (`rules/ai-influencer-prompting/07-recreation-engine.md` §7.4).
- Only continue the action the still already shows; no invented gestures.
- Don't describe the people in the clip prompt; name them by a short label only.

## Open: glitchy motion
Some clips glitched in Omni. Likely cause: the skit prompts break the Omni rule "one simple action,
minimal hand movement" (patting hands, fumbling a card, standing up and walking off, several cuts
each with its own action). To try next: one small action per shot, hands mostly still, a person
leaving = walks out of frame in one move, no hand-offs. Also vary the start image per clip (her
side, his side, the waiter's view) instead of reusing one two-shot.
