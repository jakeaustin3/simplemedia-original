
# /setup-storage

Every video gets ONE folder, from parts/pull.md or parts/breakdown.md to the final edit:
`Videos/<Character>/<YYYY-MM>/<Video topic>/` (original, clip map + storyboard, script, Omni storyboard link, images/, clips/, final.mp4).
Spec: `rules/STORAGE.md`.
Tool: `python3 ~/.claude/skills/ai-influencer/scripts/storage.py` (settings in `~/SimpleMedia/settings.txt`).

## Onboarding (first run, like an app). ONE question per message.
1. Check `python3 ~/.claude/skills/ai-influencer/scripts/storage.py status`. If set up, say where and stop.
2. Default = **Google Drive** is the organized home; finished files they want (e.g. a Seedance video) are also dropped in **~/Downloads**. No folder structure on the computer. Ask only: **"Can I connect your Google Drive so every video gets its own folder there?"**
3. Drive needs the student's Video Database sheet connected (`~/SimpleMedia/settings.txt` has `SHEET_SCRIPT_URL`). If it isn't connected, don't send them hunting: offer **this computer** instead (`storage.py setup --mode computer`, folders in `~/SimpleMedia/Videos/`). They can connect Drive later.
4. Run `python3 ~/.claude/skills/ai-influencer/scripts/storage.py setup` (mode drive). Show the Drive link and the size heads-up from `python3 ~/.claude/skills/ai-influencer/scripts/storage.py estimate 150` (~80 MB per video, ~12 GB per 150 videos; Google free = 15 GB).
5. Offer once, don't push: "I can also keep the same folders on your computer." Yes → `setup --mode both`.

## During a video (every skill)
- As soon as the character and topic are known: `python3 ~/.claude/skills/ai-influencer/scripts/storage.py folder <Character> "<Video topic>"` and write everything into that folder. Topic = short plain name ("Cinnamon banana drink"), no date.
- Never keep a second copy on the same computer. Drive + computer is fine.
- From a Video DB row: also note the row number in `video.json` (`"row": N`).

## Save at the end
When the final video is done, ask: **"Save this video to Drive?"** (skip the question if mode = computer). Then `python3 ~/.claude/skills/ai-influencer/scripts/storage.py save "<video folder>"` (in drive mode it clears the local working copy after a clean save). Files over 35 MB are listed: drag those into the Drive folder by hand. Anything the student wants to keep on the computer → `python3 ~/.claude/skills/ai-influencer/scripts/storage.py deliver <file>` (goes to ~/Downloads).
