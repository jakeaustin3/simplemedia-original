
# /add-to-character · one image → the right folder + a bible row

Kits live in `Kits/Characters/<slug>/` (locks/ · outfits/ · environments/ · shots/ · products/ · bible.md · character.md). Environments and shots are the two folders that grow over time; this skill is how they grow.

## Rules
- **One question max.** If the character or the type is unclear, ask one thing. If the image and the student's words make it obvious, ask nothing.
- **Never invent.** The bible row describes what is in the picture. Unknowns stay blank.
- **Someone else in the picture is fine.** A location or a framing can hold another person; file it with "Person in it: someone else (swap)". The character gets swapped in at generation time using her locks as reference. Never file another real person's face as a lock.
- **No credits without a yes.** Filing is free. Regenerating the picture with the character swapped in costs credits; offer it, do not do it unasked.

## Step 1 · Take the image
- Chat drop: the file is in this session's images folder (the path Claude Code shows for the attached image). Path or URL: read it from there. Higgsfield result: `python3 ~/.claude/skills/ai-influencer/scripts/kit_tools.py fetch <url> <dest>`.
- Look at it (Read tool) before filing. One line back to the student: what you see.

## Step 2 · Decide the type (ask only if unclear)
| The student says / the picture shows | Folder | Bible section |
|---|---|---|
| an outfit, "save this look", the character full body in clothes | `outfits/` | 5 · Wardrobe, one row: file · outfit name · full prompt description |
| a place, a room, a car, a street, "add this location" | `environments/` | 6 · Setting, one row: file · place · full prompt description (objects, colors, light) |
| a framing, a selfie angle, a pose, a shot type, "I like how this is shot" | `shots/` | 13 · Shots, one row: file · shot · what to copy (framing, lens, angle, light, pose) · person in it |
| a new angle of the character on a plain wall | `locks/` | 4 · Locks (only if it is her face; a state folder before/ after/ if the character has states) |
| a product she holds | `products/` + `Kits/Products/<product>/images/` | Products line |

## Step 3 · File it
- Convert to JPEG if needed (results come as PNG bytes). Name: next number + descriptive slug, e.g. `outfits/06_red_bikini_set.jpg`, `environments/04_nail_salon_chair.jpg`, `shots/01_car_selfie_low_angle.jpg`.
- Append the row to the bible table. Keep the table's columns. Add `(added 2026-MM-DD, from: <where it came from>)` at the end of the description.
- If the picture shows a different person, add "Person in it: someone else (swap)" and, for outfits, note that the outfit description is what gets reused, not the person.

## Step 4 · Confirm and offer
One line: "Filed as `<path>`, row added to section N." Then, only if it applies: "Want her in it? I can regenerate this shot with your character for 2 credits." If the student says yes: `nano_banana_pro`, 9:16, references = her `locks/01_front_full_body.jpg` (upload with `media_upload` → curl PUT with `-H "If-None-Match: *"` → `media_confirm`) plus the filed image, prompt = "Same woman as reference 1, identical face and body, placed in the scene of reference 2, same framing, same light, same pose, the other person removed". File the result next to the original as `<name>_<name>.jpg` and add it to the same row.

## Optional · board
