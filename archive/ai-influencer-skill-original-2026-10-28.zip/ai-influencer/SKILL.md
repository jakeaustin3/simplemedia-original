---
name: ai-influencer
description: Make an AI influencer video with your character - a talking head (a recipe, a product in a store, explaining something, an interview) or a skit (several people acting out a little story, movie style or iPhone style). Asks one question at a time - who's in it, copying a video or your own idea, the script - then builds the storyboard with every prompt, runs it or hands it to you for Google Flow, and stitches the clips. Use when the student says "/ai-influencer", "make an AI influencer video", "talking head video", "recipe video", "explainer video", "product authority", "interview video", "skit", "make a skit", "movie style video".
---

# /ai-influencer

> **How this skill is laid out.** Everything this skill needs sits in its own folder,
> `~/.claude/skills/ai-influencer/`: `parts/` (instructions you read only when a step calls for them),
> `scripts/` (run them as `python3 ~/.claude/skills/ai-influencer/scripts/<file>`), `rules/`.
> The student's own things live in `~/SimpleMedia/`: `Kits/Characters/`, `Kits/Products/`,
> `Kits/Side Characters/`, `Videos/` and `settings.txt`. In every part, `tools/` means this skill's
> `scripts/`, `Kits/` and `Videos/` and `settings.txt` mean the ones in `~/SimpleMedia/`, and a skill
> name like `/stitch` means `parts/stitch.md`.

**One question per message.** Offer your best guess. Follow `rules/DOORS.md`: you lead (when a step is
done, say so and offer the next), prompts never go out as a file, reference images go to Downloads.

## First time only
Run these three checks before anything else, each on its own (say what you're doing in one line):
1. **Folders:** if `~/SimpleMedia/` is missing, make it:
   `mkdir -p ~/SimpleMedia/Kits/Characters ~/SimpleMedia/Kits/Products "~/SimpleMedia/Kits/Side Characters" ~/SimpleMedia/Videos`
2. **Settings:** if `~/SimpleMedia/settings.txt` is missing, copy `~/.claude/skills/ai-influencer/settings.example.txt` to it.
   (Check this even when the folder already exists.)
3. **Where videos are saved:** if `~/.simple-media/storage.json` is missing, run `parts/setup-storage.md`
   onboarding now, so the student connects **their own** Google Drive (or picks this computer). Never use
   or mention a Drive that isn't theirs.
Works on Mac and Windows: check which one the student is on first. Check `ffmpeg` and `python3` are installed (on Windows, `python` if `python3` isn't found, and use that name for every command in this skill). If ffmpeg is missing: Mac `brew install ffmpeg` (install Homebrew first if needed), Windows `winget install -e --id Gyan.FFmpeg` and then open a new terminal.

**No characters yet?** If `~/SimpleMedia/Kits/Characters/` is empty, don't ask which character and never
name characters from anywhere else. Say: "You don't have any characters yet. Let's create your first
one." and go straight to the New Character skill (`/new-character`, installed separately).

## Steps (say where you are; when one is done, offer the next)
1. **Talking head or skit?**
   - **Talking head:** one person talking to camera. A recipe, a product in a store (product authority),
     explaining something, or an interview (someone asks, the character answers).
   - **Skit:** several people acting out a little story.
2. **Is it selling a product?** Yes: ask for the product's name, a clear photo and the link (or its kit in
   `~/SimpleMedia/Kits/Products/`). No: it's a growth video.
3. **Who's in it?** List the kits in `~/SimpleMedia/Kits/Characters/` (only those). A new one:
   the New Character skill (`/new-character`, installed separately). Anyone in more than one scene (skits): `parts/side-character.md`.
4. **Copying a video, or your own idea?** A Video Database row: `parts/pull.md`. A link or a file:
   `parts/breakdown.md`. Own idea: a sentence or two about it. Make the video folder:
   `python3 ~/.claude/skills/ai-influencer/scripts/storage.py folder <Character> "<Video topic>"`.
5. **The script:** `parts/script.md` (keeps theirs, remixes a copied one, or writes options).
6. **Open the door:** talking head → `parts/talking-head.md`. Skit → `parts/skit.md`.
7. **The ending:** stitch the clips (`parts/stitch.md`), captions if they want them, a post caption in the
   character's voice, and save (`parts/setup-storage.md`). The student edits anything else in CapCut.
