# Student storage (spec, 2026-10-01, Erick)

Set up at the very start (onboarding, first time the student opens the repo), like an app:
1. "We need a place to save all your videos. Connect Google Drive?" → connect (or computer only).
2. Ask: save to **Google Drive**, **this computer**, or **both**. Remember the answer.
3. Create the root `Videos/` folder.

## Default (2026-10-01): Drive = organized home; finished files also go to ~/Downloads; no computer folder structure unless the student asks.

## Layout
```
Videos/
  <Character>/            the character, your character …
    <YYYY-MM>/            one folder per month (60–90 videos fits fine)
      <Video topic>/      e.g. "Cinnamon banana drink" (no date in the name)
        original.mp4
        clip map + storyboard
        script
        omni storyboard link
        images/
        clips/
        final.mp4
```

## Rules
- One video = one folder, from parts/pull.md or parts/breakdown.md through the final edit. Every skill saves into it.
- No duplicates on one computer. Drive + computer is fine; two copies on the same computer is not.
- Video DB row gets marked as made: date + link to the video folder.
- At the end of a video, offer: "Save to Drive / computer / both?" (default = the onboarding answer).
