# AI UGC RECREATION — PROMPT SHEET

Copy-paste these in order. Short on purpose — `07-recreation-engine.md` carries the rest.

---

## STEP 1 — INTAKE

Attach the frames and the script, then paste:

```
Hey Claude — we're recreating this video.

It's AI UGC style. I'm going to be recreating it scene for scene unless
I say otherwise — same choreography, same framing, same iPhone-style
candid video imagery. That stays locked unless I say otherwise.

I will be making changes to: the character, the environment, the props,
the product, and the script.

Here are the frames and the script. Don't break down any marketing
structure, don't rewrite anything yet. Just confirm you've got it and
give me a quick summary of the video.
```

**You get back:** a one or two line summary, then a prompt for your character.

---

## STEP 2 — SCRIPT REWRITE

```
My character is [gender, age range, background, profession].

Rewrite the script. Keep the hook. Keep the beats. The only changes I
want right now are the call to action, and I want it to sound like my
character. Otherwise keep it pretty much the same.
```

**You get back:** the clean script, spaced by beat, plus one sentence on the CTA choice.

**Character format** — four things is enough:

> Older Mexican holistic healer woman

> Mid-forties fit Hawaiian surfer who lives a healthy lifestyle

Gender · rough age · background · expertise. Paste a longer block if you have one; it gets compressed for you.

---

## STEP 3 — VISUAL LOCK

Confirm the script, then name your visual changes. Paste your own script here instead if you rewrote it elsewhere.

**Direct recreation — fastest:**

```
Script is good. Let's use it. Just swap my character in, everything
else stays the same.
```

**With changes:**

```
Script is good. Let's use it.

Changes: [tighter framing / Walmart instead of Costco / add an American
flag / drop the last two beats]. Reference image attached.
```

**You get back:** your changes confirmed, a predicted base image count, and the **first image prompt only** — labeled `IMAGE 1 · ANCHOR`, with later ones labeled `IMAGE 3 · chains off image 1` so you know what goes in the reference box.

Run it. If you like it, say go and you get the rest.

```
Looks good. Give me the rest.
```

```
Pull the framing back and lose the flag. Then give me the rest.
```

**Attach a reference image for any environment change.** Words give you a generic version of a place; an image gives you the actual look. Props and framing can just be described.

### What goes in the reference box

**Anchor images** — the first image of any setup — get the full set:

- Your character reference (face lock, and body lock if you have one)
- The reference frame from the original video
- Your environment reference, if you're changing the location

**Every other image chains off that anchor.** One image in the box, plus the prompt.

### The chaining rule

For every image, ask:

- **First image of the video?** → anchor, full input set
- **Same setup as the last anchor?** → chain off that anchor
- **New location?** → new anchor, full input set again
- **Just a framing change?** → still chains off the anchor

**Never chain off a chained output.** Only anchors feed other images.

> Costco example: images 1–3 in the meat section all chain off image 1. Image 4 moves to the supplement section and becomes a new anchor. Images 5–6 chain off image 4.

**Why it matters:** if 3 chains off 2 and 2 off 1, every generation inherits every flaw before it and the face is gone by image five. Chaining off one anchor keeps each image independent — a bad image 4 costs one retry and touches nothing else.

**If the anchor is wrong, fix it first.** Everything downstream inherits it.

### Every prompt should be short

The rule behind all of them: **whatever is in the reference box doesn't get described.**

Your anchor has the character lock and the original scene frame in the box, so it doesn't describe the person or the room — it points at them and says what's different. Two short paragraphs.

Your chained prompts have the anchor's output in the box, so they're just `Same exact image, except…` plus what changed.

If any prompt comes back long, something got described that was already in a picture.

### Continuity

State what changed and what the change made ambiguous. Nothing else.

- Poured a full glass in → glass gone
- Spooned honey out of a jar → jar back on the table, still holding honey
- Dumped a bowl of cucumbers in → bowl back on the table empty, cucumbers now visible in the blender

If something left a container, it has to show up in whatever it went into.

**Cutting something?** Say which way — lengthwise or crosswise.

**On base images:** if one shot carries a long stretch of talking, that's *one* image — several clips chain off it later. You're not generating a new image every time the dialogue moves.

---

## STEP 4 — ANIMATION PROMPTS

```
Give me the animation prompts.
```

Send the generated images if you have them. Not required.

**You get back:** one labeled prompt per clip, each in its own copy block, ready to paste into Flow as a start frame.

`CLIP 3 · IMAGE 4 · 24 words · 8s`

> The camera pushes forward toward the yellow spot as she points at it and says: "You see that yellow spot right there? A yellow spot means it ripened on the vine the way it should." Natural movement, natural audio.

### Word budget

| Words | Clip |
|---|---|
| Under 9 | 4s |
| 9–15 | 6s |
| 17–25 | 8s |
| 27–35 | 10s |

30 words is the sweet spot for 10 seconds. Hook beats stay their own clip at whatever length they are — never padded.

### Adjustments

```
More movement on the hook.
```

```
Lock the camera on clips 4 through 7.
```

```
Use image 5 for the last three lines.
```

---

## AMENDMENTS — use at any step

Drop these in whenever. They do not break the flow.

```
Change the location to [X].
```

```
Keep the hook but make it [X].
```

```
Swap the product to [X].
```

```
Actually my character is [X].
```

```
Give me that again, shorter.
```

---

## WHAT DETERMINES YOUR CTA

**No product → growth video.** Save, follow, or a geo-targeted comment.

**Product → shop video.** Comment trigger, or link in bio.

The CTA gets picked for you based on the setting. Override it any time by naming the one you want.

**Your call, not Claude's:** compliance, disclosures, and whether you can name Amazon or the brand. Check your agreements.

---

*Steps 5+ pending.*
