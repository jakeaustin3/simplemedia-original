# Animation looks

The words that turn any route into animation. The scripts, storyboards and clip lengths don't change;
only what the pictures look like. Taken from the AI Animation Project (`08-visual-styles`,
`09-character-lock`, `10-green-screen`; looks from 25 reference videos). Read only the section for the look the
student picked.

**Where the words go**
- **Image prompts** (stills, start frames): the **look tail** closes every prompt. Never scatter style
  words through the description.
- **Seedance prompts**: the **look line** replaces the first line; the **LOOK block** replaces the movie
  or iPhone block.
- **Character images**: built in the look first (`parts/side-character.md` for skeletons and talking objects,
  the New Character skill (`/new-character`, installed separately) for a main animated character), before any shot.

Reference rows: Pixar skits = styles full rows 9, 10, 11 (10 and 11 = the Menerals product skits).
Cartoon = styles full row 8 (cartoon brought to life), row 12 (90s Disney 2D), Videos row 44.
Skeleton = Videos rows 36, 37. Talking objects = Videos row 33.

---

## Rules for every look

1. **Describe the character only in its first image.** After that the image is in the reference box and
   the prompt names one or two anchors ("the purple headband and the black afro"). Restating the whole
   design overwrites the reference.
2. **No text in images.** Captions are added in the edit. Product labels are the one exception, and only
   with the product image attached.
3. **Products stay real.** Attach the product lock, reproduce it exactly, label forward, lit like a hero
   shot, inside the animated world. Never redraw the product in the cartoon style.
4. **Show the problem on the body.** "If your X looks like this" gets its own image of the problem on the
   character (hair on a jaw bone, wrinkles in a macro of the eye socket).
5. **Big body, honest face.** Poses go big (arms in an X, finger wag, dropping into a chair); faces don't
   mug. Mugging is the number-one tell of bad AI animation.
6. **Motion is designed.** Animation prompts say: a wind-up before a move, a fast move that overshoots
   and settles, hair and cloth arriving a beat late, a held pose that still blinks and breathes. Never
   "smooth" or "floaty".
7. **Never write, in any animated look:** photorealistic (for the character), 8K, film stock, grain, pore
   detail, documentary, DSLR, iPhone. Those drag it back to live action.
8. **Never name the studio.** No "Pixar" or "Disney" in a prompt; describe the look instead.
9. **One look per video, never mixed.** Confirm it in one line before the first image prompt.
10. **Extras with no image** (a waiter, a passer-by) get a full description in every scene, word for word,
    written in the look's words (a Pixar waiter gets the eye build and proportions in two sentences; a
    skeleton extra gets build, hair, headband, outfit).
11. **Design characters against each other.** Two characters share no more than one of: age band,
    colouring, hair type. Two brunettes blend mid-clip.
12. **Any hand in a stylised shot is the character's** (a bony hand, the Pixar character's hand), never a
    real human hand. Exception: the hands shots at the end of the Animation project (Erick's call, 2026-10-07).

---

## Pixar (3D feature film)

Rounded appealing faces, big eyes (small iris, wide white either side), matte skin with a warm glow
through ears and fingertips, cloth with weight, warm lamp-lit rooms drawn in the same 3D style, one
saturated accent colour per scene. Every skit alternates a medium shot with a reaction close-up.

**Look tail (image prompts):**
```
Production CG from a feature-quality 3D animated film, stylised proportions, matte skin with a warm subsurface glow through ears and fingertips, cloth with weight and few large folds, soft motivated light from [the named source], [palette] with [the accent] as the single saturated colour. Not photorealistic, not flat cartoon. Vertical 9:16. No text.
```
**Seedance look line:** `Vertical 9:16, production CG from a feature-quality 3D animated film.`

**Seedance LOOK block:**
```
LOOK, consistent across every shot: production CG from a feature-quality 3D animated film, stylised proportions, matte skin with warm subsurface through ears and fingertips, cloth with weight and few large folds. Rendered in-camera depth of field, shallow on faces, soft background falloff. Key light from [this room's named source], [side], slightly above eye level, soft fill from [a named surface], thin warm edge on hair and shoulders. Lifted soft blacks with shadow detail. Palette of [four or five colours in this room]; [one item] is the single saturated accent. 35mm wides, 50mm mediums, 85mm close-ups, camera locked, one slow push-in on the final shot.
```
**Character image (first image, grey backdrop):** state the eye build once (small iris, wide white,
thick upper lid, short blunt lashes); one exaggeration with its counterpart (big eyes, small mouth);
heads tall by age (toddler 4, child 5, teen 6, adult 7); matte skin, never glossy.
**Motion:** wind-up, snap and settle, follow-through on hair and cloth; eyes reach the target before the
head turns.
**Stays out:** film grain, photoreal skin, rim light, HDR, crushed blacks, "beautiful".

---

## Cartoon

Two kinds. Ask which if the student just says "cartoon".

### Cartoon in the real world (default)
A cartoon character rendered as a glossy 3D figure in a photoreal place: a strawberry woman in a pink
tracksuit on a plane, a sponge in a hard hat on a building site. Toy-like surface, real clothes, real
light. The contrast is the joke.

**Look tail:**
```
A 3D cartoon character with a [glossy plastic-toy / felt / real fruit-skin] finish, big expressive eyes, wearing real cloth [garments], composited into a photoreal [place] and lit by that place's real light. The character is stylised; everything else is real. Vertical 9:16. No text.
```
**Seedance look line:** `Vertical 9:16, a 3D cartoon character in a live-action-real world.`
**Seedance LOOK block:** the skeleton block below with "the skeleton" replaced by "the character" and
the surface named.
A known cartoon character: describe the build (a yellow porous sponge with a square body), never the
trademarked name. Using a likeness is the student's call.
**Motion:** fast wind-up, squash on landings, big double-takes; cloth and props move with real physics.

### Flat 2D cartoon (retro TV or 90s Disney)
Everything drawn, rooms included. Use the project's own entries below: **3.11 Retro TV cartoon** (90s
animated-series line art) or **3.12 Disney renaissance** (90s princess cel look, styles
full row 12). Their look tails, Seedance lines and character image (§4 below) are used word for word.
In 2D, never write render, depth of field or subsurface (those are 3D words).

---

## Skeleton

A skeleton with big cartoon eyes and thick brows, real hair, a headband and real clothes, in a photoreal
room. Default build is the **glass body**: a clear glossy body shell over ivory bones, so it has a
person's silhouette. The headband, hair and outfit are its identity.

| Build | What you see |
|---|---|
| **Glass body** (default) | clear glossy body shell over ivory bones, cartoon eyes, real hair, headband, real clothes (Videos row 36) |
| Translucent skin | pale gel-like skin, skull and ribs showing through, huge glossy eyes |
| Face on skull | a full cartoon face and hair; bone shows only at the neck, arms and hands (Videos row 37) |
| Fleshy face | skull with cartoon flesh around the eyes and jaw, darker and moodier |

**Look tail (image prompts):**
```
3D animated skeleton character, [glass-body / translucent-skin / face-on-skull / fleshy-face] build, cartoonish expressive eyes and thick brows, highly detailed bone texture, clean production-CG render. The room is photoreal and lit by its own light. Vertical 9:16. No text.
```
**Seedance look line:** `Vertical 9:16, a 3D animated skeleton character in a live-action-real room.`
**Seedance LOOK block:**
```
LOOK, consistent across every shot: the skeleton is clean production CG, [build], cartoon eyes and brows, glossy bone, [hair and headband named], [outfit named]. Everything else in frame is photoreal: the room, the light, the props, any product. Light from [this room's named sources], faces fully readable. 35mm for wides, 50mm for mediums, 85mm for close-ups, camera locked, one slow push-in at most. Palette of [the room's colours]; [the headband / one garment] is the single saturated accent.
```
**Motion:** big snappy gestures (arms crossed in an X, finger wag, dropping into a chair); hair and
headband follow a beat late; eyes blink. The ribcage never bends like flesh.
**Stays out:** horror, gore, blood, decay, cracked bone, red or glowing eyes, Halloween, x-ray or
medical words. If it comes back scary: add brows and cartoon eyes, light the room bright. If it looks
like a medical model: name the headband, hair and outfit, add the glass body.

---

## Talking objects

The product, an ingredient, a body part or the problem itself has a face and talks ("Hey, I'm Dan
Druff"). Rendered like *cartoon in the real world* (a glossy 3D character with big eyes and a mouth,
small arms if it gestures) on the real surface where it lives: the scalp, the shower floor, the kitchen
counter. A germ or a fungus can live on photoreal skin (Videos row 33).
- The object speaks in the clip (Omni or Kling with dialogue), so its mouth must be visible and
  unobstructed in every start image.
- Its voice is set once (age, accent, energy) and repeated word for word in every clip.
- One object per clip is easiest; two objects talking = a skit, use the skit route with the objects as
  the cast.

---

## Other looks from the Animation Project

The student can name any of these, or bring a screenshot: match it to the closest one and say which in one
line. Copied from the project's `08-visual-styles` (14 looks in all; Pixar, cartoon and skeleton are above).

### 3.3 STYLIZED 3D

**What it is.** The opening cutscene of a game. Cleaner, cooler and sharper than Pixar:
harder edges, semi-realistic proportions, crisp materials, controlled colour, often a
slightly desaturated palette with one bright accent. Faces are appealing but less rounded.

**What sells it.** Crisp surface detail (fabric weave, metal, glass), clean rim separation,
steadier "camera," a graded look. Rooms in the same register, or a photoreal plate behind a
stylised character when the student wants the contrast.

**Look tail:**
```
Stylised 3D game-cinematic render, semi-realistic proportions, crisp materials, clean edge
light, controlled [cool / warm] palette with [the accent] as the single bright colour, soft
rendered depth of field. Not photorealistic. Vertical 9:16. No text.
```

**Seedance look line:** `Vertical 9:16, stylised 3D game-cinematic render.`
**LOOK block:** the Pixar block with *"production CG from a feature-quality 3D animated
film"* replaced by *"stylised 3D game-cinematic render, semi-realistic proportions, crisp
materials"* and the palette clause set cool.

**Motion note.** Slightly more realistic timing than Pixar, less squash. Camera moves are
allowed to be smoother and longer.

**Stays out:** cartoon, chibi, cel-shading (that is anime), photoreal skin.

---

### 3.4 URBAN 3D ANIME

**What it is.** Anime-designed faces (large angular eyes, small mouths, sharp hair shapes)
on 3D-rendered bodies, in streetwear: oversized fits, chunky sneakers, layered jackets,
Harajuku colour. Neon-lit city, wet asphalt, shop signs as shapes.

**What sells it.** The fit. Name every garment and the sneakers. Cel-style shading on the
skin with soft 3D light on the clothes. Night city with practical neon as the light source.

**Look tail:**
```
Urban 3D anime render, anime-styled face with large angular eyes on a 3D body, cel-shaded
skin with soft rendered light on the clothing, oversized streetwear [named], chunky sneakers,
neon city practicals as the light, wet asphalt reflections, [accent colour]. Vertical 9:16.
No text.
```

**Seedance look line:** `Vertical 9:16, urban 3D anime render.`
**LOOK block:** the Pixar block with the first clause swapped for the tail above and the
light sources set to neon practicals and shop windows.

**Motion note.** Snappier than Pixar, more pose-to-pose, hair moves in shapes.

**Stays out:** Pixar roundness, matte-subsurface skin language, daylight suburbia.

---

### 3.6 ARCANE

**What it is.** Painterly 3D: modelled characters with painted textures, visible brushwork on
skin and cloth, hard cinematic light, dark gothic detail, one glowing accent (purple, cyan,
ember). Faces sharp and adult.

**Look tail:**
```
Painterly 3D animation render, painted textures with visible brushwork on skin and cloth,
hard cinematic key light, deep shadows with detail, dark [gothic / industrial] setting, one
glowing [purple / cyan / ember] accent. Vertical 9:16. No text.
```
**Seedance look line:** `Vertical 9:16, painterly 3D animation with painted textures.`
**LOOK block:** the Pixar block with *"production CG"* replaced by *"painterly 3D with
painted textures and visible brushwork,"* blacks allowed deep, one glowing accent named.

**Motion note.** Slower, heavier, more held frames. Eyes carry it.

**Stays out:** cute, rounded, warm-lamp domestic, matte subsurface language.

---

### 3.7 ILLUSTRATIVE 2D

**What it is.** Clean editorial flat animation. Thick clean outlines or none, flat colour
fills, rich children's-book palette, simple appealing shapes, a little texture in the fills.
Looks like it came straight out of a picture book.

**Look tail:**
```
Clean illustrative 2D animation, flat colour with soft paper texture, simple appealing
shapes, [thick clean outlines / no outlines], rich children's-book palette, [warm cream /
deep blue / soft yellow] ground. Friendly modern explainer style. Vertical 9:16. No text.
```
**Seedance look line:** `Vertical 9:16, clean illustrative 2D animation.`
**LOOK block:**
```
LOOK, consistent across every shot: clean illustrative 2D animation, flat colour fills with a
soft paper texture, simple appealing shapes, [outline rule], one consistent palette of [four
colours] with [accent] as the single bright colour. Flat even light, no rendered shadows beyond
one soft contact shadow. Camera locked, cuts only.
```
**Motion note.** Limited animation: pose to pose, holds, simple secondary motion. Never
try for realistic weight.

**Stays out:** 3D, gradients, photoreal, anime eyes, dark or moody, cluttered scenes.

---

### 3.8 GHIBLI

**What it is.** Hand-painted 2D: soft watercolour skies with big cumulus clouds, painted
backgrounds with visible brush, simply drawn characters with small eyes and soft lines,
warm nostalgic light, wind in the grass and hair.

**Look tail:**
```
Hand-painted 2D animation in a nostalgic Japanese feature style, watercolour sky with
soft cumulus clouds, painted backgrounds with visible brush, simply drawn character with
small expressive eyes and soft lines, warm [afternoon / morning] light, wind moving the
[grass / hair / curtains]. Vertical 9:16. No text.
```
**Seedance look line:** `Vertical 9:16, hand-painted 2D animation, nostalgic Japanese feature style.`
**LOOK block:** the Illustrative block with painted-watercolour backgrounds, soft cel
shading on the character, and a wind or weather element named.

**Motion note.** Gentle: wind, hair, cloth, steam off food. Long holds. Food beats are
lingered on.

**Stays out:** 3D, neon, hard shadows, action-anime speed lines, "Ghibli" or "Miyazaki" as
words in the prompt.

---

### 3.9 1980s ANIME

**What it is.** Cel animation with hard-edged shadows, grainy film texture, muted cinematic
colour, dramatic low-angle frames, mechanical detail, hand-painted backgrounds. Retro
Japanese sci-fi and drama.

**Look tail:**
```
1980s cel-animation look, hard-edged two-tone shadows, subtle film grain and gate weave,
muted cinematic palette, dramatic [low / high] angle, hand-painted background, [neon /
dusk] light. Vertical 9:16. No text.
```
**Seedance look line:** `Vertical 9:16, 1980s cel-animation look with film grain.`
**LOOK block:** the Illustrative block with two-tone hard shadows, grain allowed, muted
palette, cinematic angles allowed.

**Motion note.** Limited frame rate feel, dramatic holds, speed lines allowed on action.

**Stays out:** modern digital gloss, 3D, pastel palettes.

---

### 3.10 PAINTERLY 2D

**What it is.** Every frame a painting. Thick visible brushwork, deep saturated colour,
dramatic light, simplified forms. The kind of image people screenshot and save.

**Look tail:**
```
Painterly 2D animation, every frame a finished painting, thick visible brushwork, deep
saturated colour, dramatic [warm / cool] light, simplified forms, [palette]. Vertical 9:16.
No text.
```
**Seedance look line:** `Vertical 9:16, painterly 2D animation, every frame a painting.`
**LOOK block:** the Illustrative block with brushwork and deep colour in place of flat fills.

**Motion note.** Slow, drifting, atmospheric. Camera pushes are fine.

**Stays out:** outlines, flat fills, 3D, comedy timing.

---

### 3.11 RETRO TV CARTOON

**What it is.** 90s animated-series line art: bold clean outlines, flat colour, angular
stylised faces, strong silhouettes, art-deco or Miami palettes (pink, teal, cream, gold),
glamorous adult characters. Think a 90s superhero series or a 90s glamour cartoon.

**Look tail:**
```
1990s animated-TV-series cel look, bold clean ink outlines, flat colour fills, angular
stylised face with a strong silhouette, [pink / teal / cream / gold] palette, flat even
light with one hard shadow side. Vertical 9:16. No text.
```
**Seedance look line:** `Vertical 9:16, 1990s animated-TV-series cel look.`
**LOOK block:** the Illustrative block with bold ink outlines and a hard shadow side.

**Motion note.** Limited animation, posed, dramatic holds, hair swings as one shape.

**Stays out:** 3D, painterly, anime eyes, sketchy lines.

---

### 3.12 DISNEY RENAISSANCE

**What it is.** 90s princess-film cel look: soft line, expressive large eyes, flowing hair
drawn in ribbons, sparkle and shimmer, palaces and skylines in pink, gold and cream, warm
sunset light, dessert and jewellery close-ups.

**Look tail:**
```
1990s hand-drawn animated-feature cel look, soft clean line, large expressive eyes,
flowing hair drawn in ribbons, shimmer and sparkle highlights, [pink / gold / cream]
palette, warm [sunset / chandelier] light. Vertical 9:16. No text.
```
**Seedance look line:** `Vertical 9:16, 1990s hand-drawn animated-feature cel look.`
**LOOK block:** the Illustrative block with soft cel shading, sparkle highlights and a warm
palette.

**Motion note.** Flowing: hair, fabric, sparkle drift. Big-eyed reactions.

**Stays out:** 3D, hard shadows, muted colour, "Disney" as a word in the prompt.

---

### 3.13 PIXEL

**What it is.** 16-bit game sprites and tile backgrounds. Chunky visible pixels, limited
palette, side-on or isometric rooms, HUD-free.

**Look tail:**
```
16-bit pixel-art animation, chunky visible pixels, limited [N]-colour palette, [side-on /
isometric] [room], dithered shading, no anti-aliasing. Vertical 9:16. No text, no HUD.
```
**Seedance look line:** `Vertical 9:16, 16-bit pixel-art animation.`
**LOOK block:** *"16-bit pixel art, fixed camera, sprite animation, limited palette, tile
background, no smoothing."*

**Motion note.** Sprite steps, frame-by-frame, no smooth interpolation.

**Stays out:** 3D, smooth gradients, high resolution detail.

---

### 3.14 WOOL STOP MOTION

**What it is.** Felted wool characters with visible fibre, handmade sets (cardboard, fabric,
clay), soft studio light, the slight jitter of stop motion. Cozy like a sweater.

**Look tail:**
```
Wool stop-motion animation, needle-felted character with visible fibre texture, handmade
[fabric / cardboard / clay] set, soft warm studio light, shallow macro depth of field, tiny
imperfections. Vertical 9:16. No text.
```
**Seedance look line:** `Vertical 9:16, wool stop-motion animation.`
**LOOK block:** *"Needle-felted wool character and handmade miniature set, soft warm studio
light, macro depth of field, stop-motion frame cadence with slight jitter, camera locked."*

**Motion note.** Stop-motion cadence: stepped, slightly jittery, loving. No motion blur.

**Stays out:** smooth CG motion, glossy surfaces, big sets.

---

---

## Character images (the exact prompts)

One character, full body, neutral pose, plain backdrop, feet in frame. The backdrop is grey
here (not the real room) because this image is a reference, not a shot. Nothing in the
hands.

### 1 Skeleton (default: glass body)

```
A single full-body character render of a 3D animated skeleton, [glass-body: a clear glossy
slightly refractive body shell in the shape of a [slim / curvy / stocky] [woman / man] with
ivory bones visible inside it | translucent-skin: pale gel-like skin with the skull and
ribcage showing through | face-on-skull: a full stylised face and hair, bone visible only at
the neck, forearms and hands | fleshy-face: a skull with cartoon flesh around the eyes and
jaw].

Eyes: large round glossy cartoon eyes seated in the sockets, [colour] irises, a wide band of
white visible either side, thick expressive [colour] eyebrows above them. Teeth clean and
even.

Hair: [length, colour, texture, how it's worn], real hair with volume, growing from the
skull. Headband: [colour] [fabric] headband tied around the skull. [Earrings / necklace /
one signature accessory].

Wardrobe: [garments, head to toe, named plainly]. Real cloth with weight. [The headband /
one garment] is the only saturated colour.

Silhouette: [N] heads tall, [dominant shape]. Reads as a person in black silhouette.

Pose: neutral reference stance, weight on one leg, head tilted slightly, light closed-mouth
smile, eyes to camera, hands empty and relaxed at the sides.

Camera: 50mm straight on at chest height, full body with feet in frame.
Background: flat grey studio backdrop, empty.

Clean production-CG render, highly detailed bone texture, cartoonish expressive eyes, not
horror, not medical. No text.
```

**Design calls you make when the student doesn't:** build (glass body), hair (something
with a strong silhouette: an afro, a beaded crop, a long blowout), headband colour (the
accent), one outfit (gym set, tee and jeans, a robe), one accessory.

**Never in a skeleton lock:** blood, cracks, decay, red or glowing eyes, exposed brain,
skulls as jewellery, a scythe, anything Halloween.

### 2 Pixar and stylised 3D

The Dan Kieft fixed block. Fixed lines stay word for word; swap lines are the brackets.

```
A single-character full-body render from a feature-quality 3D animated film, production CG,
not photorealistic and not flat cartoon.

Eyes: a small iris surrounded by a wide band of white sclera, clearly visible on both sides
of it. The iris takes up about a third of the eye opening. The eyeball is a sphere bigger
than the opening, and the lids cut across it. The upper eyelid is a thick band of skin
resting over the eyeball, casting a shadow onto it. No dark outline or liner drawn around
the eye. Eyelashes short, blunt and sparse.

Eyebrows: [Groomed — soft, hair-coloured, individual hairs | Graphic — thick, dark, soft-
edged | Sparse — very fine, barely visible].

Face: [THE ONE EXAGGERATION AND ITS COUNTERPARTS]. [Cranium and eyeline]. [Neck]. A [size]
mouth with rounded dimensional lips.

Subject: [age, sex, build, skin tone, one-line personality].

Facial hair: [omit the line if none. If present: a soft matte tint over the skin across
jaw, chin and upper lip, never individual hairs].

Skin: [Light zoning — pink nose tip, red translucent ear tips, flushed cheeks, cool purple-
grey under the eyes | Deep zoning — deep red-orange nose tip and ear rims, plum-red flush
across the cheeks and through the turn into shadow, cooler grey-violet under the eyes].
Warm subsurface glow through ears and fingertips. [Any marks, scattered unevenly].

Hands: [size and character], built from a few large rounded forms, thick blunt fingertips,
minimal knuckle detail, soft simple palms.

Silhouette: [N] heads tall, [dominant shape]. [Child rider: long torso, short legs, low
centre of gravity, enlarged head, narrow shoulders | Adult: normal proportion]. Reads as
[shape] in black silhouette.

Hair: [length, colour, texture, how it's worn], built as a deep three-dimensional volume
with three scales of grouping at once, a near-black occluded core with lit strands in
front, growing from a visible [part / hairline] with clear directional flow, [where it
falls] and casting soft shadows onto the skin. Matte.

Wardrobe: [garments]. [The signature element, worn] is the only saturated colour in an
otherwise muted palette. Cloth with weight, few large folds, grime in the creases,
unbranded.

Pose: neutral reference stance, weight on one leg, hip out, head tilted slightly, light
closed-lip smile, eyes to camera, hands empty and relaxed at the sides. Nothing mirrored.

Camera: 50mm straight on at chest height, full body with feet in frame.

Background: flat grey studio backdrop, empty.
```

**Rules that make it work:**
- **One exaggeration, with its counterpart.** Large eyes only read large against a small
  mouth and narrow jaw. State both.
- **Heads tall:** toddler 4 · child 5 · teen 6–6.5 · adult 7. The child rider never goes on
  an adult (bobblehead).
- **Deep skin tone always gets the deep zoning.** The light setting on dark skin renders
  grey.
- **Signature element is worn, never held**, and carries the only saturated colour.
- **Thin hair** is a "thin volume," still three scales. **Tight coils:** name the three
  scales (coils, clusters, mass).
- **Design characters against each other.** A second character shares no more than one of:
  age band, colouring, hair type, ear size. Two brunettes blend mid-clip.

For **stylised 3D** (toggle 3), keep the block and change the first line to *"a stylised 3D
game-cinematic character render, semi-realistic proportions, crisp materials"* and drop the
subsurface clause.

### 3 Cartoon in the real world

```
A single full-body render of a 3D cartoon character: [a strawberry with a woman's body /
a yellow porous sponge with a square body and thin arms / a grey cat standing upright /
describe the build], [surface: smooth glossy plastic-toy finish | felt | real fruit skin
with seeds], big round expressive eyes, thick brows, a small mouth.

Wardrobe: real cloth [garments named], [one accessory]. [One garment] is the only saturated
colour.

Silhouette: [N] heads tall, [dominant shape]. Reads as [shape] in black silhouette.

Pose: neutral stance, arms relaxed, hands empty, eyes to camera, light closed-mouth smile.
Camera: 50mm straight on at chest height, full body, feet in frame.
Background: flat grey studio backdrop, empty.

Clean 3D render of a toy-like cartoon character, lit softly and evenly. No text.
```

### 4 The 2D styles (toggles 7–12)

```
A single full-body character design sheet image, [style tail's first clause, e.g. clean
illustrative 2D animation / 1990s animated-TV-series cel look / hand-painted 2D in a
nostalgic Japanese feature style]. [Age, sex, build, skin tone, one-line personality].

Face: [the one exaggerated feature and its counterpart]. Eyes: [style's eye rule: small and
simple for Ghibli / large and expressive for Disney renaissance / angular for retro TV].
Hair: [length, colour, shape as one silhouette]. Wardrobe: [garments], [accent] the only
bright colour.

Pose: neutral stance facing camera, arms relaxed, hands empty, feet flat.
Flat [colour] background, nothing else.

[Style tail from 08, minus the aspect ratio line]. No text.
```

### 5 Pixel and wool

Pixel: *"16-bit pixel-art character sprite, front view, [N]-colour palette, [build and
outfit in two lines], on a flat single-colour background, no anti-aliasing."*
Wool: the cartoon block with *"needle-felted wool character, visible fibre texture"* as the
surface and *"soft warm studio light, macro depth of field"* at the end.

---

### Rules for every character image

- **Nothing in the hands.** Props get their own prompt. A held object locks the pose and
  eats the reference.
- **No ink or pen marks on skin.** They render as tattoos.
- **Always output the prompt in full.** Every revision, every variation.
- **Keep it short.** Long prompts get averaged.
- **No avoid list.** Negations are the weakest instruction; one line at the end is enough.
- **No aspect ratio in the lock text.** Set it in the tool. (The look tails in `08` carry
  9:16 because those are shots, not references.)
- **No acting.** Neutral held expression.
- **No lighting or grade lines on the grey backdrop.**
- **Branding traps:** don't ask for a white high-top with a rubber toe cap and then say "no
  logos." Change the silhouette instead.
- **Watch child anatomy words.** "Soft round belly" on a toddler comes back as a paunch.
  Slim, straight, flat torso; let the head carry the age.

---

After the first image: the image goes in the reference box, prompts name one or two anchors only, the
look tail still closes every prompt. A detail that drifts gets one line in that prompt only.

---

## When it breaks

| Symptom | Fix |
|---|---|
| Character drifts photoreal | strip live-action words; restate the look in one line |
| Character drifts to generic CG | reference in the box, name only one or two anchors |
| Room turns cartoon in a real-world look | add "the room is photoreal and lit by its own light" |
| Product redrawn in the style | attach the product lock; "reproduce the product exactly, real packaging" |
| Face mugs | write what they're doing, not the emotion as an adjective |
| Motion floaty | add wind-up, snap, settle, follow-through |
| Text appears | "No text" at the end of every tail |
| 2D look comes back 3D | remove render, depth of field, subsurface |

Log every new failure here, tagged with the look and the tool.
