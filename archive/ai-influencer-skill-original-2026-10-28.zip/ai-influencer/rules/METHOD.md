# Reverse-build method

How we break a finished video down, built one question at a time with Erick.
Each teardown lives in its own folder here; corrections from each one are folded back into this file.

## Q1 · What the breakdown pulls out (2026-09-30)

One table per video. **Each row = one shot** (a cut / one still), in order.

| # | Column | What goes in it |
|---|---|---|
| 0 | **Scene** | Group label for rows that came from one generation (e.g. one Seedance clip holds many shots but is one scene). Filled in *after* the shots are listed, by grouping. |
| 1 | **Structure** | Where the row sits in the story: hook · body · CTA, plus the named script structure when there is one (e.g. Problem · Agitate · Solution). |
| 2 | **Dialogue** | The exact words said during that shot. |
| 3 | **Still** | What is seen on screen: the image/frame for that shot. |
| 4 | **Action** | Movement and context: what happens during the shot. |

**Order of work:** break into shots first (every cut, every still), then group shots into scenes by how the video was probably generated.

**Open:** answer is proven on Erick's example videos before moving to Q2.

## Q2 · Where a link lands, and where the breakdown is stored (2026-09-30)

Three intake paths, all protected, all ending in the Video DB:
1. Student drops the link in Discord → Video DB row → tells Claude "break down row N".
2. Student gives Claude the link → Claude downloads and breaks it down → backfills the Video DB.
3. Either path can send the downloaded video to Higgsfield video analysis (cost to confirm).

Tested 2026-09-30:
- Higgsfield `video_analysis_create` accepts only a YouTube URL or an uploaded video file. Instagram links are refused (HTML page, not media). So: download first, then upload, then analyze. Balance 961 credits (Ultimate). Price per analysis unknown until one runs.
- yt-dlp reads the Instagram reel without a login (1080×1920). Download path works.

Storage: the Videos tab is one row per video (Thumbnail · Link · Transcript · Folder · Download · Storyboard · Scene 1–7). The breakdown is one row per shot, so it does not fit that row. Proposed: a second tab "Breakdown", one row per shot (Video row # · Scene · Structure · Dialogue · Still · Action), plus one new column on Videos linking to it. Existing columns untouched. Awaiting Erick's ruling.

## Test 1 results · local method vs Erick (2026-09-30)

Three videos, local method (ffmpeg cuts + 2s timeline + Whisper + Claude reads frames). Seedance recipe: correct. Omni cookies: wrong (10 rows → really 8 clips). Omni Walmart tests: wrong (9 rows → really 5 clips).

**Root cause:** I treated every cut as a new scene. In Omni videos a *clip* = one still animated (about 4–10s), and the editor then cuts inside it (zoom punch-ins, trims, re-stitches). Cuts are edits; they are not new clips.

### Rules added (from Erick's corrections)
1. **The row unit is the clip (one generation), not the cut.** Raw cuts stay in the working files; the clip map lists clips.
2. **Same-clip test.** Two adjacent shots are the same clip when the character, outfit, set, lighting and prop state are unchanged and the framing change is a zoom, crop or trim. A close-up of the same prop in the same state = same clip.
3. **Check prop state before calling a new clip.** Raw dough balls zoomed in are still raw dough balls (cookies video, rows 7–8).
4. **Ingredient logic (recipes).** Every ingredient named in the dialogue is its own step, and in a recipe video usually its own still/clip. Count ingredients in the transcript first, then expect that many stills.
5. **Script first, frames second.** Split the transcript into beats (one sentence or one instruction each); each beat is a candidate clip. Then match frames to beats. Omni clips run roughly one beat / up to ~30 words each.
6. **Demonstration = one clip.** "Do X → see Y" (test + result) is one animated still, not two.
7. **Transitions and effects are never rows.** Mirrored zooms, re-stitches, punch-ins are edits.
8. **Action describes the whole clip**, including the beats the editor cut between.

### Open
- Define **Scene** vs **Clip** for column 0. Proposal: Clip = one generation (one still animated). Scene = a change of location or setup; most of these videos are one scene. Erick to rule.

## Row 2 test · own breakdown vs DB pull (2026-09-30)
Erick: mine better (has Action) but wrong on two counts. Rules added:
9. **Style rule · Product authority, Google Omni (Flow) (row 2 only so far):** the closing talk after the last ingredient (apply + benefits + CTA) is ONE scene, regenerated repeatedly from the same still. Rules are style-specific: tag every rule with the style + tool it came from and do not generalize it.
10. **Action = the physical verb, the tool in hand, and the target.** Pour ≠ squeeze. Say "injects the syringe into the mask's forehead", not "points". Check the frame for what is actually held (spoon, jar, tube).
11. (withdrawn: Erick says the folder shows 6 scenes and that same-still merging is not a general rule; it is style-specific.)

Two skills, one output format:
- **parts/breakdown.md** (link or file): download → cuts + 2s timeline → Whisper → clip map → storyboard. Full path, ~2 min, no credits.
- **parts/pull.md row N**: read the row → download the folder (video, transcript.txt, scenes.txt, frames). Skip Whisper and cut detection (already done), regroup scenes into clips, add Structure + Action from the frames. Cheaper and faster; it only needs a look at the frames.

## Erick's rulings, end of session 1 (2026-09-30)
- **Action needs the motion, not one frame.** My corrections only came from Erick watching the video. Fix: read a strip of 4–6 frames per clip (his repo's "grid" idea) before writing Action, or watch the clip. One frame per clip is not enough.
- **Tool is a question, not a guess.** Before grouping, ask: "Was this made in Google Omni (Flow) or Seedance, or which tool are you using?" If the student says Seedance, group the DB clips into Seedance scenes and make the grouping visible (scene bands above the clip cards). Example, clove water (Videos row 9, ~8 DB clips): clip 1 = scene 1 · clips 2–6 = scene 2 · clip 7 = scene 3. Then output in that tool's format (Seedance: one prompt per scene; Omni: one still per clip).
- So the storyboard has two levels: **Scene** (one generation) and **Clip** (one shot). Column 0 is back, as a band, when the tool makes multi-shot generations.
- **Presentation:** the embedded-frame HTML got to 631 KB at 540px frames and is annoying to open; 134 KB at 210px is fine. Decision pending: artifact link (opens in the browser, stored in the DB row) + table in chat, PNG only for Miro.

## Seedance recreation path · proven (2026-09-30)
Two videos recreated with the character in ONE Seedance 2.5 generation each (30s, 480p, kie.ai, 840 credits): clove water → Mexican kitchen, chef chickpea cookies → Costco aisle with generated music. Erick's grade: **usable, 100%.** This is now the default path when a student says "do it in Seedance".

Recipe (from `seedance-prompt-builder`, Max's template):
1. Break the source down (clip map). Cut the script to ≤ ~65 words for 30s at the character's pace; shorter hook, one-line CTA.
2. 7 shots max, at most two actions each. Two named camera positions only (A = face at the counter/table, B = high angle on the bowl/pot, hands only).
3. Character = 4 locks in @Image order (front full body · front close-up · right profile · left profile) + face/voice text from `character.md`. Wardrobe "exactly as shown".
4. Props as fixed specs in HERO PROPS, repeated by name in every shot. Continuity of un-referenced props is the weak spot: check the frames, re-roll once if it drifts.
5. Environment written out with 5–8 anchors. Seedance drew a generic warehouse for "Costco bakery aisle"; put the most specific anchor first.
6. Off-screen narration over hands shots; "No text on screen"; music via the MUSIC block if wanted.
7. Run: `seedance-run/scripts/run_clips.py <spec.json> --dry-run` then run; 480p is the deliverable. Check: frame strip + Whisper on the output.
Files: Erick's seedance-recipe and chickpea-costco runs (not in this kit).

## Green screen (row 15, chia + lime + ACV, 2026-09-30)
Erick's Miro breakdown (left side of the board, next to the reel thumbnail). Rules, tagged **green screen**:
12. **Two tracks, not one.** Avatar track (A-roll: one still of the character, talking) + B-roll track (one still per script beat, image to video, same rules as recipes). The clip map lists both; column "Track", plus a "Layer" note for the edit.
13. **Avatar is one of two options, never both:** (A) HeyGen: one generation of the whole script; (B) Omni (Flow): split the script at sentence breaks into pieces of ≤~30 words / ~10s, independent of the B-roll cuts, stitched in CapCut. Ask the student A or B in phase 2.
14. **The avatar still carries its own background.** It is keyed out (green screen removal) bottom-left over the B-roll, and shown full frame for the CTA when there is no B-roll.
15. **Storyboard = two rows:** avatar cards on top, B-roll cards below, both in time order.
16. **Generation count (option B) = total words ÷ 30, rounded up** (56 → 2, 90 → 3, 150 → 5). Show the math on the output.
17. **Output = board-style timeline, one PNG per option** (`vidtools.py timeline <name>`, from `timeline.json`): per generation a row with the script block on the left, the avatar thumbnail, and an arrow over the B-roll it plays over; B-roll row of same-size thumbnails ending in the CTA card; an Edit note (remove background → bottom-left → full frame at the CTA → captions). Matches Erick's Miro layout (2026-09-30).
18. **Green screen ending:** the B-roll usually stops for the last ~5–10s and the avatar (A-roll) plays unkeyed for the CTA. That stretch is NOT a B-roll clip and nothing is generated for it: it is the tail of the avatar generation(s) (HeyGen: same video; Omni: the last generation, or one more if the words run over). Show it as an empty "B-roll ends" slot.
18. **Green screen ending:** the B-roll usually stops for the last ~5–10s and the avatar (A-roll) plays unkeyed for the CTA. That stretch is NOT a B-roll clip and nothing is generated for it: it is the tail of the avatar generation(s) (HeyGen: same video; Omni: the last generation, or one more if the words run over). Show it as an empty "B-roll ends" slot.
19. **Split priority (Omni, Erick 2026-09-30):** fewest generations (each ≤30 words) → end on whole sentences (comma cut only when a sentence can't fit) → even sizes → last generation ≥ ~10 words / 4s. Implemented in `vidtools.split_script`.
20. **Green screen is detected, not assumed:** parts/pull.md and parts/breakdown.md spot it from the strips after phase 1 and OFFER /greenscreen-storyboard; it is optional.

## Seedance recipe storyboard · parts/seedance-storyboard.md (2026-09-30)
- A pull's clip map (one still per clip) is the Omni/Kling layout. For Seedance, regroup: one generation = the run end to end, max 30s (aim 20-30s), character kit as reference, setting described, original video as reference for the look.
- Over 30s: generation 1 ends ON the first frame of the next part (e.g. clove water row 12: G1 = hook + 5 recipe steps, ends on the monologue's first frame; G2 = the 27s monologue, starting from that end frame).
- Under 30s: one generation (chef chickpea row 39, 30s, 11 clips → G1).
- Tool: `seedance_board.py <name>` → seedance-plan.json + seedance-storyboard.png. Next step: parts/seedance-prompt-builder.md, one prompt per generation.
- **Before/after hooks (row 42, 2026-09-30):** a before shot and an after shot are separate clips even when the same person talks over both. Read the dialogue for time jumps ("this is her four months later") and check the frames at that line: a new set or a changed body = a new clip. Check the hook every 0.5s, not just the 5-frame strip.
