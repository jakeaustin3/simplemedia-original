# Routes · style × tool 

Every recreate runs the same way:

1. **Pull / breakdown.** Always the same careful clip map, for every style. Never changes per route.
2. **Format check.** Name the format when it's obvious (green screen, transformation...). It does NOT skip anything.
3. **"How do you want to make this?"** Always asked, after the format check. No default. The answer + the style pick the storyboard.
4. **Storyboard for that route.** The structure changes with the route (Seedance = few big generations; Omni = one clip per beat; HeyGen = one long avatar clip).
5. **Prompts** (the route's skill), then generate.

## Running the tools

- **Seedance:** Claude writes the big prompt(s) with the Seedance skills. Then the student picks:
  run it for them (Higgsfield MCP/CLI, kie.ai API, OpenArt...) **or** take the prompt and paste it in by hand.
  Always offer both. Prompt writing is the part they need help with.
- **Omni Flash in Google Flow:** by hand (no API). Claude gives clip-by-clip prompts.
  Omni can also be automated through Higgsfield or the kie.ai API.
- **Seedance + Omni mixed:** build in the order the video plays (if the first part is Omni, do Omni first; if it's Seedance, do Seedance first).
  Need breakdowns for both versions: Omni→Seedance and Seedance→Omni.
- **Kling / Kling Motion Control / Genjutsu:** clone motion from the reference video with the student's character
  (transformation one-clip protocol). Image sources: Nano Banana Pro, GPT images.
- **HeyGen:** one long avatar clip (green screen, podcast, overlay). Long form. The student does it in HeyGen, or Claude runs it through the HeyGen API if they connected a key.
- **ElevenLabs:** voiceover for no-speaking formats (skeleton, talking objects, hands).

## Matrix

Status: ✅ tested · 🟡 lightly tested · ⬜ not tested

| Family | Style | Routes | Status |
|---|---|---|---|
| AI influencer · talking head | Green screen | HeyGen · Omni | ✅ Omni (/greenscreen-storyboard → prompts → edit) |
| | Overlay / podcast | Omni ✓ (/podcast-image → Flow → parts/stitch.md → voice → /podcast-storyboard → /podcast-edit-style-erick-professional) · HeyGen | ✅ Omni tested 2026-10-01 (10 secret codes, Erick) |
| | Recipe | Seedance · Seedance + Omni · Omni | ✅ Seedance (clove, chickpea), ✅ Omni (row 40, parts/omni-storyboard.md) |
| | Product (image to video) | Kling · Nano Banana Pro / GPT images → video; Seedance with or without reference images | ⬜ |
| | Product authority | Omni (mostly) · HeyGen · Seedance? | ✅ Omni (Botox row 2, parts/omni-storyboard.md), ⬜ Seedance |
| | Explainer | Omni in Flow · Kling (GPT images → Kling 3.0 / Omni) · Seedance? | 🟡 Omni, ⬜ Seedance |
| | Interview | hook (2 interview clips, before → after) in Seedance (one gen) or Flow (2 stills) → body = one talking-head image in Omni clips + parts/stitch.md or HeyGen; no new board: hook from parts/seedance-storyboard.md, body from parts/omni-storyboard.md | 🟡 stills tested (row 21, the character at Santana Row) |
| Skit | Movie style | Seedance end to end · Flow end to end · Seedance hook → Flow | ⬜ |
| | iPhone style | Seedance hook → Flow · Flow end to end | ⬜ |
| Transformation | Before/after images | images (Nano Banana / GPT) animated in Kling or Flow; any order (before→after, after→before, after only); single or couple; weight loss, skincare, glow-up, divorce... **No continuity between clips** · the Transformation skill (`/transformation`). Tested: GPT Image 2 stills + Kling 3.0 ✓. Flow (Nano Banana Pro + Omni) = storyboard page. Seedance not tested | ✓ |
| | One clip / routine | image + Kling prompt (default, looked more real) · Kling Motion Control only for ONE person in a clean shot (matching first frame) | ✓ |
| | + talking head | character speaks → AI Influencer talking-head route (`parts/omni-storyboard.md`) | ~ |
| Animation | Pixar skit | the Animation project → `parts/skit.md` (Seedance, look block from `rules/animation/LOOKS.md`) · `parts/flow-skit-storyboard.md` (look tail on every still) | ⬜ |
| | Cartoon skit (3D in the real world, or flat 2D) | same as Pixar, cartoon look | ⬜ |
| | Skeleton (voiceover) | the Animation project: ElevenLabs voiceover (skeleton never speaks), one shot per line, hands shots for the CTA · Nano Banana Pro + Omni in Flow (by hand) · GPT Image 2 + Kling 3.0 (kie or Higgsfield, automatic) · no Seedance · edit = `skeleton/scripts/edit.py` | 🟡 edit tested on placeholder shots (2026-10-07); no generated run yet |
| | Talking objects | the Animation project → talking object side character → `parts/omni-storyboard.md` (Flow) · Kling · Seedance only on request | ⬜ |
| Product demonstration | Hands | the Product Demonstration project: product image → Flow clip (always video) on top · voice underneath = character in Omni (any setting, ~30 words a clip) or ElevenLabs MP3 · **never Seedance** · edit = `product-demonstration/scripts/overlay.py`. Quick sell = one start frame; story = one shot per place, selfie shots allowed | 🟡 edit tested on placeholder clips (2026-10-07) |
| | Explainer | default UGC: a person on camera talking with the product (styles full row 13) · Omni or Seedance, student picks · voiceover + close-ups only when asked | ⬜ |
| | Demo | Seedance only, from a real video of the product (required); the person talks inside the clip | ⬜ |
| | Try-on (clothing only) | (1) images of her in the clothes → Flow clips, Omni voice or ElevenLabs under · (2) she tries it on and talks, Omni or Seedance | ⬜ |

## Next
1. Seedance + Omni mixed: break down Erick's example videos, both orders (Omni first / Seedance first).
2. Then work through the matrix one route at a time; each route gets its storyboard + instruction set.

## Side characters (interview, 2026-10-02)
No skill and no kit. Describe side people inside the anchor prompt (age, build, skin, eyes, hair, clothes). Before → after person: image 2's reference box = character lock + image 1's output, prompt "Same woman, same face, eye color, skin tone, hair color and age, except now she is …". New people (husband) are described fresh in that prompt. In Seedance, tag the same idea: "the obese woman from the first shot is now slim and strikingly beautiful." Tested on row 21: identity held. Fallback only if a face drifts: generate the side character's before/after pair first.
