# Video Database Bot — setup playbook (lives in tools/)

The person using this folder is a beginner following a visual guide. They send short
messages; you do the work. Talk to them in plain words, one next step at a time, and never
ask them to edit files, open Terminal, or read code. Only hand them the clicks that must
happen in their browser, each with its exact link.

**What this is:** paste a video link in Discord `#video-drop` → `bot.py` downloads it
(`process_video.py`: scenes, storyboard, Whisper transcript, `scenes.txt`, zip) → `sheet.py`
POSTs files to a Google Apps Script web app (`tools/google-sheet/Code.gs`) bound to their sheet →
the script saves files to Drive and inserts a row at the top of the `Videos` tab.

**Mac or Windows.** Check which you're on first. Commands below say `python3`; on Windows
use `python` (or `py` if `python` isn't found). Everything else is the same except the
install step and the folder rule, noted inline.

Commands run from the kit folder; the bot files are in `tools/`. Settings live in `settings.txt` in the kit folder (copy `settings.example.txt`) (dotenv format). Never print the token or web app URL back
in full, never commit `settings.txt`, and never paste either into Discord or a web page.

---

## "Set me up"

1. **Location.**
   - **Mac:** if this folder is inside `~/Desktop`, `~/Documents` or `~/Downloads`, tell them
     background apps on a Mac can't read those folders. Ask to move it to
     `~/simple-media-video-kit`, move it, and ask them to reopen Claude Code there. Stop until they do.
   - **Windows:** any folder works (Downloads is fine). Avoid folders synced by OneDrive
     (often Desktop and Documents): move it to `%USERPROFILE%\simple-media-video-kit` if so.
2. **Install.**
   - **Mac:** `brew install ffmpeg node` (install Homebrew first if missing; it asks for their
     Mac password in the terminal, so tell them that first).
   - **Windows:** `winget install -e --id Python.Python.3.12` if Python is missing, then
     `winget install -e --id Gyan.FFmpeg` and `winget install -e --id OpenJS.NodeJS.LTS`. Tell
     them to click **Yes** on any "allow changes" prompt. winget installs don't reach the
     current shell's PATH; use full paths or open a new shell, and verify `ffmpeg -version`.
   - Both: `python3 -m pip install -r requirements.txt (in the kit folder)` (Mac: add `--break-system-packages`
     if pip refuses).
3. **Test.** `python3 ~/.claude/skills/ai-influencer/scripts/process_video.py "https://www.facebook.com/reel/1617284839873263"`.
   Expect about 31 scenes. Then delete `output/`.
4. Reply: "Everything's installed ✅. Next: Part 2 in the guide (Discord). When you have
   your bot token, paste it here."

## They paste a Discord bot token

A token looks like three dot-separated chunks, e.g. `MTQ1….G7x….a9F…` (~70 chars).

1. Write it to `DISCORD_BOT_TOKEN=` in `settings.txt`.
2. `python3 ~/.claude/skills/ai-influencer/scripts/bot.py --invite` → give them the link: "Click this, pick your server, click
   Authorize."
3. `python3 ~/.claude/skills/ai-influencer/scripts/autostart.py on` (starts the bot in the background, and at every login. Mac uses a
   LaunchAgent, Windows the sign-in Run list plus a hidden `pythonw`; both are named per folder,
   so several bots can run on one computer).
4. After they say they've authorized, check `tools/bot.log` for `created #video-drop` or
   `Logged in`. If it logged `PrivilegedIntentsRequired`, they need to turn on **Message
   Content Intent** at https://discord.com/developers/applications → their app → Bot → Save,
   then `python3 ~/.claude/skills/ai-influencer/scripts/autostart.py restart`.
5. Reply: "Your bot is in your server and #video-drop is ready ✅. Next: Part 3. Say
   'Connect my Google Sheet'."

## "Connect my Google Sheet"

Uses clasp 3.x (`npm install -g @google/clasp`). Command names changed in 3.x:
`create-script`, `create-deployment`, `update-deployment`, `open-script`.

1. Ask them to turn on **Google Apps Script API** at
   https://script.google.com/home/usersettings. Wait for "done".
2. `clasp login` (run in background; it opens their browser. On Windows the command is
   `clasp.cmd` if `clasp` isn't found). Tell them: "A Google page
   opened. Pick your account and click Allow." Wait until it finishes.
3. In `tools/google-sheet/`: `clasp create-script --type sheets --title "Video Database"`.
   It creates the Google Sheet plus its script and writes `.clasp.json` (`scriptId`,
   `parentId` = the sheet ID). clasp may overwrite `appsscript.json`, so **then** copy
   `manifest.json` → `appsscript.json` and run `clasp push --force`.
4. `clasp create-deployment --description "Video Database bot"` → take the deployment ID.
   Write `SHEET_SCRIPT_URL=https://script.google.com/macros/s/<deploymentId>/exec` and
   `SHEET_DEPLOYMENT_ID=<deploymentId>` to `settings.txt`.
5. **Permission (must be them).** Give them `https://script.google.com/d/<scriptId>/edit`
   and these clicks: pick **setup** in the function menu → **Run** → **Review permissions**
   → their account → **Advanced** → **Go to Video Database (unsafe)** → **Allow**.
   Explain "unsafe" only means they made it themselves.
6. **Verify.** `python3 ~/.claude/skills/ai-influencer/scripts/bot.py --test "https://www.facebook.com/reel/1617284839873263"`.
   If the response is HTML instead of JSON, permission (step 5) isn't done or the manifest
   wasn't pushed. Then `python3 ~/.claude/skills/ai-influencer/scripts/autostart.py restart`.
7. Reply with the sheet link `https://docs.google.com/spreadsheets/d/<parentId>/edit`: "Your
   sheet is ready with a test video on top ✅. Click **Allow access** on the yellow bar if
   pictures are blank. Now paste any video link in #video-drop."

**Fallback if clasp won't work:** walk them through the manual route. Open the sheet →
Extensions → Apps Script → paste `tools/google-sheet/Code.gs` → Project Settings → show
appsscript.json → paste `manifest.json` → Deploy → New deployment → Web app (Me / Anyone)
→ Authorize → give you the URL.

---

## Everyday requests

| They say | You do |
|---|---|
| "Is my bot running?" / "It's not reacting" | `python3 ~/.claude/skills/ai-influencer/scripts/autostart.py status`, read `tools/bot.log`, fix, `restart` |
| Videos stuck on ⏳ Processing, or ❌ "Google Sheet script didn't answer" | Google's web app sometimes hiccups (an error page, a timeout, or a redirect that drops the request body so only `doGet()`'s "script is running" greeting comes back), mostly when several videos or big uploads go at once. `sheet.py` already re-POSTs to unexpected redirects and retries each call 4 times (15/30/45 s); `bot.log` shows `🔁` / `↪️` lines when that happens. If a video still failed: `python3 ~/.claude/skills/ai-influencer/scripts/autostart.py restart` (catch-up finishes ⏳ rows) or `python3 ~/.claude/skills/ai-influencer/scripts/bot.py --redo "<link>"` for ❌ rows. If every call fails, it's the deployment: check `SHEET_SCRIPT_URL` and that access is "Anyone" |
| "Stop my bot" / "Start my bot" | `tools/autostart.py off` / `on` |
| "I moved the folder" | `python3 ~/.claude/skills/ai-influencer/scripts/autostart.py on` from the new location (rewrites the path) |
| Instagram links ❌ | set `COOKIES_BROWSER=chrome` (or their browser) in settings, restart |
| "Add a column for …" / change the sheet | edit `Code.gs` (`HEADERS`, `finish()`, `FIRST_FRAME_COL`) **and** `sheet.py`/`bot.py` if new data is needed, then `clasp push --force` + `clasp update-deployment $SHEET_DEPLOYMENT_ID`, restart the bot. Never create a new deployment (the URL would change) |
| "Redo [video]" / "update my old rows" | `python3 ~/.claude/skills/ai-influencer/scripts/bot.py --redo "<link>"` per video (or they type `redo <link>` in #video-drop, bot reacts 🔄 then 🎉). Keeps the row in place (or brings a deleted one back on top), empties that video's Drive folder, reprocesses with the current scene settings, and clears leftover scene pictures. Use it after any scene-detection change |
| "Bring back a video I deleted" (bot reacts 🗑️) | `sheet.from_env().forget(link)` (removes it from the hidden `History` tab), then they paste it again |
| "It missed a link" in a forwarded message or card | `links_in()` in `bot.py` reads message text plus every embed's title, description, fields, author and footer (forwarded ones too). To re-read an old message, set `state.json` for that channel to the ID of the message *before* it, then `autostart.py restart` |
| "It missed scenes" / "too many scenes" | How scenes are found (`process_video.py`): black bars cropped out → **hard cuts** (`SCENE_THRESHOLD` 0.25) → **quick cuts** on a still camera (`SPIKE_MIN` 0.1, `SPIKE_RATIO` 4), kept only if ≥ `SPIKE_CHANGE` (0.09) of an 18×32 grey thumbnail changes, so caption words and small movements don't count → **fades/dissolves** (`FADE_CHANGE` 0.5 across 2.5 s with ≤ `FADE_STEADY` 0.08 on each side) → scenes under `MIN_SCENE_SECONDS` (0.4) merged → **runs of look-alike scenes** (colour difference ≤ `MERGE_COLOR` 0.06 and ≤ `MERGE_CHANGE` 0.25 moved) merged only when `MERGE_MIN_RUN` (5)+ in a row, so talking-head jump cuts collapse but 3–4 product/ingredient steps in one spot stay. These two cases can't be told apart by pixels; the run length is the deliberate trade-off. Talking-head reels with word-by-word captions used to explode into 40+ scenes; raising `SPIKE_CHANGE` removes more, lowering it keeps more. Override any of these in settings, check by eye with `python3 ~/.claude/skills/ai-influencer/scripts/process_video.py "<link>"`, then restart |
| "Look closer at [video]" / "it missed a product" (optional, uses their Claude usage) | The automatic scenes only split on camera cuts and fades, so something picked up without a cut stays inside one scene. For one video they name: download it (`yt-dlp` into a temp folder), pull a frame every 0.5 s with ffmpeg, look at the frames yourself, and add a scene wherever something new appears in someone's hand, leaves it, or comes in from off camera (ignore captions, talking, gestures). Rebuild `frames/`, `storyboard.jpg` and `scenes.txt` with those starts (reuse `process_video.py` functions), then `folder_id = sheet.redo(link, video_name(link))` and `sheet.save_video(result, folder_id)` to replace that row. Tell them first that this reads many pictures and uses a lot of their Claude usage |
| "It didn't save a creator" / profile links | A profile link (tiktok.com/@name, instagram.com/name, youtube.com/@name, facebook.com/name) in #video-drop goes to the `Creators` tab (Creator, Link, Platform, Added; newest on top, no duplicates) via `creator_in()` in `bot.py` and the `creator` action in `Code.gs`. Bot reacts 👤 (🔁 if already there). Only text typed or forwarded counts, not the creator link inside a video's preview card |
| Change channel name | `CHANNEL_NAME=` in settings, restart |
| Better transcripts | `WHISPER_MODEL=small` (slower) in settings, restart |
| "Save space" / no zip copies | skip the zip upload in `sheet.save_video` |

Rules: a link in `History` with no row in `Videos` was deleted on purpose — `start` refuses it,
so don't work around that when retrying; keep the column order in `finish()` and `HEADERS` in sync; the `Link` column must stay
column B (duplicates and rewind look there). The tab must stay named `Videos` unless you change `TAB` and redeploy. Each sheet
remembers its own Drive folder by ID (script property `ROOT_FOLDER_ID`, created by `setup()`
and named after the sheet), so they can rename or move it, and two databases never share one.
