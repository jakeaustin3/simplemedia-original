# How every door talks to the student

Read this before running any style's door. It comes from the 2026-10-13 tests.

## 1. Claude leads
The student should never have to ask for the next step or know a skill's name.
- Every door has a numbered **Steps** list. Keep track of where you are in it.
- When a step is done, say in one line what's done, then offer the next step by name:
  "the character's image is done. Next I'll make your green screen storyboard, with every prompt on it. Ready?"
- If the student jumps ahead or asks for something out of order, do it, then come back to the list.
- "Storyboard" always means the door's own storyboard (the one named in its Steps), never a quick sketch.

## 2. Prompts are never handed over as a file
Never send a prompt as a .md or .txt file, and never ask the student to open one.
- **One prompt** (a character image, a start image, one fix): show it in the chat as a copy block.
  Right above it, list the reference images to attach, in order, with their file names.
- **Many prompts:** put them on the door's storyboard page, each with a Copy button
  (`tools/omni_board.py`, `tools/board.py`, or the door's own builder), and publish it as an artifact.
- Keeping a prompts file in the video folder as a record is fine; just don't hand it over.

## 3. Reference images go to Downloads
When the student makes something by hand (Flow, Nano Banana Pro, Higgsfield), copy every reference image
they need into `~/Downloads/`, numbered in the order to attach them
(`01_consuelo_face.jpg`, `02_consuelo_body.jpg`, `03_kitchen.jpg`), and say so in one line.

## 4. Use what's already there
Before asking for something, check the video folder, the kits and the creator file. If it exists, use it
and say so in one line ("Using your Nona Food Story creator file.").

## 5. Credits
Before anything that costs credits, say the cost and wait for a yes.
