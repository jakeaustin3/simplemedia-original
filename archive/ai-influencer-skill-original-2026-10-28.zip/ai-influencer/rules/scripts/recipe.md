# Recipe and remedy scripts

<!-- AUTO:updated -->
Data refreshed 2026-10-08 from the howtomakeaivideos.com database.
<!-- /AUTO:updated -->

## How long

<!-- AUTO:length -->
Videos over 500K views: 1144. Middle half run 27–64 seconds (median 39s).
<!-- /AUTO:length -->

## Frameworks that win (by median views)

<!-- AUTO:frameworks -->
| Framework | Videos | Median views | Median length |
|---|---|---|---|
| comparison | 15 | 266K | 54s |
| demonstration | 1135 | 223K | 42s |
| myth bust | 39 | 212K | 51s |
| before after bridge | 120 | 207K | 45s |
| quick tip | 1077 | 206K | 27s |
| authority warning | 72 | 185K | 39s |
| pas | 442 | 183K | 68s |
| listicle | 645 | 180K | 62s |
| hook story offer | 726 | 163K | 76s |
| aida | 30 | 159K | 48s |
<!-- /AUTO:frameworks -->

## Hook patterns that win, with real hooks

Use the shape, not the words or the claim.

<!-- AUTO:hooks -->
**nostalgia discovery** · 113 videos · median 296K views · median 32s
- "How old were you when you discovered that if you put a slice of pineapple in a blender, a carrot, half a cucumber, the juice…" (17.0M)
- "At what age did you realize that if you slice an orange into thin pieces and put the pieces into boiling water with sliced onion,…" (5.2M)
- "How old was your dog when you found out about the baking soda flea remedy?" (4.1M)

**myth bust symptom** · 93 videos · median 289K views · median 51s
- "That pain in your back and hips may not be sciatica. It could be your kidneys and I have the" (21.0M)
- "That lower back and hip pain isn't always sciatica. You need to see this remedy." (11.0M)
- "That weight in your belly is not all fat. Five to 15 pounds of old food is caked inside your gut," (2.0M)

**personification greeting** · 140 videos · median 241K views · median 47s
- "Hello, I am Bittermelon. I catch excess sugar to keep blood flowing." (33.6M)
- "Hello, I am water. I thin out thick blood." (19.7M)
- "Hello, this is not shampoo. This is how hair was cleaned before damage existed." (17.1M)

**specific age elder** · 117 videos · median 233K views · median 106s
- "You're 102 and you've never taken medicine? Never. No, my friend." (6.5M)
- "If you are over 40, you need to know this. In a blender, mix a cup of pineapple, a stem of mint," (4.0M)
- "My grandma lived to 125 years old as an herbalist healer. Here are the health secrets I learned from her that will blow your mind." (3.9M)

**time bound diy promise** · 742 videos · median 206K views · median 43s
- "Flush your kidney stones in just three days and know you don't need a miracle diet or a $2,000 surgery." (45.9M)
- "Clean your vagina in just one night. In a glass, mix one teaspoon of turmeric," (34.0M)
- "You can get rid of prediabetes in under two minutes. And no, you don't need those expensive target pills to do so." (8.4M)

**watch what happens** · 190 videos · median 199K views · median 42s
- "Just wait, you'll see in a second. Wait, what is this stuff? It's actually warm. It's turning to foam. Okay, what is that?" (37.2M)
- "Soak your feet in vinegar and salt for 10 minutes before bed and watch what happens." (23.0M)
- "Put lemon on beets and just watch what happens. Pharmacies don't like this because half their customers would disappear overnight." (2.7M)

**triple stack body indicator** · 191 videos · median 189K views · median 62s
- "If you have oily skin drink cucumber juice If you have dark circles drink beetroot juice" (13.4M)
- "If you pee when you walk, when you laugh or when you cough, and the stream leaks out without warning, do not worry." (8.5M)
- "If the skin on your heels looks like this, dry, crack, crusty, this is not a foot problem." (6.6M)

**counter intuitive command** · 821 videos · median 185K views · median 48s
- "You can eat apples, spinach, chicken, yogurt, and it will not clear what has been sitting" (14.8M)
- "Put baking soda on the back of your neck and you will not believe what happens. In Chinese medicine, we have used this combination" (9.6M)
- "Do not drink this too often, my friend, because your family will think you are on ozempic." (9.2M)
<!-- /AUTO:hooks -->

## Pattern cards

### R1 · Did-you-know recipe
The whole recipe sits inside the hook sentence, so the viewer has the value in the first five seconds.
1. **Hook + recipe:** "Did you know if you mix [A] with [B] and [step], you get [result]?"
2. **Why it works:** one reason per ingredient, out loud ("The [A] brings… The [B]…").
3. **The routine:** when and how often ("every morning for seven days").
4. **What you'll notice:** in the senses, mild and believable.
5. **CTA:** comment a word or follow. Shop: the product as the easier version, then the CTA.

### R2 · Counter-intuitive command / watch what happens
Opens on an order the viewer can picture.
1. **Hook:** "Put [A] on [B] and watch what happens." / "Stop [common habit]. Do this instead."
2. **Authority or tension:** who knows this (grandmas, the elders, "pharmacies don't like this").
3. **Recipe with amounts.**
4. **One reason per ingredient.**
5. **CTA.**

### R3 · Time-bound DIY promise
1. **Hook:** "[Fix the problem] in [three days]. Just do this."
2. **"Listen up":** a beat that slows them down.
3. **Recipe** in one breath.
4. **Routine** and what they'll feel by the end.
5. **CTA.**

### R4 · Ingredient list (repeat line)
Several ingredients, each in the same short line, so viewers wait for the next one.
- "If you mix [A] with [B], [what happens]." × 4–6
- "Hello, I am [ingredient]. I [what I do]." × 5 (talking food, animation)
- "If a woman ate [A] every day for two weeks, she would [result]." × 5
End on the strongest one, then the CTA.

### R5 · Grandma / elder remedy
1. **Hook:** the remedy or the problem.
2. **Recipe + one reason per ingredient.**
3. **Where it comes from:** "The elders taught me this when I was young." / "Every grandmother in Mexico knows this."
4. **CTA:** often "comment [word] for my full remedy book".

### Shop bridge (any card)
The recipe is the free fix. The product comes in at the end as the lazy or stronger version:
"And on the days there's no time, one [product] does the same job." Then the CTA.

## Notes (Simple Media)

- Test 2026-10-08 (strawberry, pumpkin and beet bar with Physician's Choice probiotic): scripts written from
  general frameworks alone read like a cookbook and were rejected twice. Scripts built from R1, R2 and the
  layered method with grandma authority were "a lot better".
- Amounts can live on screen or in the caption when the spoken line gets long.
