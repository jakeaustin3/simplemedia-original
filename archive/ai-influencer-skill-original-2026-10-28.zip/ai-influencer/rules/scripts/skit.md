# Skit and story scripts

<!-- AUTO:updated -->
Data refreshed 2026-10-08 from the howtomakeaivideos.com database.
<!-- /AUTO:updated -->

## How long

<!-- AUTO:length -->
Videos over 500K views: 122. Middle half run 13–73 seconds (median 19s).
<!-- /AUTO:length -->

The length follows the card. A 15-second reaction skit and a two-minute storytime are both normal; don't cut a
storytime short to fit a skit length.

## Frameworks that win (by median views)

<!-- AUTO:frameworks -->
| Framework | Videos | Median views | Median length |
|---|---|---|---|
| listicle | 46 | 189K | 111s |
| hook story offer | 170 | 172K | 107s |
| pas | 16 | 139K | 87s |
| before after bridge | 20 | 108K | 62s |
<!-- /AUTO:frameworks -->

## Hook patterns that win, with real hooks

Use the shape, not the words or the claim.

<!-- AUTO:hooks -->
**philosophical existential** · 48 videos · median 227K views · median 82s
- "What we eat today is an honest family of 12 to stay toxic free in the modern world. We never eat out, we don't go…" (2.1M)
- "So me and my husband have been sleeping in separate bedrooms for the past two years, and on our 12-year anniversary last month, we got…" (2.1M)
- "My friend, sometimes nothing good happens to you because you are the good that happens to others." (1.6M)

**shock reveal** · 25 videos · median 195K views · median 34s
- "Wait, why does this feel so good? It has a headrest and armrests and the mesh is like letting the water like come up around…" (7.2M)
- "When I first bought this, it was just another cutting board. Now it's basically the center of my kitchen." (4.6M)
- "In 2022, five divers were sucked into an oil pipeline, a split-second accident that became a nightmare." (2.7M)

**specific age elder** · 14 videos · median 191K views · median 115s
- "I am 108 years old and I have never stepped foot in a hospital not even once." (622K)
- "I'm 87 years old and I've never stepped foot in a hospital, not even once," (528K)
- "How long have you two been married? Married? That's my daughter. No way. How old are you?" (465K)

**dialogue interview opener** · 199 videos · median 191K views · median 99s
- "I do makeup on women twice my age every single day. Here's why most foundations look bad on you." (9.5M)
- "Why are you putting ice on it? The ice helps loosen the grime and speeds up the reaction. But I can see you're in a…" (8.7M)
- "Hey, what's wrong with you? Your chest needs some care now." (6.9M)

**counter intuitive command** · 15 videos · median 111K views · median 81s
- "Stop spending time with people who don't make you feel good. Stop giving second chances to people who never gave you a first try." (743K)
- "Don't make me cook for you." (322K)
- "Don't ever embarrass me in front of my family again." (319K)

**empathetic chronic suffering** · 36 videos · median 102K views · median 24s
- "If you're facing the same issue Jada once did, comment legs and I'll send you a message" (3.1M)
- "How do you go back to sleep if you wake up between 2 and 3 a.m. in the middle of the night?" (474K)
- "If you are facing the same issue Letitia once did, comment here and I will send you a message" (363K)
<!-- /AUTO:hooks -->

## Pattern cards

### S1 · Public humiliation → helper (movie style, shop) · about 80–165 seconds, cuts every 2–3 seconds
The proven selling skit. Reference: Styles FULL row 1 (fb reel 1617284839873263) and at least 8 copies in the
database at 0.5M–1.2M views each. Write it as dialogue only; no narrator.
1. **Ambush (0–15s):** names called out ("Sheila? David?"), the partner compliments the rival, the hero catches
   it ("Are you flirting with her right in front of me?"), the rival insults her, the partner takes the rival's
   side ("Please leave. You're embarrassing me.").
2. **Silent walk-away:** two or three shots with no lines.
3. **Everything failed:** she lists what she already tried (the product kit's workarounds), and an expert brushes
   her off ("Your labs look fine. Give it more time.").
4. **Low point:** one line ("He left me today.").
5. **The helper appears:** someone from her past who changed ("Girl, is that you?" / "How do you look like this at
   52?" / "Because I stopped fighting the wrong thing."). The helper can be the healer or can send her to one.
6. **Diagnosis by question:** "When you press on your belly, is it hard or soft?" Then the real cause in two plain
   lines, then "It's not your fault. It was never your fault."
7. **Let me guess:** the helper names her daily symptoms. "How do you know that?" "Because that was me."
8. **The fix:** "What fixed it?" One ingredient or mechanism in one line.
9. **Objection + product:** "I've bought [things] that did nothing." The product with one or two proof points.
10. **CTA in dialogue:** "Where can I find it?" "Search [product] on Amazon, or the link in my profile."
11. **Optional twist:** back where it started, the tables turned (a last line, or "They can all look now.").

### S2 · Accusation → reveal → reversal · 15–40 seconds
Someone gets accused in public; the reveal flips who looks bad. References (Video DB, Videos tab): row 56
(security guard, "lift the shirt"), row 49 (proposal: "Wait, which one of us?"), row 50 (the "pro athlete" exposed).
1. **The accusation (hook):** a hard line in public ("Ma'am, stop right there.").
2. **Pressure:** she refuses, it escalates, people watch.
3. **The reveal:** the thing everyone assumed is wrong. The product can be the reveal.
4. **The reversal:** the accuser is the one embarrassed; one short line to close.

### S3 · Museum class (time-travel comparison) · about 45–60 seconds
Reference: Erick's Video DB (Drive transcript 1Vx_p6ba1_ccVyImt8TkFbWPFoWlOxi3T, "Okay class, this is what the
average male looked like in America by 2040"). A teacher walks kids through exhibits; the kids' jokes carry it.
1. **The bad future (hook):** "Okay class, this is what the average [person] looked like in [future year]." Kids
   joke and ask questions. "That's going to be you in twenty years."
2. **The good past:** "Here is what the average [person] looked like in [past year]." One quip per kid.
3. **The cause, planted as history:** a kid asks why; the teacher names what changed in one line.
4. **The fix, also as history:** "Eventually people started putting [it] back." The product in one or two proof points.
5. **The button:** one last kid joke; the teacher cuts it off ("Now, now. That's enough.").

### S4 · Prove-them-wrong bet · 45–75 seconds
A doubter threatens to take everything; a deadline; the mentor keeps the hero calm; the win; the apology.
References: rows 120 and 121 (dad sells the trading setup, "Give him until tonight", "$43,000. One trade.").
1. **The threat (hook):** the doubter takes or ends the thing the hero loves.
2. **The bet:** a deadline and a number ("If he makes more than $2,000 today, he keeps everything.").
3. **Pressure:** it goes wrong first; the doubter reaches for the plug.
4. **The mentor:** one calm line ("What does your setup say? Stay in.").
5. **The win** in one number, then **the apology** ("I owe you an apology.").
The product or method is what the mentor trusts.

### S5 · Escalation contest · 30–90 seconds
Stakes rise in steps until a twist at the top. References: row 82 (charity date auction, $10,000 to $1,000,000),
row 47 (dating-show roast, insult for insult).
1. **The setup line:** the host states the game ("Bidding starts at $100,000.").
2. **Three or more rising steps,** each topping the last.
3. **The twist at the top:** who wins or why is not who the viewer expected.
4. **A one-line button.**

### S6 · Kindness repaid (catchphrase comedy) · 45–90 seconds
Every line ends on the same tag word, which is the joke; underneath, a real story where kindness comes back.
References: row 125 ("c'u", the sandwich that becomes a promotion), row 122 ("Kuh").
1. **Giving:** the hero shares what little they have.
2. **Hard times:** the hero is the one with nothing.
3. **It comes back:** the people they helped show up for them.
4. **The payoff:** the reward, plus one last joke.

### Still to study
- Rows 133, 134, 135: skits told with pictures and no dialogue. Need the frames, not the transcript.
- Rows 43, 44, 55: very little speech; need the frames too.
- Row 4 (gas station, the dad's reframe) and row 35 (embarrassed at the arena, then the healer's three-foods
  pitch) look like variants of S1.
- Rows 2 and 3: still processing in the Video DB.

## Notes (Simple Media)

- Test 2026-10-08 ("Know your place" drama, the character as the healer, probiotic): skits written from guessed cards
  were rejected (too short, written instead of acted). S1 above is built from the real reference instead.
- Product can't-say lists apply to dialogue too: "I got slim" is a weight-loss claim; use the buyer's words
  ("I stopped feeling heavy and bloated").
