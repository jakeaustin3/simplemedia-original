# Script library

What Claude reads when it writes a script from scratch (own idea, no script). Built from the top videos in the
Simple Media video database and refreshed over time. Read only the file for the style being made.

- `recipe.md`: recipe and remedy videos (talking head, hands, voiceover).
- `skit.md`: skits and story videos (drama, two characters, storytime).

Each file has:
1. **Numbers from the database** (between AUTO markers): typical length, the frameworks that win, the hook
   patterns that win with real example hooks. These get refreshed; don't edit them by hand.
2. **Pattern cards**: the order of beats for each winning structure and what each beat does.
3. **Notes**: Simple Media's own rules and lessons from tests. Kept across refreshes.

## How to write scripts with it

1. **Know the style and the idea first.** No script without them. If the idea is loose, run the idea tools first:
   - **Run the tap:** 15–20 one-line ideas, fast, weak ones included.
   - **Variation chain:** the picked idea, then about 5 versions, each changing one thing (a word, more specific, a clearer promise). Every version must still fit the style.
   - **Speed limit:** push the picked idea too far, then tame it back to something the character can film. Show wild, past the limit, doable.
2. **Pick the patterns yourself.** The student doesn't choose a framework. Match the idea to 3 different pattern cards from the style file.
3. **Write 3–5 scripts side by side**, split into the same named sections so the student can mix and match ("hook from 2, body from 4").
4. **Use the example hooks for shape and rhythm, never for their lines or their claims.** The example videos often make health claims we can't make. The product's `Can't say` row always wins.
5. **Then loop** on what the student asks: "five more like 3, but change X", "only the hook", "start over".

## Rules for every script

- Fifth-grade words. Short sentences. Sounds spoken, not written.
- One angle per video.
- Talk about people ("most people", "your gut") more than "I, I, I". The character's own story is the exception in storytime skits.
- One reason per ingredient or step, said out loud.
- Nothing invented about results, money or health. Mirror the product label.
- Growth video: no product, ends on follow or comment. Shop video: the product shows up as the easier or stronger version of the free fix, then the CTA.
- Spell numbers out for voice tools.
