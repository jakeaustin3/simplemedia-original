#!/usr/bin/env python3
"""Run a batch of Seedance 2.5 clips through kie.ai, one after another.

Wraps tools/kie_video.py (upload, create, poll, download,
log) and adds what a multi-clip skit needs: validation before anything is
paid for, a state file so a queued job is resumed instead of paid for twice,
versioned file names, and a contact sheet per clip for checking the result.

Spec (JSON):
{
  "scene": "dinner",                       # file stem prefix
  "out_dir": "Videos/<Character>/<YYYY-MM>/<Video topic>/clips",
  "log_dir": "Videos/<Character>",        # the shared log.tsv lives here
  "res": "720p", "ar": "9:16", "audio": true,
  "clips": [
    {"name": "clipA_ask", "prompt": "prompts/clipA_ask.txt", "dur": 28,
     "images": ["Kits/Characters/<name>/locks/02_front_close_up.jpg", "Kits/Characters/<name>/locks/01_front_full_body.jpg"]}
  ]
}
Prompt paths are relative to out_dir. Images are @Image1, @Image2 … in order.

  python3 run_clips.py spec.json --dry-run    validate + cost, nothing sent
  python3 run_clips.py spec.json              run every clip not yet done
  python3 run_clips.py spec.json --only clipA_ask
  python3 run_clips.py spec.json --sheet      rebuild contact sheets only

State lives next to the spec as <spec>.state.json. A clip with a task id and
no output is resumed by polling that task, never resubmitted.
"""

import argparse
import json
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))  # kie_video.py sits next to this file
import kie_video as kv  # noqa: E402

CREDITS_PER_SEC = {"480p": 28, "720p": 63, "1080p": 114}  # 1080p is an estimate
POLL_TIMEOUT = 4 * 3600  # kie's queue has held a job 70+ minutes
REPO = Path(__file__).resolve().parents[4]
CHECKS = REPO / ".tmp" / "seedance-checks"
SHOT_RE = re.compile(r"SHOT\s+(\d+)\s*\((\d+):(\d+)\s*[–-]\s*(\d+):(\d+)\)")


def p(path, base=None):
    path = Path(path).expanduser()
    return path if path.is_absolute() or base is None else base / path


def shots(prompt):
    """[(shot number, start s, end s)] from the SHOT lines of a prompt."""
    return [(int(n), int(a) * 60 + int(b), int(c) * 60 + int(d))
            for n, a, b, c, d in SHOT_RE.findall(prompt)]


def validate(spec):
    """Return (problems, warnings). Problems block the run."""
    problems, warnings = [], []
    out = p(spec["out_dir"])
    if spec.get("res") not in CREDITS_PER_SEC:
        problems.append(f"res must be one of {sorted(CREDITS_PER_SEC)}")
    for c in spec["clips"]:
        tag = c["name"]
        pf = p(c["prompt"], out)
        if not pf.is_file() or not pf.read_text().strip():
            problems.append(f"{tag}: prompt file missing or empty: {pf}")
            continue
        text = pf.read_text()
        dur = c.get("dur")
        if not isinstance(dur, int) or not 1 <= dur <= 30:
            problems.append(f"{tag}: dur must be a whole number 1–30, got {dur}")
        imgs = c.get("images", [])
        for i in imgs:
            if not p(i).is_file():
                problems.append(f"{tag}: image not found: {i}")
        refs = {int(n) for n in re.findall(r"@Image(\d+)", text)}
        if refs and max(refs) > len(imgs):
            problems.append(f"{tag}: prompt uses @Image{max(refs)} but only "
                            f"{len(imgs)} image(s) are attached")
        unused = set(range(1, len(imgs) + 1)) - refs
        if unused:
            warnings.append(f"{tag}: image(s) {sorted(unused)} attached but "
                            f"never named in the prompt")
        sh = shots(text)
        if sh and isinstance(dur, int) and abs(sh[-1][2] - dur) > 1:
            warnings.append(f"{tag}: shots end at {sh[-1][2]}s, clip is {dur}s")
        if re.search(r'^[A-Z][A-Z0-9 ]+:\s*"', text, re.M) and not spec.get("audio"):
            warnings.append(f"{tag}: has dialogue but audio is off")
    return problems, warnings


def load_state(path):
    return json.loads(path.read_text()) if path.exists() else {}


def save_state(path, state):
    path.write_text(json.dumps(state, indent=2))


def next_version(out, stem):
    n = 1
    while any(out.glob(f"{stem}_v{n}.*")):
        n += 1
    return f"{stem}_v{n}"


def sheet(video, prompt, name):
    """One frame from the middle of every shot, side by side."""
    if not shutil.which("ffmpeg"):
        return None
    CHECKS.mkdir(parents=True, exist_ok=True)
    sh = shots(prompt) or [(1, 0, 2)]
    frames = []
    for n, a, b in sh:
        f = CHECKS / f"{name}_shot{n}.jpg"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", str((a + b) / 2),
                        "-i", str(video), "-frames:v", "1", "-vf", "scale=270:-1",
                        str(f)], check=False)
        if f.exists():
            frames.append(f)
    if not frames:
        return None
    dest = CHECKS / f"{name}_sheet.jpg"
    if len(frames) == 1:
        shutil.copy(frames[0], dest)
    else:
        args = ["ffmpeg", "-v", "error", "-y"]
        for f in frames:
            args += ["-i", str(f)]
        args += ["-filter_complex", f"hstack=inputs={len(frames)}", str(dest)]
        subprocess.run(args, check=False)
    return dest if dest.exists() else None


def run_clip(spec, c, state, state_path):
    out, log_dir = p(spec["out_dir"]), p(spec.get("log_dir", spec["out_dir"]))
    text = p(c["prompt"], out).read_text()
    st = state.setdefault(c["name"], {})
    if st.get("output"):
        print(f"= {c['name']} already done → {st['output']}")
        return
    print(f"=== {c['name']} {c['dur']}s {spec['res']} "
          f"~{CREDITS_PER_SEC[spec['res']] * c['dur']} credits ===", flush=True)
    if not st.get("task_id"):
        urls = [kv.upload(p(i)) for i in c.get("images", [])]
        print(f"uploaded {len(urls)} image(s)", flush=True)
        st["task_id"] = kv.create_task(
            text, urls, resolution=spec["res"], aspect_ratio=spec.get("ar", "9:16"),
            duration=c["dur"], generate_audio=spec.get("audio", True))
        st["submitted"] = datetime.now().isoformat(timespec="seconds")
        save_state(state_path, state)  # before polling: a timeout must resume, not resubmit
        print(f"task {st['task_id']}", flush=True)
    else:
        print(f"resuming task {st['task_id']}", flush=True)
    url, credits = kv.poll(st["task_id"], timeout=POLL_TIMEOUT, interval=20)
    stem = next_version(out, f"{spec['scene']}_{c['name']}")
    dest = kv.download(url, out, stem)
    kv.log(log_dir, {
        "time": datetime.now().isoformat(timespec="seconds"),
        "task_id": st["task_id"], "mode": "ingredients" if c.get("images") else "text",
        "prompt": text, "inputs": ";".join(p(i).name for i in c.get("images", [])),
        "res": spec["res"], "ar": spec.get("ar", "9:16"), "dur": c["dur"],
        "credits": credits, "output": str(dest),
    })
    st.update(output=str(dest), credits=credits)
    save_state(state_path, state)
    print(f"SAVED {dest}  ({credits} credits)", flush=True)
    s = sheet(dest, text, stem)
    if s:
        print(f"SHEET {s}", flush=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("spec")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--only", action="append", default=[])
    ap.add_argument("--sheet", action="store_true")
    a = ap.parse_args()

    spec_path = Path(a.spec).expanduser()
    spec = json.loads(spec_path.read_text())
    state_path = spec_path.with_suffix(".state.json")
    state = load_state(state_path)
    clips = [c for c in spec["clips"] if not a.only or c["name"] in a.only]

    problems, warnings = validate({**spec, "clips": clips})
    for w in warnings:
        print(f"WARN  {w}")
    for pr in problems:
        print(f"STOP  {pr}")
    total = sum(CREDITS_PER_SEC.get(spec.get("res"), 0) * c.get("dur", 0) for c in clips)
    print(f"{len(clips)} clip(s), ~{total} credits at {spec.get('res')}")
    if problems:
        sys.exit(1)

    if a.sheet:
        out = p(spec["out_dir"])
        for c in clips:
            o = state.get(c["name"], {}).get("output")
            if o:
                print(f"SHEET {sheet(Path(o), p(c['prompt'], out).read_text(), Path(o).stem)}")
        return
    if a.dry_run:
        return

    failed = []
    for c in clips:
        try:
            run_clip(spec, c, state, state_path)
        except TimeoutError as e:
            print(f"STILL QUEUED {c['name']}: {e}. Rerun the same command to resume "
                  f"polling. Do not resubmit.", flush=True)
            failed.append(c["name"])
        except RuntimeError as e:
            msg = str(e)
            print(f"FAILED {c['name']}: {msg}", flush=True)
            failed.append(c["name"])
            if "createTask" in msg:  # nothing was created; likely balance or a rejected prompt
                print("Stopping the batch: createTask was refused.", flush=True)
                break
            if "failed:" in msg:  # the task itself failed; clear it so a fix can resubmit
                state[c["name"]].pop("task_id", None)
                save_state(state_path, state)
    if failed:
        print(f"NOT DONE: {', '.join(failed)}")
        sys.exit(2)


if __name__ == "__main__":
    main()
