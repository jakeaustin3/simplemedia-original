"""Seedance recipe storyboard: regroup a phase-1 clip map (/pull or /breakdown) into Seedance generations.

  python3 seedance_board.py <name> [--max 30]    <name>/clipmap.json -> <name>/seedance-plan.json + seedance-storyboard.png

Rules (Simple Media board rules, 2026-09-30):
- One generation renders the run end to end (aim 20-30s, never over --max). Character kit = reference images,
  setting described in words, the original video = reference for the recipe look.
- Pack clips in order. When the next clip does not fit, the generation ENDS ON that clip's first frame
  (hand-off) and the next generation uses that end frame as its start frame.
- A single clip longer than --max is cut into parts at --max (each part chains the same way).
- Edit seedance-plan.json by hand if needed, then re-run with --plan to render it as is.
"""
import base64, html, json, math, sys
from vidtools import HERE, OUT_PNG, TO_PNG, run, fit_miro, secs

e = html.escape


def balance(its, mx):
    """Fewest generations that fit mx, cut at clip boundaries so sizes are as even as possible; never cut between two recipe steps."""
    n = len(its); dur = lambda i, j: its[j - 1]["b"] - its[i]["a"]
    k = 1
    while True:
        best = {0: (0, [])}  # DP over (cut index) -> (worst deviation, cuts)
        for _ in range(k):
            nb = {}
            for i, (dv, cuts) in best.items():
                for j in range(i + 1, n + 1):
                    if dur(i, j) > mx: break
                    midstep = j < n and its[j]["structure"].startswith("Step") and its[j - 1]["structure"].startswith("Step")
                    cand = (max(dv, abs(dur(i, j) - (its[-1]["b"] - its[0]["a"]) / k)) + (100 if midstep else 0), cuts + [j])
                    if j not in nb or cand[0] < nb[j][0]: nb[j] = cand
            best = nb
        if n in best:
            cuts = [0] + best[n][1]
            return [its[a:b] for a, b in zip(cuts, cuts[1:])]
        k += 1


def plan(clips, mx):
    items = []  # split any clip longer than mx
    for i, c in enumerate(clips, 1):
        a, b = secs(c["time"])
        n = max(1, math.ceil((b - a) / mx - 1e-6))
        for k in range(n):
            pa, pb = a + (b - a) * k / n, a + (b - a) * (k + 1) / n
            items.append(dict(c, n=i, part=f"{k+1}/{n}" if n > 1 else "", a=round(pa, 2), b=round(pb, 2),
                              frame=c["frame"] if k == 0 else round(pa + 0.3, 2)))
    runs = []  # consecutive clips per tool: clip "tool": "omni" = one still per clip in Omni, default = Seedance
    for it in items:
        t = it.get("tool", "seedance")
        if runs and runs[-1][0] == t: runs[-1][1].append(it)
        else: runs.append((t, [it]))
    groups = []
    for t, its in runs:
        if t != "seedance": groups.append((t, its)); continue
        groups += [(t, g) for g in balance(its, mx)]
    out, sg, og = [], 0, 0
    keys = ("n", "part", "a", "b", "structure", "dialogue", "action", "frame")
    for gi, (t, cs) in enumerate(groups):
        nxt = groups[gi + 1] if gi + 1 < len(groups) else None
        chain = nxt is not None and t == "seedance" and nxt[0] == "seedance"
        if t == "seedance": sg += 1; gid = f"G{sg}"
        else: og += 1; gid = f"O{og}"
        prev_chain = gi > 0 and t == "seedance" and groups[gi - 1][0] == "seedance"
        out.append({"gen": gid, "tool": t, "time": f"{cs[0]['a']:g}–{cs[-1]['b']:g}", "dur": round(cs[-1]["b"] - cs[0]["a"], 1),
                    "start": f"end frame of G{sg-1}" if prev_chain else ("one still per clip" if t != "seedance" else f"first frame of clip {cs[0]['n']}"),
                    "end_on": f"clip {nxt[1][0]['n']} first frame (hand-off to G{sg+1})" if chain else ("each clip's own end" if t != "seedance" else f"last frame of clip {cs[-1]['n']}"),
                    "handoff_frame": round(nxt[1][0]["a"] + 0.3, 2) if chain else None,
                    "clips": [{k: c[k] for k in keys} for c in cs]})
    return out


def render(name, gens, meta):
    d = HERE / name; v = d / "source/video.mp4"; (d / "clips").mkdir(exist_ok=True)
    TW, TH, G = 150, 267, 10

    def img(t, tag):
        f = d / f"clips/sd_{tag}.jpg"
        run("ffmpeg", "-v", "error", "-y", "-ss", str(t), "-i", str(v), "-frames:v", "1", "-vf", f"scale={TW*2}:-1", str(f))
        return "data:image/jpeg;base64," + base64.b64encode(f.read_bytes()).decode()

    blocks = []
    for gi, g in enumerate(gens):
        thumbs = "".join(f'<div class="t"><img src="{img(c["frame"], f"{g["gen"]}_{j}")}"><div class="cap">{c["n"]}{" · "+c["part"] if c["part"] else ""} · {e(c["structure"])}</div></div>'
                         for j, c in enumerate(g["clips"]))
        if g["handoff_frame"] is not None:
            thumbs += f'<div class="t ho"><img src="{img(g["handoff_frame"], g["gen"] + "_ho")}"><div class="cap">END FRAME → {e(gens[gi+1]["gen"])}</div></div>'
        lines = " ".join(c["dialogue"] for c in g["clips"] if not c["part"] or c["part"].startswith("1/"))
        om = g.get("tool", "seedance") != "seedance"
        note = (f'<b>{e(g["gen"])} · {e(g["time"])}s · {g["dur"]:g}s · {len(g["clips"])} Omni (Flow) clips.</b><br>One still per clip, animated image → video, lip-synced. Character kit as reference.' if om else
                f'<b>{e(g["gen"])} · {e(g["time"])}s · {g["dur"]:g}s · one Seedance generation.</b><br>'
                f'Start: {e(g["start"])}. Character kit as reference, describe the setting, original video as reference for the look.<br>'
                f'End on: {e(g["end_on"])}.')
        blocks.append(f'<div class="gen"><div class="note">{note}</div><div class="box{" om" if om else ""}">{thumbs}</div>'
                      f'<div class="say"><span class="k">Script</span> {e(lines)}</div></div>')
    body = blocks[0]
    for gi in range(1, len(blocks)):
        chained = gens[gi - 1]["handoff_frame"] is not None
        body += f'<div class="arr{"" if chained else " cut"}">→<span>{"end frame = start frame" if chained else "hard cut, edit together"}</span></div>' + blocks[gi]
    total = sum(g["dur"] for g in gens)
    W = sum((len(g["clips"]) + (1 if g["handoff_frame"] is not None else 0)) * (TW + G) + 60 for g in gens) + (len(gens) - 1) * 150 + 40
    css = f"""<style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@500;700;800&family=JetBrains+Mono:wght@500&display=swap');
body{{margin:0;background:#f2f1eb;font-family:Inter,sans-serif;color:#16191f}}
.stage{{width:{max(W, 1100)}px;padding:48px 56px;background-image:radial-gradient(rgba(20,25,40,.08) 1.3px,transparent 1.3px);background-size:26px 26px}}
.lab{{font:500 12px 'JetBrains Mono';letter-spacing:.12em;text-transform:uppercase;color:#e8604c;margin-bottom:6px}}
h1{{font-weight:800;font-size:30px;margin:0 0 4px}}.sub{{font-size:15px;color:#6e7683;margin:0 0 30px}}
.row{{display:flex;align-items:flex-start}}.gen{{display:flex;flex-direction:column;gap:14px}}
.note{{font-size:14.5px;line-height:1.5;text-align:center;max-width:{TW*4}px;align-self:center}}
.box{{display:flex;gap:{G}px;border:3px solid #c62828;border-radius:28px;padding:24px}}
.t img{{width:{TW}px;height:{TH}px;object-fit:cover;border-radius:5px;display:block}}
.box.om{{border-color:#7b6cf6}}.arr.cut{{color:#7b6cf6}}
.ho img{{outline:4px solid #2e9e55;outline-offset:3px}}.ho .cap{{color:#2e9e55}}
.cap{{font:500 10px 'JetBrains Mono';color:#6e7683;margin-top:6px;width:{TW}px}}
.say{{font-size:13px;line-height:1.45;background:#fff;border-radius:8px;padding:10px 14px;box-shadow:0 1px 4px #0002;max-width:{TW*5}px}}
.k{{font:500 10px 'JetBrains Mono';text-transform:uppercase;letter-spacing:.08em;color:#c62828}}
.arr{{align-self:center;font-size:56px;color:#2e9e55;margin:0 30px;text-align:center;line-height:1}}.arr span{{display:block;font:500 10px 'JetBrains Mono';width:90px}}
.foot{{margin-top:30px;font-size:15px;background:#fff;border-left:4px solid #c62828;border-radius:8px;padding:12px 16px;max-width:900px;box-shadow:0 1px 4px #0002}}</style>"""
    inner = (f'<div class="lab">Seedance recipe storyboard{" · Omni + Seedance" if any(g.get("tool","seedance")!="seedance" for g in gens) else ""}</div><h1>{e(meta["title"])}</h1>'
             f'<p class="sub">{e(meta["link"])} · {total:g}s · {sum(1 for g in gens if g.get('tool','seedance')=='seedance')} Seedance generation(s) · max 30s each</p>'
             f'<div class="row">{body}</div>'
             f'<div class="foot"><b>Next:</b> /seedance-prompt-builder writes one prompt per generation (character kit + setting + this plan).</div>')
    p = d / "seedance-storyboard.html"
    p.write_text(f'<!doctype html><html><head><meta charset="utf-8"><title>{e(meta["title"])}</title>{css}</head><body><div class="stage">{inner}</div></body></html>')
    png = d / "seedance-storyboard.png"
    run("python3", str(TO_PNG), str(p), "--full-page", "--size", f"{max(W, 1100) + 112}x700", "--out", str(png))
    fit_miro(png); OUT_PNG.mkdir(parents=True, exist_ok=True)
    (OUT_PNG / f"{name}-seedance-storyboard.png").write_bytes(png.read_bytes()); print(png)


if __name__ == "__main__":
    name = sys.argv[1]; d = HERE / name
    mx = float(sys.argv[sys.argv.index("--max") + 1]) if "--max" in sys.argv else 30
    meta = json.load(open(d / "clipmap.json"))
    if "--plan" in sys.argv:
        gens = json.load(open(d / "seedance-plan.json"))
    else:
        gens = plan(meta["clips"], mx); json.dump(gens, open(d / "seedance-plan.json", "w"), indent=1)
    for g in gens:
        print(g["gen"], g["time"], f'{g["dur"]}s', "clips", [c["n"] for c in g["clips"]], "| end on:", g["end_on"])
    render(name, gens, meta)
