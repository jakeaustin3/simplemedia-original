"""Talks to the script inside your Google Sheet (google-sheet/Code.gs)."""

import base64
import mimetypes
import os
import re
import time
from pathlib import Path

import requests

MAX_UPLOAD_MB = 35  # bigger files are skipped (Google's limit per request is ~50 MB)
RETRIES = 4
RETRY_WAIT_SECONDS = 15  # waits 15s, 30s, 45s between tries


class Sheet:
    def __init__(self, url: str, tab: str | None = None):
        self.url = url
        self.tab = tab  # None = the Videos tab; a name = a research tab beside it

    def _post_body(self, action: str, payload: dict) -> dict:
        body = {"action": action, **payload}
        if self.tab:
            body["tab"] = self.tab
        return body

    def _call(self, action: str, expect: str = "", **payload) -> dict:
        """Every action is safe to repeat, so Google's hiccups (an error page instead of an
        answer, a timeout, a half answer) are retried a few times before giving up."""
        problem = ""
        for attempt in range(RETRIES):
            if attempt:
                print(f"  🔁 Google Sheet didn't answer properly ({problem}), "
                      f"trying again ({attempt + 1}/{RETRIES})")
                time.sleep(RETRY_WAIT_SECONDS * attempt)
            try:
                resp = self._post(self._post_body(action, payload))
            except requests.RequestException as e:
                problem = f"{action}: {type(e).__name__}"
                continue
            try:
                data = resp.json()
            except ValueError:
                title = re.search(r"<title>(.*?)</title>", resp.text, re.S | re.I)
                problem = f"{action}: HTTP {resp.status_code} " + (
                    title.group(1).strip() if title else resp.text[:80].replace("\n", " "))
                continue
            if not isinstance(data, dict) or (data.get("ok") and not data.get("error")
                                              and expect and expect not in data):
                problem = f"{action}: incomplete answer {str(data)[:80]}"
                continue
            if not data.get("ok") or data.get("error"):
                raise RuntimeError(f"Google Sheet script error: {data.get('error')}")
            return data
        raise RuntimeError(f"Google Sheet script didn't answer after {RETRIES} tries ({problem}). If this keeps "
                           "happening, check SHEET_SCRIPT_URL in settings.txt and that the "
                           "deployment's access is set to 'Anyone'.")

    def _post(self, body: dict) -> requests.Response:
        """Google answers a POST with a redirect to the result (script.googleusercontent.com),
        which is fetched with GET. Sometimes it redirects to another script.google.com address
        instead; following that with GET would drop the body and only reach doGet(), so the
        request is POSTed again there."""
        url = self.url
        for _ in range(5):
            resp = requests.post(url, json=body, timeout=300, allow_redirects=False)
            if resp.status_code not in (301, 302, 303, 307, 308):
                return resp
            url = resp.headers.get("Location", "")
            if "googleusercontent.com" in url:
                return requests.get(url, timeout=300)
            print(f"  ↪️  Google sent the request somewhere else ({url.split('?')[0][:60]}), sending it there")
        return resp

    def start(self, link: str, name: str) -> dict:
        return self._call("start", expect="duplicate", link=link, name=name)

    def redo(self, link: str, name: str) -> str:
        """Process a video again: keeps (or restores) its row and empties its Drive folder. Returns the folder ID."""
        return self._call("redo", expect="folderId", link=link, name=name)["folderId"]

    def pending(self) -> list[str]:
        return self._call("pending", expect="links")["links"]

    def forget(self, link: str) -> bool:
        """Un-delete: pasting this link will add the video again."""
        return self._call("forget", link=link)["forgotten"]

    def copy(self, rows: list[dict], source: str | None = None) -> dict:
        """Copy finished rows ([{link, note}], top first) from Videos (or `source`) into this tab."""
        return self._call("copy", expect="copied", rows=rows, **({"from": source} if source else {}))

    def add_creator(self, name: str, platform: str, link: str) -> bool:
        """Save a creator's profile to the Creators tab. False if they're already there."""
        return not self._call("creator", expect="duplicate", name=name, platform=platform,
                              link=link)["duplicate"]

    def fail(self, link: str, error: str):
        self._call("fail", link=link, error=error[:300])

    def _upload(self, folder_id: str, files: list[tuple[str, Path]]) -> dict:
        payload = []
        for drive_path, local in files:
            if local.stat().st_size > MAX_UPLOAD_MB * 1024 * 1024:
                print(f"  ⚠️  {local.name} is over {MAX_UPLOAD_MB} MB — kept on this computer only")
                continue
            payload.append({
                "path": drive_path,
                "mimeType": mimetypes.guess_type(local.name)[0] or "application/octet-stream",
                "data": base64.b64encode(local.read_bytes()).decode(),
            })
        if not payload:
            return {}
        return self._call("upload", expect="ids", folderId=folder_id, files=payload)["ids"]

    def save_video(self, result: dict, folder_id: str, note: str = ""):
        """Upload the finished folder, then fill in the row. note goes on the thumbnail cell
        (only used by research tabs)."""
        folder = result["folder"]
        rel = lambda p: str(p.relative_to(folder))

        # Big files one per request, small files together.
        ids = {}
        ids.update(self._upload(folder_id, [(rel(result["video"]), result["video"])]))
        ids.update(self._upload(folder_id, [(result["zip"].name, result["zip"])]))
        small = [result["thumbnail"], result["storyboard"], result["transcript_file"],
                 result["scenes_file"], *result["frames"]]
        ids.update(self._upload(folder_id, [(rel(p), p) for p in small]))

        return self._call(
            "finish",
            link=result["link"],
            folderId=folder_id,
            zipId=ids.get(result["zip"].name, ""),
            thumbnailId=ids[rel(result["thumbnail"])],
            storyboardId=ids[rel(result["storyboard"])],
            frameIds=[ids[rel(f)] for f in result["frames"]],
            transcript=result["transcript"],
            note=note,
        )


def from_env(required: bool = True, tab: str | None = None) -> Sheet | None:
    url = os.getenv("SHEET_SCRIPT_URL", "").strip()
    if not url.startswith("https://script.google.com/"):
        if required:
            raise SystemExit("SHEET_SCRIPT_URL is missing in settings.txt. "
                             "Tell Claude Code: Connect my Google Sheet.")
        return None
    return Sheet(url, tab)
