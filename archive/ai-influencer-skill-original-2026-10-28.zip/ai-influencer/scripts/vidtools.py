"""Shared tools for /pull and /breakdown. One work folder per video under Videos/_work/<name>/.

  python3 vidtools.py fetch-row <row> [tab]    Video DB row (Videos tab, or e.g. "styles full") -> <name>/ (zip unpacked into source/, row.json)
  python3 vidtools.py fetch-link <url> [name]  link -> <name>/ (yt-dlp + cuts + Whisper, via breakdown.py)
  python3 vidtools.py strips <name>            one 5-frame strip per DB scene / raw shot -> <name>/strips/
  python3 vidtools.py strip <name> <a> <b>     one strip for a time range (seconds) -> printed path
  python3 vidtools.py render <name>            <name>/clipmap.json -> clip-map.png + storyboard.png
  python3 vidtools.py upload <name>            PNGs -> the row's Drive folder (pull only; never touches the sheet)

clipmap.json: {title, label, link, dur, tool, clips:[{time, structure, dialogue, still, action, frame, scene?}]}
scene (optional) = generation group, e.g. "S2"; set when the student picks a multi-shot tool (Seedance).
"""
import base64, html, json, pathlib, re, shutil, subprocess, sys, urllib.request, zipfile

TOOLS = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path.home() / "SimpleMedia"  # the student's workspace
HERE = ROOT / "Videos/_work"  # work folders, one per video (ignored by git)
HERE.mkdir(parents=True, exist_ok=True)
BOT = TOOLS  # sheet.py lives next to this file
ROOT_VIDEOS = ROOT / "Videos/_database"  # optional local copies of DB rows
OUT_PNG = ROOT / "Videos/Teardowns"
TO_PNG = TOOLS / "to_png.py"


def sheet(tab=None):
    sys.path.insert(0, str(BOT))
    from sheet import Sheet
    p = ROOT / "settings.txt"
    url = next((l.split("=", 1)[1].strip() for l in (open(p) if p.exists() else []) if l.startswith("SHEET_SCRIPT_URL=")), "")
    if not url:
        raise SystemExit("Your Video Database sheet is not connected yet (no SHEET_SCRIPT_URL in settings.txt). "
                         "Ask Claude to 'connect my sheet' first.")
    return Sheet(url, tab)


def run(*cmd):
    subprocess.run(cmd, check=True)


def duration(v):
    return float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(v)]))


def video_dirs():
    """Folders where the Video Database bot keeps its own copy of every video it processed."""
    return [d for d in (BOT / "videos", ROOT_VIDEOS) if d and d.is_dir()]


def local_copy(link):
    """The bot's local folder for this link (video.mp4, transcript, scenes, frames, storyboard), if it has one."""
    m = re.search(r"(?:reels?|video|t)/([\w-]+)", link or "")
    if not m: return None
    for root in video_dirs():
        for d in root.iterdir():
            if d.is_dir() and d.name.endswith("_" + m.group(1)) and (d / "video.mp4").exists():
                return d
    return None


def drive_zip(file_id, z):
    """Download a Drive zip, getting past the 'too big to scan for viruses' page."""
    urllib.request.urlretrieve(f"https://drive.usercontent.google.com/download?id={file_id}&export=download&confirm=t", z)
    if not zipfile.is_zipfile(z):
        z.unlink(); sys.exit("Drive did not send the zip (file not shared as 'anyone with the link'?).")


def fetch_row(row, tab=None):
    """Row <row> of the Videos tab (or `tab`, e.g. "styles full"). Uses the bot's local copy when it has one,
    otherwise the row's zip from Drive. Finds the link / folder / zip by content, so tabs with extra columns work."""
    r = sheet(tab)._call("read", expect="rows", formulas=True)["rows"][row - 2]
    cells = " ".join(str(c) for c in r["formulas"]) + " " + " ".join(str(v) for v in r.values() if isinstance(v, str))
    link = re.search(r"https://(?:www\.)?(?:tiktok|instagram|facebook|youtube)\.com/[^\"\s,)]+", cells)
    link = link.group(0) if link else ""
    folder = re.search(r"drive/folders/([\w-]+)", cells)
    zip_id = re.search(r"uc\?export=download&id=([\w-]+)", cells)
    name = f"row{row}" + (f"-{re.sub(r'\W+', '', tab.lower())}" if tab else "")
    d = HERE / name; src = d / "source"; src.mkdir(parents=True, exist_ok=True)
    local = local_copy(link)
    if (src / "video.mp4").exists():
        pass  # already fetched
    elif local:
        shutil.copytree(local, src, dirs_exist_ok=True)
    elif zip_id:
        z = src / "row.zip"
        drive_zip(zip_id.group(1), z)
        with zipfile.ZipFile(z) as zf:
            for m in zf.namelist():
                rel = pathlib.Path(*pathlib.Path(m).parts[1:])
                if m.endswith("/") or not rel.parts: continue
                out = src / rel; out.parent.mkdir(parents=True, exist_ok=True)
                out.write_bytes(zf.read(m))
    else:
        sys.exit(f"Row {row} has no Drive folder / zip yet (link {link}). Use /breakdown on the link instead.")
    transcript = (src / "transcript.txt").read_text() if (src / "transcript.txt").exists() else ""
    json.dump({"row": row, "tab": tab or "Videos", "link": link, "folderId": folder.group(1) if folder else "",
               "transcript": transcript}, open(d / "row.json", "w"), indent=1)
    v = src / "video.mp4"
    print(f"{name}: {link} · {duration(v):.1f}s · {'local copy' if local else 'Drive zip'} · folder {folder.group(1) if folder else '-'}")
    if (src / "storyboard.jpg").exists(): print(f"Bot storyboard: {src / 'storyboard.jpg'}")
    print((src / "scenes.txt").read_text()[:4000])
    return name


def fetch_link(url, name=None):
    name = name or "link-" + re.sub(r"\W+", "", url.rstrip("/").split("/")[-1])[:20]
    d = HERE / name; (d / "source").mkdir(parents=True, exist_ok=True)
    v = d / "source/video.mp4"
    if not v.exists():
        run("yt-dlp", "-q", "-f", "mp4/best", "-o", str(v), url)
    json.dump({"link": url}, open(d / "row.json", "w"))
    subprocess.run([sys.executable, str(TOOLS / "breakdown.py"), name], check=True, cwd=HERE)  # cuts, shots, Whisper -> <name>/breakdown/
    print((d / "breakdown/audio.txt").read_text())
    return name


def ranges(d):
    """DB scenes (pull) or raw cuts (breakdown) as (a, b) seconds."""
    s = d / "source/scenes.txt"
    if s.exists():
        t = lambda m: int(m.split(":")[0]) * 60 + int(m.split(":")[1])
        return [(t(a), t(b)) for a, b in re.findall(r"\[(\d+:\d+)[–-](\d+:\d+)\]", s.read_text())]
    return [(float(a), float(b)) for _, a, b in (l.split() for l in open(d / "breakdown/shots.txt"))]


def strip(d, a, b, out, n=5):
    v = d / "source/video.mp4"; b = min(b, duration(v) - 0.05)
    tmp = out.with_suffix(""); tmp.mkdir(exist_ok=True)
    for k in range(n):
        t = a + (b - a) * (k + 0.5) / n
        run("ffmpeg", "-v", "error", "-y", "-ss", f"{t:.2f}", "-i", str(v), "-frames:v", "1", "-vf", "scale=240:-1", str(tmp / f"{k}.jpg"))
    run("ffmpeg", "-v", "error", "-y", "-i", str(tmp / "%d.jpg"),
        "-vf", f"tile={n}x1:padding=3:color=white", str(out))
    shutil.rmtree(tmp)
    return out


def strips(name):
    d = HERE / name; (d / "strips").mkdir(exist_ok=True)
    for i, (a, b) in enumerate(ranges(d), 1):
        print(strip(d, a, max(b, a + 0.5), d / f"strips/{i:02d}_{a:g}-{b:g}.jpg"))


CSS = """<style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=JetBrains+Mono:wght@500&display=swap');
body{margin:0;background:#f6f3ec;font-family:Inter,sans-serif;color:#1d1d1f}
.stage{padding:40px 48px;background-image:radial-gradient(#d9d3c4 1px,transparent 1px);background-size:18px 18px}
.lab{font:500 12px 'JetBrains Mono';letter-spacing:.12em;text-transform:uppercase;color:#2f6fed}
h1{font-weight:800;font-size:34px;margin:6px 0 4px}.meta{color:#555;margin:0 0 22px;font-size:14px}
table{border-collapse:collapse;background:#fff;width:100%;font-size:13px;box-shadow:0 1px 3px #0001}
th{font:500 11px 'JetBrains Mono';text-transform:uppercase;letter-spacing:.08em;text-align:left;background:#eef3ff;padding:10px;color:#2f6fed}
td{padding:10px;border-top:1px solid #eee;vertical-align:top}.n{font-weight:800;color:#2f6fed}.t,.sc{white-space:nowrap;color:#666}.s{font-weight:600}
.row{display:flex;gap:16px;align-items:flex-start}.grp{display:flex;flex-direction:column;gap:8px}
.band{font:500 11px 'JetBrains Mono';text-transform:uppercase;letter-spacing:.1em;background:#e8604c;color:#fff;border-radius:6px;padding:6px 10px}
.cards{display:flex;gap:16px}.card{width:210px;background:#fff;border-radius:10px;box-shadow:0 1px 3px #0002;overflow:hidden;font-size:12px}
.card img{width:210px;display:block}.hd{padding:8px 10px}.hd .n{margin-right:8px}.tm{color:#666;font-size:11px}.st{font-weight:600;margin-top:2px}
.bd{padding:8px 10px}.k{font:500 10px 'JetBrains Mono';text-transform:uppercase;color:#2f6fed;margin-top:4px}.k.a{color:#e8604c}.bd p{margin:2px 0 6px}
.foot{font:500 10px 'JetBrains Mono';letter-spacing:.1em;color:#888;margin-top:20px}</style>"""


def fit_miro(png, max_side=4000):
    """Miro rejects images over 32 MP; the renderer works at 2x. Cap the long side."""
    subprocess.run(["sips", "-Z", str(max_side), str(png)], capture_output=True)


def render(name):
    d = HERE / name; m = json.load(open(d / "clipmap.json")); e = html.escape
    clips = m["clips"]; scenes = any(c.get("scene") for c in clips); (d / "clips").mkdir(exist_ok=True)
    meta = f"<b>{e(m['link'])}</b> · {e(m['dur'])} · {len(clips)} clips · {e(m['tool'])}"
    head = lambda kind: f'<div class="lab">Teardown · {e(m["label"])}</div><h1>{e(m["title"])} · {kind}</h1><p class="meta">{meta}</p>'
    # clip map (text)
    tracks = any(c.get("track") for c in clips)
    th = ("<th>Track</th>" if tracks else "") + ("<th>Scene</th>" if scenes else "") + "<th>#</th><th>Time</th><th>Structure</th><th>Dialogue</th><th>Still</th><th>Action · movement + context</th>"
    rows = "".join(f'<tr>{"<td class=sc>"+e(c.get("track",""))+"</td>" if tracks else ""}{"<td class=sc>"+e(c.get("scene",""))+"</td>" if scenes else ""}<td class="n">{i}</td><td class="t">{e(c["time"])}</td>'
                   f'<td class="s">{e(c["structure"])}</td><td>{e(c["dialogue"])}</td><td>{e(c["still"])}</td><td>{e(c["action"])}{"<br><b>Layer:</b> "+e(c["layer"]) if c.get("layer") else ""}</td></tr>'
                   for i, c in enumerate(clips, 1))
    docs = {"clip-map": (1500, f'{head("clip map")}<table><thead><tr>{th}</tr></thead><tbody>{rows}</tbody></table>')}
    # storyboard (cards left to right, grouped under scene bands when set)
    def card(i, c):
        f = d / f"clips/clip_{i:02d}.jpg"
        run("ffmpeg", "-v", "error", "-y", "-ss", str(c["frame"]), "-i", str(d / "source/video.mp4"), "-frames:v", "1", "-vf", "scale=420:-1", str(f))
        src = "data:image/jpeg;base64," + base64.b64encode(f.read_bytes()).decode()
        return (f'<div class="card"><div class="hd"><span class="n">{i}</span><span class="tm">{e(c["time"])}s</span><div class="st">{e(c["structure"])}</div></div>'
                f'<img src="{src}"><div class="bd"><div class="k">Dialogue</div><p>{e(c["dialogue"])}</p><div class="k a">Action</div><p>{e(c["action"])}</p></div></div>')
    if not (d / "source/video.mp4").exists():  # original video (no reference footage): clip map only
        clips_done = True
    elif any(c.get("track") for c in clips):  # green screen: one row of cards per track (avatar on top, B-roll below)
        rows_html = []
        for tr in dict.fromkeys(c.get("track", "") for c in clips):
            cs = "".join(card(i, c) for i, c in enumerate(clips, 1) if c.get("track", "") == tr)
            rows_html.append(f'<div class="grp"><div class="band">{e(tr)}</div><div class="cards">{cs}</div></div>')
        W = max(1200, 96 + max(sum(1 for c in clips if c.get("track", "") == t) for t in {c.get("track", "") for c in clips}) * 226)
        docs["storyboard"] = (W, f'{head("storyboard")}<div class="grp" style="gap:22px">{"".join(rows_html)}</div><div class="foot">TOP ROW = AVATAR TRACK · BOTTOM ROW = B-ROLL TRACK · EDIT LAYERS THE AVATAR OVER THE B-ROLL</div>')
        clips_done = True
    else:
        clips_done = False
    groups = []
    for i, c in (() if clips_done else enumerate(clips, 1)):
        if groups and groups[-1][0] == c.get("scene"): groups[-1][1].append(card(i, c))
        else: groups.append((c.get("scene"), [card(i, c)]))
    body = "".join(f'<div class="grp">{"<div class=band>Scene "+e(s)+" · one generation</div>" if s else ""}<div class="cards">{"".join(cs)}</div></div>' for s, cs in groups)
    if not clips_done and groups:
      W = max(1200, 96 + len(clips) * 226 + len(groups) * 16)
      docs["storyboard"] = (W, f'{head("storyboard")}<div class="row">{body}</div><div class="foot">READS LEFT TO RIGHT · ONE CARD = ONE CLIP · FRAME = START OF THE CLIP</div>')
    OUT_PNG.mkdir(parents=True, exist_ok=True)
    for kind, (w, inner) in docs.items():
        p = d / f"{kind}.html"
        p.write_text(f'<!doctype html><html><head><meta charset="utf-8"><title>{e(m["title"])}</title>{CSS}<style>.stage{{width:{w}px}}</style></head><body><div class="stage">{inner}</div></body></html>')
        png = d / f"{kind}.png"
        run("python3", str(TO_PNG), str(p), "--full-page", "--size", f"{w + 96}x700", "--out", str(png))
        fit_miro(png); shutil.copy(png, OUT_PNG / f"{name}-{kind}.png")
        print(png)


def upload(name):
    d = HERE / name; r = json.load(open(d / "row.json"))
    if "folderId" not in r: sys.exit("No Drive folder for this video (it came from a link, not a DB row). PNGs stay local.")
    files = [{"path": f"breakdown/{k}.png", "mimeType": "image/png", "data": base64.b64encode((d / f"{k}.png").read_bytes()).decode()}
             for k in ("clip-map", "storyboard", "timeline-A", "timeline-B") if (d / f"{k}.png").exists()]
    ids = sheet()._call("upload", expect="ids", folderId=r["folderId"], files=files)["ids"]
    print(f"Uploaded to https://drive.google.com/drive/folders/{r['folderId']} -> breakdown/:", ids)


if __name__ == "__main__" and sys.argv[1] not in ("timeline", "greenscreen"):
    cmd, *a = sys.argv[1:]
    {"fetch-row": lambda: fetch_row(int(a[0]), " ".join(a[1:]) or None), "fetch-link": lambda: fetch_link(*a), "strips": lambda: strips(a[0]),
     "strip": lambda: print(strip(HERE / a[0], float(a[1]), float(a[2]), HERE / a[0] / f"strips/x_{a[1]}-{a[2]}.jpg")),
     "render": lambda: render(a[0]), "upload": lambda: upload(a[0])}[cmd]()



def secs(t):
    a, b = re.split(r"[–-]", t); return float(a), float(b)


def timeline(name, only=None):
    """Board-style green screen view, one PNG per avatar option. Same-size thumbnails like the Simple Media boards:
    avatar row on top (one thumbnail per generation + an arrow over the B-roll it covers), B-roll row below,
    CTA = avatar full frame as the last card. Input: <name>/timeline.json (see row15)."""
    d = HERE / name; m = json.load(open(d / "timeline.json")); e = html.escape
    v = d / "source/video.mp4"; (d / "clips").mkdir(exist_ok=True)
    TW, TH, G = 190, 338, 16
    def img(t, tag):
        if not v.exists():  # original video: blank placeholder until the stills are generated
            lab = "AVATAR" if tag == "avatar" else tag.upper().replace("B", "B", 1)
            svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="{TW*2}" height="{TH*2}"><rect width="100%" height="100%" fill="#e6e4dc"/>'
                   f'<rect x="6" y="6" width="{TW*2-12}" height="{TH*2-12}" fill="none" stroke="#a3a9b2" stroke-width="4" stroke-dasharray="14 10" rx="10"/>'
                   f'<text x="50%" y="48%" text-anchor="middle" font-family="monospace" font-size="40" fill="#6e7683">{lab}</text>'
                   f'<text x="50%" y="55%" text-anchor="middle" font-family="monospace" font-size="22" fill="#a3a9b2">image to generate</text></svg>')
            return "data:image/svg+xml;base64," + base64.b64encode(svg.encode()).decode()
        f = d / f"clips/tl_{tag}.jpg"
        run("ffmpeg", "-v", "error", "-y", "-ss", str(t), "-i", str(v), "-frames:v", "1", "-vf", f"scale={TW*2}:-1", str(f))
        return "data:image/jpeg;base64," + base64.b64encode(f.read_bytes()).decode()
    av = img(m["avatar_frame"], "avatar")
    cards = [(secs(b["time"]), img(b["frame"], f"b{i}"), f"B{i}") for i, b in enumerate(m["broll"], 1)]
    cards.append((secs(m["fullframe"]), av, "CTA"))
    info = m["broll"] + [dict(still="", action="", **m["cta"]) if "still" not in m["cta"] else m["cta"]]
    SW = 340  # script column on the left
    X = lambda k: SW + G * 2 + k * (TW + G)
    W = X(len(cards)) - G
    OUT_PNG.mkdir(parents=True, exist_ok=True)
    for key, o in m["options"].items():
        if only and key != only: continue
        gens = ""
        for gi, g in enumerate(o["avatar"], 1):
            a, z = secs(g["time"])
            span = [k for k, ((ca, cz), _, _) in enumerate(cards) if ca < z - 0.05 and cz > a + 0.05]
            x0, x1 = X(span[0]), X(span[-1]) + TW
            gens += (f'<div class="row"><div class="script"><div class="k">Script · gen {gi} · {g["words"]} words · {e(g["time"])}s</div>{e(g["dialogue"])}</div>'
                     f'<div class="av" style="left:{x0}px"><img src="{av}"><div class="cap">Gen {gi} · {e(o["tool"])}</div></div>'
                     f'<div class="arrow" style="left:{x0 + TW + 8}px;width:{x1 - x0 - TW - 8}px"></div>'
                     + '</div>')
        if m.get("compact"):  # all generations on one avatar row, script written along each arrow
            row = '<div class="script note"><div class="k">Avatar · ' + e(o["tool"]) + '</div>One generation per box. Script for each runs along its arrow.</div>'
            starts = []
            for g in o["avatar"]:
                a, z = secs(g["time"])
                span = [k for k, ((ca, cz), _, _) in enumerate(cards) if ca < z - 0.05 and cz > a + 0.05]
                starts.append((X(span[0]), X(span[-1]) + TW))
            for gi, g in enumerate(o["avatar"], 1):
                x0, x1 = starts[gi - 1]
                nxt = starts[gi][0] if gi < len(starts) else W + 300  # last one gets the extra space on the right
                wa = nxt - (x0 + TW) - 28
                row += (f'<div class="av" style="left:{x0}px"><img src="{av}"><div class="cap">Gen {gi} · {e(o["tool"])} · {g["words"]} words</div></div>'
                        + (f'<div class="arrow" style="left:{x0 + TW + 8}px;width:{x1 - x0 - TW - 8}px"></div>' if x1 - x0 > TW else '')
                        + f'<div class="desc" style="left:{x0 + TW + 14}px;width:{wa - 24}px;top:{TH//2 + 22}px"><div class="k">Gen {gi} · {e(g["time"])}s</div>{e(g["dialogue"])}</div>')
            gens = f'<div class="row">{row}</div>'
        bottom = "".join((f'<div class="c" style="left:{X(k)}px"><img src="{src}"><div class="cap">{lab} · {ca:g}–{cz:g}s</div>'
                          f'<div class="bt"><div class="k">Still</div>{e(info[k]["still"])}<div class="k a">Action</div>{e(info[k]["action"])}<div class="say">“{e(info[k]["dialogue"])}”</div></div></div>')
                         if lab != "CTA" else
                         (f'<div class="c" style="left:{X(k)}px"><div class="end">B-ROLL ENDS<br><br>Nothing to generate.<br>Avatar plays<br>without the key.</div><div class="cap">{ca:g}–{cz:g}s</div>'
                          f'<div class="bt"><div class="say">“{e(info[k]["dialogue"])}”</div></div></div>')
                         for k, ((ca, cz), src, lab) in enumerate(cards))
        bottom = f'<div class="script note"><div class="k">B-roll</div>One still per script beat, animated (image → video).</div>' + bottom
        css = f"""<style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@500;800&family=JetBrains+Mono:wght@500&display=swap');
body{{margin:0;background:#f2f1eb;font-family:Inter,sans-serif;color:#16191f}}
.stage{{width:{W}px;padding:48px 56px;background-image:radial-gradient(rgba(20,25,40,.08) 1.3px,transparent 1.3px);background-size:26px 26px}}
h1{{font-weight:800;font-size:28px;margin:0 0 4px}}.sub{{font-size:15px;color:#6e7683;margin:0 0 34px}}.sub b{{color:#16191f}}
.row{{position:relative;width:{W}px;height:{TH + 30}px}}.row+.row{{margin-top:26px}}
.c,.av{{position:absolute;top:0;width:{TW}px}}img{{width:{TW}px;height:{TH}px;object-fit:cover;border-radius:6px;display:block;box-shadow:0 1px 4px #0002}}
.av img{{outline:3px solid #7b6cf6;outline-offset:2px}}
.script{{position:absolute;left:0;top:0;width:{SW}px;height:{TH}px;box-sizing:border-box;background:#fff;border-radius:8px;box-shadow:0 1px 4px #0002;padding:14px 16px;font-size:14.5px;line-height:1.5;overflow:hidden}}
.script.note{{height:auto;background:transparent;box-shadow:none;padding:0 16px 0 0;color:#6e7683}}
.k{{font:500 11px 'JetBrains Mono';letter-spacing:.08em;text-transform:uppercase;color:#7b6cf6;margin-bottom:8px}}
.cap{{font:500 11px 'JetBrains Mono';color:#6e7683;margin-top:8px;white-space:nowrap}}
.arrow{{position:absolute;top:{TH//2}px;height:0;border-top:3px solid #7b6cf6}}
.arrow:after{{content:"";position:absolute;right:-2px;top:-9px;border-left:13px solid #7b6cf6;border-top:7.5px solid transparent;border-bottom:7.5px solid transparent}}
.end{{width:{TW}px;height:{TH}px;box-sizing:border-box;border:2px dashed #a3a9b2;border-radius:6px;display:flex;align-items:center;justify-content:center;text-align:center;font:500 11px 'JetBrains Mono';color:#6e7683;padding:10px}}
.avdesc{{background:#fff;border-left:4px solid #7b6cf6;border-radius:8px;padding:14px 18px;font-size:15px;line-height:1.55;max-width:1300px;margin:0 0 30px;box-shadow:0 1px 4px #0002}}.ac{{color:#e8604c}}
.desc{{position:absolute;top:18px;font-size:14px;line-height:1.45;background:#fff;border-radius:8px;padding:12px 14px;box-shadow:0 1px 4px #0002}}
.k.a{{color:#e8604c;margin-top:8px}}.bt{{font-size:12.5px;line-height:1.4;margin-top:8px}}.bt .k{{margin:6px 0 2px;font-size:10px}}.say{{margin-top:8px;color:#6e7683;font-style:italic}}
.edit{{margin-top:30px;background:#fff;border-left:4px solid #e8604c;border-radius:8px;padding:14px 18px;font-size:15px;line-height:1.5;max-width:1100px;box-shadow:0 1px 4px #0002}}
.edit .k{{color:#e8604c}}
.lab{{font:500 12px 'JetBrains Mono';letter-spacing:.12em;text-transform:uppercase;color:#7b6cf6;margin-bottom:6px}}</style>"""
        if m.get("compact"):
            css = css.replace(f"width:{W}px;padding", f"width:{W + 300}px;padding").replace(f".row{{{{position:relative;width:{W}px", f".row{{{{position:relative;width:{W + 300}px")
        inner = (f'<div class="lab">Green screen · option {key}</div><h1>{e(o["label"])}</h1><p class="sub">{o["legend"]}</p>'
                 f'<div class="avdesc"><div class="k">Avatar · {e(m["avatar"]["name"])} · described once, same image for every generation</div><b>Still:</b> {e(m["avatar"]["still"])}<br><b class="ac">Action:</b> {e(m["avatar"]["action"])}</div>'
                 f'{gens}<div class="row" style="height:{TH + 330}px">{bottom}</div>'
                 f'<div class="edit"><div class="k">{e(m.get("edit_label","Edit (CapCut)"))}</div>{m["edit_note"]}</div>')
        p = d / f"timeline-{key}.html"
        p.write_text(f'<!doctype html><html><head><meta charset="utf-8"><title>{e(m["title"])}</title>{css}</head><body><div class="stage">{inner}</div></body></html>')
        png = d / f"timeline-{key}.png"
        run("python3", str(TO_PNG), str(p), "--full-page", "--size", f"{W + 112 + (300 if m.get('compact') else 0)}x700", "--out", str(png))
        fit_miro(png); shutil.copy(png, OUT_PNG / f"{name}-timeline-{key}.png"); print(png)



def split_script(text, limit=30, min_last=10):
    """Option B split. Priority: fewest generations (each <= 30 words), then end on whole sentences
    (comma cuts only when unavoidable), then even sizes, and the last generation >= 10 words."""
    units = []  # (text, ends_a_sentence)
    for sen in re.split(r"(?<=[.!?])\s+", text.strip()):
        parts = re.split(r"(?<=,)\s+", sen)
        for k, part in enumerate(parts):
            units.append((part, k == len(parts) - 1))
    wc = lambda g: sum(len(u[0].split()) for u in g)
    best = None
    def pack(i, groups):
        nonlocal best
        if best and len(groups) > best[0][0]: return
        if i == len(units):
            sizes = [wc(g) for g in groups]
            commas = sum(not g[-1][1] for g in groups)
            score = (len(groups), commas, sizes[-1] < min_last and len(groups) > 1, max(sizes) - min(sizes))
            if best is None or score < best[0]: best = (score, [list(g) for g in groups])
            return
        if groups and wc(groups[-1]) + len(units[i][0].split()) <= limit:
            groups[-1].append(units[i]); pack(i + 1, groups); groups[-1].pop()
        groups.append([units[i]]); pack(i + 1, groups); groups.pop()
    pack(0, [])
    return [" ".join(u[0] for u in g) for g in best[1]]


def greenscreen(name, only=None):
    """clipmap.json (phase 1, with "cta": true on the unkeyed ending and "avatar": {name, still, action})
    -> timeline.json with option A (HeyGen, 1 gen) and B (Omni, ceil(words/30) gens) -> both PNGs."""
    d = HERE / name; cm = json.load(open(d / "clipmap.json"))
    clips = cm["clips"]; cta = [c for c in clips if c.get("cta")]; br = [c for c in clips if not c.get("cta")]
    dur = duration(d / "source/video.mp4")
    script = " ".join(c["dialogue"] for c in clips).replace("  ", " ")
    total = len(script.split())
    # word -> time: Whisper words if /breakdown made them, else spread evenly
    srt = d / "breakdown/audio.srt"
    stamps = []
    if srt.exists():
        for blk in srt.read_text().strip().split("\n\n"):
            ln = blk.split("\n"); a, b = [sum(float(x) * f for x, f in zip(t.replace(",", ".").split(":"), (3600, 60, 1))) for t in ln[1].split(" --> ")]
            ws = " ".join(ln[2:]).split()
            stamps += [a + (b - a) * k / len(ws) for k in range(len(ws))]
    t_of = lambda k: stamps[k] if k < len(stamps) else dur * k / total
    segs, k = [], 0
    for chunk in split_script(script):
        n = len(chunk.split()); a = 0 if k == 0 else round(t_of(k), 1); k += n
        segs.append(dict(dialogue=chunk, words=n, a=a))
    for i, sg in enumerate(segs):
        sg["time"] = f'{sg.pop("a"):g}–{(segs[i + 1]["a"] if i + 1 < len(segs) else round(dur, 1)):g}'
    fa = secs(cta[0]["time"])[0] if cta else round(dur, 1)
    t = dict(title=cm["title"], link=cm["link"], avatar_frame=cta[0]["frame"] if cta else clips[-1]["frame"],
             fullframe=f"{fa:g}–{dur:.1f}", avatar=cm["avatar"],
             broll=[dict(time=c["time"], still=c["still"], action=c["action"], dialogue=c["dialogue"], frame=c["frame"]) for c in br],
             cta=dict(dialogue=" ".join(c["dialogue"] for c in cta) or "(none)"),
             edit_note=f"1. Remove {cm['avatar']['name']}'s background (keying / background removal). 2. Place her in the <b>bottom-left corner</b> over B1–B{len(br)}. "
                       f"3. When the B-roll ends ({fa:g}–{dur:.0f}s), drop the key: she plays <b>full frame</b> with her own background for the CTA. Nothing new is generated for it. 4. Captions last.",
             options={"A": dict(label="Avatar animated once in HeyGen", tool="HeyGen",
                                legend=f"<b>{total} words → 1 HeyGen generation.</b> One avatar image + the full script, plays all the way through over the B-roll.",
                                avatar=[dict(time=f"0–{dur:.1f}", words=total, dialogue=script)]),
                      "B": dict(label="Avatar animated in Omni, one generation per ~30 words", tool="Omni",
                                legend=f"<b>{total} words ÷ 30 = {len(segs)} Omni generations</b> (round up: 60 → 2, 90 → 3, 150 → 5). Split at sentence breaks, stitched in CapCut, plays all the way through over the B-roll.",
                                avatar=segs)})
    json.dump(t, open(d / "timeline.json", "w"), indent=1)
    timeline(name, only)


if __name__ == "__main__" and sys.argv[1] == "timeline":
    timeline(sys.argv[2], {"heygen": "A", "omni": "B"}.get(sys.argv[3].lower()) if len(sys.argv) > 3 else None)
if __name__ == "__main__" and sys.argv[1] == "greenscreen":
    greenscreen(sys.argv[2], {"heygen": "A", "omni": "B"}.get(sys.argv[3].lower()) if len(sys.argv) > 3 else None)
