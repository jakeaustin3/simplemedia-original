#!/usr/bin/env python3
"""Local breakdown: cut detection + one frame per shot + transcript. Works on Mac and Windows.

  python3 breakdown.py <name>     run from the folder that holds <name>/source/video.mp4
"""
import re, shutil, subprocess, sys
from pathlib import Path

n = sys.argv[1]
d = Path(n).resolve()
bd = d / "breakdown"
shutil.rmtree(bd, ignore_errors=True)
(bd / "shots").mkdir(parents=True)
v = str(d / "source/video.mp4")


def ff(*a):
    subprocess.run(["ffmpeg", "-v", "error", *a], check=True, cwd=d)


dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", v],
                           capture_output=True, text=True, check=True).stdout.strip())
# 1) scene-change score for every frame
ff("-i", v, "-vf", "scale=320:-1,select='gte(scene,0)',metadata=print:file=breakdown/scores.txt", "-f", "null", "-")
# 2) pick cuts: score >= 0.18, at least 0.4s apart, keep the highest in a window
t = None; rows = []
for l in open(bd / "scores.txt"):
    m = re.search(r"pts_time:([0-9.]+)", l)
    if m: t = float(m.group(1)); continue
    m = re.search(r"scene_score=([0-9.]+)", l)
    if m and t is not None: rows.append((t, float(m.group(1))))
cands = [(t, s) for t, s in rows if s >= 0.18 and t > 0.3 and t < dur - 0.3]
cuts = []
for t, s in cands:
    if cuts and t - cuts[-1][0] < 0.4:
        if s > cuts[-1][1]: cuts[-1] = (t, s)
    else: cuts.append((t, s))
b = [0.0] + [t for t, _ in cuts] + [dur]
shots = [(i + 1, b[i], b[i + 1]) for i in range(len(b) - 1)]
(bd / "shots.txt").write_text("".join(f"{i:02d} {a:.2f} {e:.2f}\n" for i, a, e in shots))
(bd / "cuts_scores.txt").write_text("\n".join(f"{t:.2f} {s:.3f}" for t, s in cuts))
print(f"{len(shots)} shots; top scores:", sorted([round(s, 2) for _, s in rows], reverse=True)[:12])
# 3) one frame per shot, 0.15s after the cut
for i, a, e in shots:
    ff("-y", "-ss", f"{min(a + 0.15, (a + e) / 2):.2f}", "-i", v, "-frames:v", "1", "-vf", "scale=360:-1", f"breakdown/shots/shot_{i:02d}.jpg")
# 4) contact sheet (6 per row)
k = len(shots); r = (k + 5) // 6
ff("-y", "-start_number", "1", "-i", "breakdown/shots/shot_%02d.jpg", "-vf", f"tile=6x{r}:padding=4:margin=4:color=white",
   "-frames:v", "1", "breakdown/contact_sheet.jpg")
# 5) transcript
ff("-y", "-i", v, "-vn", "-ac", "1", "-ar", "16000", "breakdown/audio.wav")
subprocess.run(["whisper", "breakdown/audio.wav", "--model", "small", "--language", "en", "--output_dir", "breakdown",
                "--output_format", "all", "--fp16", "False", "--verbose", "False"],
               cwd=d, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
print(f"{n} done: {k} shots")
