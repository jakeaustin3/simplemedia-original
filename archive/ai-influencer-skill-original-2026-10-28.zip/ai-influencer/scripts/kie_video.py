#!/usr/bin/env python3
"""kie.ai Seedance 2.5 client — one job per call: upload inputs, create task,
poll, download, log.

Shared plumbing. No brand, no character, no prompt lives in this file — they
arrive on the command line at run time.

Modes (all the same API call, different inputs):

  Text only        --prompt "..."
  Ingredients      --prompt "Reference @Image1 for the character, @Image2 for
                   the setting. <action>." --image a.png --image b.png
  First frame      --first-frame f.png --prompt "..."
  Edit / reference --video talk.mp4 --image who.png --image where.png
                   --prompt "Reference @Video1 for camera, framing, motion,
                   timing and speech. Replace the person with @Image1 and the
                   background with @Image2. Keep everything else identical."
  Audio reference  --audio voice.mp3 (referred to as @Audio1)

Inputs are uploaded to kie's own file host (expire in 1-3 days, consumed
immediately). Outputs are downloaded at once because result URLs are on a
temp host. Every job appends a row to <out>/log.tsv — the durable record.

Defaults are the cheap ones: 480p, 9:16, 5 s, no generated audio.
No retry: a failed paid job is reported, never re-run automatically.

Usage:
  python3 kie_video.py --prompt "..." [--image X ...] [--video X ...]
      [--audio X ...] [--first-frame X] [--res 480p|720p|1080p]
      [--ar 9:16|16:9|4:3|1:1|3:4|21:9|adaptive] [--dur 5] [--audio-gen]
      [--out Videos/Seedance]
"""

import argparse
import csv
import os
import re
import sys
import time
from datetime import datetime
from pathlib import Path

import requests
from dotenv import load_dotenv

# Key comes from settings.txt in the kit folder (or the KIE_API_KEY environment variable). Never paste it here.
ROOT = Path.home() / "SimpleMedia"
load_dotenv(ROOT / "settings.txt")

API_KEY = os.getenv("KIE_API_KEY")
MODEL = "bytedance/seedance-2-5"
CREATE_URL = "https://api.kie.ai/api/v1/jobs/createTask"
STATUS_URL = "https://api.kie.ai/api/v1/jobs/recordInfo"
UPLOAD_URL = "https://kieai.redpandaai.co/api/file-stream-upload"
UPLOAD_URL_ALT = "https://api.kie.ai/api/file-stream-upload"
DEFAULT_OUT = ROOT / "Videos" / "Seedance"

# USD per output second, from the model page (2026-09). "with video" is priced
# on input + output seconds at the lower rate.
PRICE = {
    "480p": {"no_video": 0.140, "with_video": 0.085},
    "720p": {"no_video": 0.315, "with_video": 0.190},
    "1080p": {"no_video": 0.570, "with_video": 0.3425},
}

LOG_FIELDS = ["time", "task_id", "mode", "prompt", "inputs", "res", "ar",
              "dur", "credits", "output"]


def _headers():
    if not API_KEY:
        raise ValueError("KIE_API_KEY not found. Add KIE_API_KEY=... to settings.txt in the kit folder")
    return {"Authorization": f"Bearer {API_KEY}"}


def upload(path):
    """Upload one local file to kie's host. Returns its public URL."""
    p = Path(path).expanduser()
    if not p.is_file():
        raise FileNotFoundError(p)
    # Uploads are free and happen before any job exists, so a transient TLS
    # drop on kie's file host is safe to retry. Alternate hosts each attempt.
    hosts = [UPLOAD_URL, UPLOAD_URL_ALT]
    last = None
    for attempt in range(4):
        url = hosts[attempt % len(hosts)]
        try:
            with p.open("rb") as fh:
                r = requests.post(
                    url, headers=_headers(),
                    files={"file": (p.name, fh)},
                    data={"uploadPath": "seedance/inputs"},
                    timeout=300,
                )
            body = r.json()
            if r.status_code == 200 and body.get("success", body.get("code") == 200):
                return body["data"]["downloadUrl"]
            last = RuntimeError(f"upload failed for {p.name}: {r.text[:300]}")
        except (requests.exceptions.SSLError,
                requests.exceptions.ConnectionError, ValueError) as e:
            last = e
        print(f"  upload retry {attempt + 1} for {p.name}", flush=True)
        time.sleep(3)
    raise RuntimeError(f"upload gave up for {p.name}: {last}")


def create_task(prompt, images=(), videos=(), audios=(), first_frame=None,
                last_frame=None, resolution="480p", aspect_ratio="9:16",
                duration=5, generate_audio=False):
    """Create one generation task. Returns the task id."""
    inp = {
        "prompt": prompt,
        "resolution": resolution,
        "aspect_ratio": aspect_ratio,
        "duration": int(duration),
        "generate_audio": bool(generate_audio),
        "return_last_frame": False,
    }
    if images:
        inp["reference_image_urls"] = list(images)
    if videos:
        inp["reference_video_urls"] = list(videos)
    if audios:
        inp["reference_audio_urls"] = list(audios)
    if first_frame:
        inp["first_frame_url"] = first_frame
    if last_frame:
        inp["last_frame_url"] = last_frame
    r = requests.post(
        CREATE_URL, headers={**_headers(), "Content-Type": "application/json"},
        json={"model": MODEL, "input": inp}, timeout=60,
    )
    body = r.json()
    if body.get("code") != 200:
        raise RuntimeError(f"createTask {body.get('code')}: {body.get('msg')}")
    return body["data"]["taskId"]


def _field(text, name):
    """Pull a top-level string/number field out of the status body by regex.

    The status response embeds the request params with unescaped quotes,
    which breaks json.loads — so we never parse the whole body.
    """
    m = re.search(r'"%s":\s*"([^"]*)"' % name, text)
    if m:
        return m.group(1)
    m = re.search(r'"%s":\s*([0-9.]+|null)' % name, text)
    return m.group(1) if m else None


def poll(task_id, timeout=900, interval=10):
    """Wait for a task. Returns (result_url, credits). Raises on fail."""
    deadline = time.time() + timeout
    while True:
        r = requests.get(STATUS_URL, headers=_headers(),
                         params={"taskId": task_id}, timeout=60)
        text = r.text
        state = _field(text, "state")
        if state == "success":
            m = re.search(r'resultUrls\\":\[\\"([^\\"]+)', text)
            if not m:
                raise RuntimeError(f"success but no resultUrls: {text[:300]}")
            return m.group(1), _field(text, "creditsConsumed")
        if state == "fail":
            raise RuntimeError(
                f"task {task_id} failed: {_field(text, 'failMsg')}")
        if time.time() > deadline:
            raise TimeoutError(f"task {task_id} still '{state}' after {timeout}s")
        print(f"  {state} …", flush=True)
        time.sleep(interval)


def download(url, out_dir, stem=None):
    """Fetch the result video into out_dir. Returns the local path."""
    out_dir = Path(out_dir).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = stem or datetime.now().strftime("seedance_%Y%m%d_%H%M%S")
    ext = url.rsplit(".", 1)[-1].split("?")[0] or "mp4"
    dest = out_dir / f"{stem}.{ext}"
    with requests.get(url, stream=True, timeout=300) as r:
        r.raise_for_status()
        with dest.open("wb") as fh:
            for chunk in r.iter_content(1 << 16):
                fh.write(chunk)
    return dest


def log(out_dir, row):
    path = Path(out_dir).expanduser() / "log.tsv"
    new = not path.exists()
    with path.open("a", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=LOG_FIELDS, delimiter="\t")
        if new:
            w.writeheader()
        w.writerow(row)


def estimate(resolution, duration, video_paths):
    """Rough USD cost printed before submitting."""
    tier = PRICE[resolution]
    if video_paths:
        # input seconds unknown without probing; assume ≈ output length
        return tier["with_video"] * duration * 2
    return tier["no_video"] * duration


def run(prompt, images=(), videos=(), audios=(), first_frame=None,
        resolution="480p", aspect_ratio="9:16", duration=5,
        generate_audio=False, out_dir=DEFAULT_OUT):
    mode = ("edit" if videos else "first_frame" if first_frame
            else "ingredients" if images else "text")
    print(f"~${estimate(resolution, duration, videos):.2f}  "
          f"{mode} {resolution} {aspect_ratio} {duration}s")

    up = lambda paths: [upload(p) for p in paths]  # noqa: E731
    img_urls, vid_urls, aud_urls = up(images), up(videos), up(audios)
    ff_url = upload(first_frame) if first_frame else None
    n = len(img_urls) + len(vid_urls) + len(aud_urls) + (1 if ff_url else 0)
    if n:
        print(f"uploaded {n} input(s)")

    task_id = create_task(prompt, img_urls, vid_urls, aud_urls, ff_url,
                          resolution=resolution, aspect_ratio=aspect_ratio,
                          duration=duration, generate_audio=generate_audio)
    print(f"task {task_id}")
    url, credits = poll(task_id)
    dest = download(url, out_dir)
    log(out_dir, {
        "time": datetime.now().isoformat(timespec="seconds"),
        "task_id": task_id, "mode": mode, "prompt": prompt,
        "inputs": ";".join(Path(p).name for p in
                           [*images, *videos, *audios,
                            *([first_frame] if first_frame else [])]),
        "res": resolution, "ar": aspect_ratio, "dur": duration,
        "credits": credits, "output": str(dest),
    })
    print(f"{credits} credits → {dest}")
    return dest


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--prompt", required=True)
    ap.add_argument("--image", action="append", default=[],
                    help="reference image (@Image1, @Image2 … in order)")
    ap.add_argument("--video", action="append", default=[],
                    help="reference video (@Video1 …), ≤30 s total")
    ap.add_argument("--audio", action="append", default=[],
                    help="reference audio (@Audio1 …), ≤30 s total")
    ap.add_argument("--first-frame")
    ap.add_argument("--res", default="480p", choices=sorted(PRICE))
    ap.add_argument("--ar", default="9:16",
                    choices=["16:9", "4:3", "1:1", "3:4", "9:16", "21:9",
                             "adaptive"])
    ap.add_argument("--dur", type=int, default=5, help="seconds, 1-30")
    ap.add_argument("--audio-gen", action="store_true",
                    help="let the model generate a soundtrack")
    ap.add_argument("--out", default=str(DEFAULT_OUT))
    a = ap.parse_args()
    try:
        run(a.prompt, a.image, a.video, a.audio, a.first_frame,
            resolution=a.res, aspect_ratio=a.ar, duration=a.dur,
            generate_audio=a.audio_gen, out_dir=a.out)
    except Exception as e:  # report, never retry
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
