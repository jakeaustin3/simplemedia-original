#!/usr/bin/env python3
"""Small helpers for character kits.
  kit_tools.py sheet <folder> <out.jpg> [cols]   contact sheet of every jpg/png in a folder, labelled with file names
  kit_tools.py fetch <url> <dest>                 download one generation result
"""
import sys, os, glob, urllib.request
from PIL import Image, ImageDraw

def sheet(folder, out, cols=4, w=360):
    fs = sorted(glob.glob(os.path.join(folder, '*.jpg')) + glob.glob(os.path.join(folder, '*.png')))
    if not fs: print('no images in', folder); return
    ims = [Image.open(f).convert('RGB') for f in fs]
    th = [im.resize((w, int(im.height * w / im.width))) for im in ims]
    h = max(t.height for t in th) + 28
    rows = (len(th) + cols - 1) // cols
    S = Image.new('RGB', (cols * w, rows * h), 'white'); d = ImageDraw.Draw(S)
    for i, (t, f) in enumerate(zip(th, fs)):
        x, y = (i % cols) * w, (i // cols) * h
        S.paste(t, (x, y)); d.text((x + 6, y + t.height + 6), os.path.basename(f), fill='black')
    S.save(out, quality=85); print(out, S.size, len(fs))

def fetch(url, dest):
    os.makedirs(os.path.dirname(dest) or '.', exist_ok=True)
    urllib.request.urlretrieve(url, dest); print('ok', dest, os.path.getsize(dest))

if __name__ == '__main__':
    a = sys.argv[1:]
    if a and a[0] == 'sheet': sheet(a[1], a[2], int(a[3]) if len(a) > 3 else 4)
    elif a and a[0] == 'fetch': fetch(a[1], a[2])
    else: print(__doc__)
