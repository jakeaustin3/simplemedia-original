"""Generate the green screen stills on kie.ai (nano-banana-pro) from prompts.md.
  python3 kie_images.py CHARACTER 1 8 10 11        # PREVIEW only: what would be sent, no credits
  python3 kie_images.py CHARACTER 1 8 10 11 --go   # actually generate (18 kie credits each)
  python3 kie_images.py 2 3 4 --res 1K --go         # budget route: B-roll stills at 1K (CHARACTER stays 2K)
Safety (2026-09-30, after a parse miss sent the wrong prompt): strict per-label parsing, prompt checks,
and nothing is spent without --go.
Run from <video folder>/make/:  KIT=<character> ENV=<environment file> python3 <kit>/tools/kie_images.py ...
Refs: CHARACTER = close-up lock + full-body lock + the ENV environment image; full refs with a hand = full body lock;
'chains off image k' = images/IMAGE_k output."""
import re, sys, json, concurrent.futures as cf
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))  # kie_video.py sits next to this file
import os
import requests, kie_video as kie

HERE = Path.cwd();  # run from inside <video folder>/make/ OUT = HERE / "images"; OUT.mkdir(exist_ok=True)
# Character kit: set KIT=<name> (a folder in Kits/Characters/) or a full path before running.
KIT = Path(os.environ.get("KIT", "")).expanduser()
if not KIT.is_absolute(): KIT = Path.home() / "SimpleMedia/Kits/Characters" / str(os.environ.get("KIT", ""))
if not os.environ.get("KIT") or not KIT.exists(): raise SystemExit("Set KIT=<character name> first, e.g.  KIT=maria python3 tools/kie_images.py ...")
MODEL = "nano-banana-pro"

def blocks():
    """Strict: each label must be followed (blank lines allowed) by its reference line and then its own code block."""
    lines = (HERE / "prompts.md").read_text().split("\n"); out = {}
    for i, ln in enumerate(lines):
        m = re.match(r"^(CHARACTER|IMAGE (\d+)) · ", ln)
        if not m: continue
        j = i + 1
        while j < len(lines) and not lines[j].strip(): j += 1
        ref = lines[j].strip(); j += 1
        while j < len(lines) and not lines[j].strip(): j += 1
        if not lines[j].startswith("```"): raise SystemExit(f"STOP: no prompt block right under '{ln}'")
        k = j + 1
        while not lines[k].startswith("```"): k += 1
        key = "CHARACTER" if m.group(1) == "CHARACTER" else m.group(2)
        out[key] = dict(ref=ref, prompt="\n".join(lines[j + 1:k]).strip(), label=ln)
    return out

def check(key, b):
    p = b["prompt"]; bad = []
    if "Natural movement, no music" in p or "as she says" in p: bad.append("this is an animation/voice prompt, not an image prompt")
    if key == "CHARACTER" and not p.startswith("Use the character"): bad.append("CHARACTER prompt must start 'Use the character'")
    if "chains off" in b["label"] and not p.startswith("Same exact image"): bad.append("chained prompt must start 'Same exact image'")
    if "chains off" not in b["label"] and p.startswith("Same exact image"): bad.append("full-refs prompt looks like a delta")
    if bad: raise SystemExit(f"STOP {b['label']}: " + "; ".join(bad))

_up = {}
def up(p):
    if p not in _up: _up[p] = kie.upload(p)
    return _up[p]

def refs(key, b):
    r = b["ref"]
    if key == "CHARACTER":
        return [KIT / "locks/02_front_close_up.jpg", KIT / "locks/01_front_full_body.jpg", *([KIT / "environments" / os.environ["ENV"]] if os.environ.get("ENV") else [])]  # ENV=<file in environments/>, optional
    m = re.search(r"image (\d+)", r)
    if m: return [OUT / f"IMAGE_{int(m.group(1)):02d}.png"]
    if "hand" in r: return [KIT / "locks/01_front_full_body.jpg"]
    return []

RES = sys.argv[sys.argv.index("--res") + 1] if "--res" in sys.argv else "2K"

def run(key, b):
    imgs = [up(str(p)) for p in refs(key, b)]
    body = {"model": MODEL, "input": {"prompt": b["prompt"], "image_input": imgs, "aspect_ratio": "9:16",
                                      "resolution": "2K" if key == "CHARACTER" else RES, "output_format": "png"}}
    r = requests.post(kie.CREATE_URL, headers={**kie._headers(), "Content-Type": "application/json"}, json=body, timeout=60).json()
    if r.get("code") != 200: raise RuntimeError(f"{key}: {r}")
    url, credits = kie.poll(r["data"]["taskId"], timeout=600, interval=8)
    stem = "CHARACTER" if key == "CHARACTER" else f"IMAGE_{int(key):02d}"
    dest = kie.download(url, OUT, stem)
    print(f"✓ {stem} -> {dest.name} ({credits} credits)", flush=True)
    return dest

if __name__ == "__main__":
    go = "--go" in sys.argv
    args = [a for i, a in enumerate(sys.argv[1:], 1) if a not in ("--go", "--res") and sys.argv[i - 1] != "--res"]
    B = blocks(); want = [a.upper() if a.lower() == "character" else a for a in args]
    n_images = len([k for k in B if k != "CHARACTER"])
    print(f"Read {len(B)} prompts from prompts.md (CHARACTER + {n_images} images).")
    for k in want:
        if k not in B: raise SystemExit(f"STOP: no prompt for {k}")
        check(k, B[k])
        print(f"  {B[k]['label']}\n    refs: {[p.name for p in refs(k, B[k])] or 'none'}\n    prompt: {B[k]['prompt'][:90]}…")
    print(f"Total: {len(want)} images at {RES} (CHARACTER always 2K). Pro at 2K = 18 kie credits each; the 1K price prints per image as it finishes.")
    if not go:
        raise SystemExit("PREVIEW only, nothing spent. Re-run with --go to generate.")
    with cf.ThreadPoolExecutor(6) as ex:
        list(ex.map(lambda k: run(k, B[k]), want))
