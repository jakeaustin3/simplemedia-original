#!/usr/bin/env python3
"""board.py <video folder> [plan file] — render a numbered copy-paste storyboard page from board-plan.json.

Used by green screen (avatar + B-roll) and overlay/podcast (what pops up over the talking video).
One row per moment, top to bottom, every prompt with a Copy button. Publish the HTML with the Artifact tool.

Plan shape (board-plan.json):
{"title": "Yogurt bites · Consuelo", "label": "green screen · Omni avatar · by hand in Flow",
 "steps": ["Make the character image first", "Then the avatar clips", "Then each B-roll image and its clip"],
 "top": [  # optional blocks above the rows (the character image, the avatar)
   {"title": "Character image", "refs": ["01 face lock", "02 body lock"], "prompts": [{"label": "Image prompt", "text": "..."}]}],
 "rows": [
   {"n": 1, "time": "0:00–0:04", "said": "If you mix yogurt...", "see": "Hand spooning yogurt into a bowl",
    "kind": "B-roll · animated", "refs": ["character image"], "pick": true,
    "prompts": [{"label": "Image prompt", "text": "..."}, {"label": "Animation prompt", "text": "..."}],
    "note": "optional"}]}
"pick": true adds a tick box so the student can choose which rows to make (overlay maps).
Writes <folder>/<plan name>.html."""
import sys, json, html, pathlib

d = pathlib.Path(sys.argv[1])
plan_path = d / (sys.argv[2] if len(sys.argv) > 2 else "board-plan.json")
P = json.loads(plan_path.read_text())
E = lambda s: html.escape(str(s))
pid = iter(range(100000))


def prompt(p):
    i = f"p{next(pid)}"
    return (f'<div class="prompt"><div class="ph"><span>{E(p["label"])}</span>'
            f'<button class="copy" data-t="{i}">Copy</button></div><pre id="{i}">{E(p["text"])}</pre></div>')


def refs(r):
    if not r:
        return ""
    return '<div class="refs"><span class="s">Attach, in this order:</span>' + "".join(
        f'<span class="ref">{k}. {E(x)}</span>' for k, x in enumerate(r, 1)) + "</div>"


def note(x):
    return f'<p class="note">{E(x["note"])}</p>' if x.get("note") else ""


top = "".join(
    f'<section class="blk"><h2>{E(b["title"])}</h2>{refs(b.get("refs"))}'
    f'{"".join(prompt(p) for p in b.get("prompts", []))}'
    f'{note(b)}</section>'
    for b in P.get("top", []))

rows = ""
for r in P["rows"]:
    pick = f'<label class="pick"><input type="checkbox" checked> make</label>' if r.get("pick") else ""
    rows += (f'<article class="row"><div class="num">{E(r["n"])}</div><div class="body">'
             f'<div class="meta"><span class="time">{E(r.get("time", ""))}</span>'
             f'<span class="kind">{E(r.get("kind", ""))}</span>{pick}</div>'
             f'<p class="said">“{E(r.get("said", ""))}”</p>'
             f'<p class="see"><b>On screen:</b> {E(r.get("see", ""))}</p>'
             f'{refs(r.get("refs"))}{"".join(prompt(p) for p in r.get("prompts", []))}'
             f'{note(r)}'
             f'</div></article>')

steps = "".join(f"<li>{E(s)}</li>" for s in P.get("steps", []))
page = f'''<title>{E(P["title"])}</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=JetBrains+Mono:wght@500&display=swap">
<style>
/* layout: numbered rows top to bottom; each row = time, what's said, what's on screen, references, prompts */
:root{{--bg:#f6f3ec;--dot:#ddd6c7;--card:#fff;--fg:#1d1d1f;--mute:#6b665c;--line:#e4ded1;--blue:#2f6fed;--green:#1f9d57;--greenw:#e1f3e9;--coral:#d9583c;--disp:"Inter",system-ui,sans-serif;--mono:"JetBrains Mono",ui-monospace,monospace}}
@media (prefers-color-scheme:dark){{:root:not([data-theme="light"]){{--bg:#17171a;--dot:#2b2b30;--card:#212125;--fg:#f1efe9;--mute:#a19c92;--line:#34343a;--blue:#6d9bff;--green:#4cc985;--greenw:#18301f;--coral:#f08d76;color-scheme:dark}}}}
:root[data-theme="dark"]{{--bg:#17171a;--dot:#2b2b30;--card:#212125;--fg:#f1efe9;--mute:#a19c92;--line:#34343a;--blue:#6d9bff;--green:#4cc985;--greenw:#18301f;--coral:#f08d76;color-scheme:dark}}
body{{background:var(--bg);background-image:radial-gradient(var(--dot) 1px,transparent 1px);background-size:22px 22px;color:var(--fg);font-family:var(--disp);margin:0}}
main{{max-width:880px;margin:0 auto;padding:24px 16px 48px;display:flex;flex-direction:column;gap:14px}}
h1{{font-weight:800;font-size:28px;margin:0;text-wrap:balance}} h2{{font-size:17px;margin:0 0 8px}}
.lbl,.s,.ph span,.time,.kind{{font-family:var(--mono);font-size:11px;letter-spacing:.05em;text-transform:uppercase;color:var(--mute)}}
ol.steps{{margin:0;padding-left:20px;font-size:14px;line-height:1.6}}
.blk,.row{{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px}}
.row{{display:grid;grid-template-columns:44px minmax(0,1fr);gap:12px}}
.num{{width:36px;height:36px;border-radius:50%;background:var(--blue);color:#fff;font-weight:800;display:flex;align-items:center;justify-content:center}}
.body{{display:flex;flex-direction:column;gap:8px;min-width:0}}
.meta{{display:flex;gap:12px;align-items:center;flex-wrap:wrap}} .kind{{color:var(--green)}}
.said{{margin:0;font-size:15px;font-weight:600;line-height:1.45}} .see{{margin:0;font-size:14px;line-height:1.45}}
.refs{{display:flex;gap:6px;flex-wrap:wrap;align-items:center}} .ref{{font-size:12px;background:var(--greenw);color:var(--green);border-radius:6px;padding:2px 8px}}
.prompt{{border:1px solid var(--line);border-radius:10px;overflow:hidden;margin-top:6px}}
.ph{{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:6px 10px;border-bottom:1px solid var(--line)}}
pre{{margin:0;padding:10px;white-space:pre-wrap;font:13px/1.5 var(--disp)}}
.copy{{font:600 12px var(--disp);background:var(--blue);color:#fff;border:0;border-radius:7px;padding:5px 12px;cursor:pointer}} .copy.ok{{background:var(--coral)}}
.copy:focus-visible{{outline:2px solid var(--coral);outline-offset:2px}}
.pick{{font-size:12px;display:flex;gap:4px;align-items:center;margin-left:auto}} .note{{margin:0;font-size:12.5px;color:var(--coral);font-weight:600}}
</style>
<main><div><div class="lbl">{E(P.get("label", ""))}</div><h1>{E(P["title"])}</h1></div>
{f'<section class="blk"><h2>How to use this page</h2><ol class="steps">{steps}</ol></section>' if steps else ""}
{top}{rows}</main>
<script>document.querySelectorAll('.copy').forEach(b=>b.addEventListener('click',()=>{{const p=document.getElementById(b.dataset.t);
navigator.clipboard.writeText(p.textContent).then(()=>{{b.textContent='Copied';b.classList.add('ok');setTimeout(()=>{{b.textContent='Copy';b.classList.remove('ok')}},1400)}}).catch(()=>{{const r=document.createRange();r.selectNodeContents(p);getSelection().removeAllRanges();getSelection().addRange(r)}})}}));</script>'''
out = plan_path.with_suffix(".html")
out.write_text(page)
print(out)
