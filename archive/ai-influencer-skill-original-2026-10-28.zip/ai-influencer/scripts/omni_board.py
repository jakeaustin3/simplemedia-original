#!/usr/bin/env python3
"""omni_board.py <teardown folder> — render omni-plan.json into the copy-paste Omni storyboard artifact HTML.
Plan shape:
{"title":"Botox Hack -> Sasha + Mom","label":"Videos row 2 · product authority · Google Flow · Sasha in black seamless set",
 "character":"sasha","lock":"locks/02_front_close_up.jpg",
 "images":[{"n":1,"kind":"anchor|chain","title":"Hook","sub":"injects the mask","box":["lock","img:1"],"prompt":"...",
            "note":"optional coral note","clips":[{"n":1,"secs":8,"words":18,"hook":true,"prompt":"..."}]}]}
Writes <folder>/omni-storyboard.html. Publish it with the Artifact tool."""
import sys,json,base64,html,os,subprocess,tempfile
d=sys.argv[1].rstrip("/"); P=json.load(open(f"{d}/omni-plan.json"))
kit=os.path.join(os.path.expanduser("~/SimpleMedia"),"Kits","Characters",P['character'])
lockp=os.path.join(kit,P.get("lock","locks/02_front_close_up.jpg"))
t=tempfile.mktemp(suffix=".jpg"); subprocess.run(["sips","-Z","120",lockp,"--out",t],capture_output=True)
L=base64.b64encode(open(t,"rb").read()).decode()
E=lambda s:html.escape(s)
def ref(r):
    if r=="lock": return f'<span class="r"><img src="data:image/jpeg;base64,{L}" alt="">{E(P["character"].title())} face lock</span>'
    if r.startswith("cast:"): return f'<span class="r"><i class="mini">CAST</i>{E(r[5:])}</span>'
    if r=="env": return f'<span class="r"><i class="mini">ENV</i>{E(P.get("env_label","location reference"))}</span>'
    n=r.split(":")[1]; return f'<span class="r"><i class="mini">IMG {n}</i>your image {n}</span>'
def pr(pid,label,text,cls=""):
    return f'<div class="prompt {cls}"><div class="ph"><span>{E(label)}</span><button class="copy" data-t="{pid}">Copy</button></div><pre id="{pid}">{E(text)}</pre></div>'
cols=""
for im in P["images"]:
    n=im["n"]; k="a" if im["kind"]=="anchor" else "d"
    cl="".join(f'<div class="cl"><div class="card v">clip {c["n"]}<small>{c["secs"]}s</small></div>{pr("c%s"%c["n"],"Omni clip %s · %s words · %ss · start frame image %s"%(c["n"],c.get("words","?"),c["secs"],n),c["prompt"],"g")}</div>' for c in im["clips"])
    note=f'<div class="note">{E(im["note"])}</div>' if im.get("note") else ""
    cols+=f'<div class="col"><div class="head"><span class="tag {k}">IMAGE {n}</span><b>{E(im["title"])}</b><span class="s">{E(im.get("sub",""))}</span></div><div class="box"><span class="s">Reference box:</span>{"".join(ref(r) for r in im["box"])}</div><div class="cl"><div class="card">image {n}<small>9:16</small></div>{pr("i%s"%n,"Image prompt · Nano Banana Pro",im["prompt"])}</div><div class="arrow">↓ animate in Omni</div>{note}{cl}</div>'
page=f'''<title>{E(P["title"])}</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=JetBrains+Mono:wght@500&display=swap">
<style>
/* layout: horizontal strip, one column per image (image + prompt on top, its Omni clips below) */
:root{{--bg:#f6f3ec;--dot:#ddd6c7;--card:#fff;--fg:#1d1d1f;--mute:#6b665c;--line:#e4ded1;--blue:#2f6fed;--green:#1f9d57;--coral:#d9583c;--disp:"Inter",system-ui,sans-serif;--mono:"JetBrains Mono",ui-monospace,monospace}}
@media (prefers-color-scheme:dark){{:root:not([data-theme="light"]){{--bg:#17171a;--dot:#2b2b30;--card:#212125;--fg:#f1efe9;--mute:#a19c92;--line:#34343a;--blue:#6d9bff;--green:#4cc985;--coral:#f08d76;color-scheme:dark}}}}
:root[data-theme="dark"]{{--bg:#17171a;--dot:#2b2b30;--card:#212125;--fg:#f1efe9;--mute:#a19c92;--line:#34343a;--blue:#6d9bff;--green:#4cc985;--coral:#f08d76;color-scheme:dark}}
body{{background:var(--bg);background-image:radial-gradient(var(--dot) 1px,transparent 1px);background-size:22px 22px;color:var(--fg);font-family:var(--disp)}}
main{{padding-inline:16px;padding-block:24px 40px;display:flex;flex-direction:column;gap:14px}}
h1{{font-weight:800;font-size:28px;margin:0;text-wrap:balance}} .lbl,.s,.arrow,.legend,.ph span{{font-family:var(--mono);font-size:11px;letter-spacing:.05em;text-transform:uppercase;color:var(--mute)}}
.scroll{{overflow-x:auto;padding-bottom:10px}} .strip{{display:flex;gap:14px;align-items:flex-start;width:max-content}}
.col{{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px;width:430px;max-width:calc(100vw - 32px);display:flex;flex-direction:column;gap:10px}}
.head{{display:flex;gap:8px;align-items:baseline;flex-wrap:wrap}} .head b{{font-size:17px}}
.tag{{font-family:var(--mono);font-size:12px;color:#fff;border-radius:6px;padding:2px 7px}} .tag.a{{background:var(--blue)}} .tag.d{{background:var(--mute)}}
.box{{display:flex;gap:10px;align-items:center;flex-wrap:wrap;font-size:12px}} .r{{display:flex;gap:6px;align-items:center}}
.r img,.mini{{width:26px;height:34px;object-fit:cover;border-radius:4px;border:1px solid var(--line)}} .mini{{display:inline-flex;align-items:center;justify-content:center;font:500 7px var(--mono);font-style:normal;border-style:dashed;color:var(--mute)}}
.cl{{display:grid;grid-template-columns:96px minmax(0,1fr);gap:10px;align-items:start}}
.card{{aspect-ratio:9/16;width:96px;border:2px dashed var(--line);border-radius:8px;display:flex;flex-direction:column;align-items:center;justify-content:center;color:var(--mute);font-weight:600;font-size:12px}} .card small{{font:500 10px var(--mono)}} .card.v{{border-color:var(--green)}}
.prompt{{min-width:0;border:1px solid var(--line);border-radius:10px;overflow:hidden}} .prompt.g{{border-color:color-mix(in srgb,var(--green) 40%,var(--line))}}
.ph{{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:6px 10px;border-bottom:1px solid var(--line)}}
pre{{margin:0;padding:10px;white-space:pre-wrap;font:12.5px/1.5 var(--disp)}}
.copy{{font:600 12px var(--disp);background:var(--blue);color:#fff;border:0;border-radius:7px;padding:5px 12px;cursor:pointer}} .prompt.g .copy{{background:var(--green)}} .copy.ok{{background:var(--coral)!important}}
.copy:focus-visible{{outline:2px solid var(--coral);outline-offset:2px}} .legend{{display:flex;gap:16px;flex-wrap:wrap}} .note{{font-size:12px;color:var(--coral);font-weight:600}}
</style>
<main><div><div class="lbl">{E(P["label"])}</div><h1>{E(P["title"])}</h1></div>
<div class="legend"><span><b style="color:var(--blue)">■</b> anchor</span><span><b style="color:var(--mute)">■</b> chained</span><span><b style="color:var(--green)">■</b> Omni clip · image = start frame</span><span>scroll right → · edit left to right, hard cuts</span></div>
<div class="scroll"><div class="strip">{cols}</div></div></main>
<script>document.querySelectorAll('.copy').forEach(b=>b.addEventListener('click',()=>{{const p=document.getElementById(b.dataset.t);
navigator.clipboard.writeText(p.textContent).then(()=>{{b.textContent='Copied';b.classList.add('ok');setTimeout(()=>{{b.textContent='Copy';b.classList.remove('ok')}},1400)}}).catch(()=>{{const r=document.createRange();r.selectNodeContents(p);getSelection().removeAllRanges();getSelection().addRange(r)}})}}));</script>'''
open(f"{d}/omni-storyboard.html","w").write(page); print(f"{d}/omni-storyboard.html")
