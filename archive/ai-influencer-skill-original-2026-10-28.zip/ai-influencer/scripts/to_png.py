#!/usr/bin/env python3
"""Render an artifact / HTML page to PNG (or PDF) with headless Chrome.

  to_png.py page.html                       # one-screen board → page.png (size read from the stage's aspect-ratio)
  to_png.py deck.html --slides 15,24        # deck → deck-slide15.png, deck-slide24.png
  to_png.py deck.html --slides all          # every slide
  to_png.py guide.html --full-page          # scrolling page → one tall PNG
  to_png.py page.html --pdf                 # also write a PDF (one page per board/slide)
  to_png.py page.html --size 9:16 --out ~/Desktop/thumb.png

Decks work when the page exposes window.goSlide(label), or a global `S` array with `.n` labels plus go(index)
(the Simple Media Live Deck), or plain `.slide` elements toggled with class `on`.
"""
import argparse, html as html_lib, json, re, subprocess, sys, time, uuid
from pathlib import Path

def find_chrome():
    """Google Chrome (or Edge on Windows) wherever it is installed: Mac, Windows or Linux."""
    import os, shutil
    pf = [os.environ.get(k) for k in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA")]
    spots = ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
             str(Path.home() / "Applications/Google Chrome.app/Contents/MacOS/Google Chrome")]
    spots += [str(Path(p) / "Google/Chrome/Application/chrome.exe") for p in pf if p]
    spots += [str(Path(p) / "Microsoft/Edge/Application/msedge.exe") for p in pf if p]
    for s in spots:
        if Path(s).exists(): return s
    for name in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "chrome", "msedge"):
        if shutil.which(name): return shutil.which(name)
    return spots[0]


CHROME = find_chrome()
BASE_W = 1600
TIMEOUT = 150  # seconds per Chrome run; big decks (10 MB) take a while, a hung run gets killed

SIZES = {"16:9": (16, 9), "9:16": (9, 16), "5:3": (5, 3), "4:5": (4, 5), "1:1": (1, 1), "letter": (8.5, 11), "8.5x11": (8.5, 11)}

PROBE_JS = """<script>(function(){function p(){try{var labels=[];
if(typeof S!=='undefined'&&Array.isArray(S)){labels=S.map(function(s,i){return String(s.n!=null?s.n:i+1)})}
else if(window.slideLabels){labels=window.slideLabels()}
else{document.querySelectorAll('.slide').forEach(function(e,i){labels.push(String(i+1))})}
document.documentElement.setAttribute('data-probe',JSON.stringify({h:document.documentElement.scrollHeight,slides:labels}))}catch(e){
document.documentElement.setAttribute('data-probe',JSON.stringify({h:document.documentElement.scrollHeight,slides:[],err:String(e)}))}}
addEventListener('load',function(){setTimeout(p,300)})})();</script>"""

GOTO_JS = """<script>(function(){var want=decodeURIComponent(location.hash.slice(1));if(!want)return;
function run(){try{if(window.goSlide){goSlide(want);return}
if(typeof S!=='undefined'&&typeof go==='function'){var k=S.findIndex(function(s){return String(s.n)===want});
if(k<0&&/^\\d+$/.test(want))k=parseInt(want,10)-1;go(k);return}}catch(e){}
var sl=document.querySelectorAll('.slide'),i=parseInt(want,10)-1;
sl.forEach(function(e,j){e.classList.toggle('on',j===i);e.hidden=j!==i})}
run();addEventListener('load',run)})();</script>"""


def chrome(args, expect=None, timeout=TIMEOUT):
    """Run headless Chrome. Don't pass --user-data-dir: with a temp profile Chrome writes the file but never exits.
    When `expect` (an output path) is given, stop Chrome as soon as that file exists and has stopped growing."""
    cmd = [CHROME, "--headless=new", "--disable-gpu", "--hide-scrollbars"] + args
    if expect is None:
        try:
            return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            print(f"  ! Chrome timed out after {timeout}s", file=sys.stderr)
            return None
    expect = Path(expect)
    expect.unlink(missing_ok=True)
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    start, last = time.time(), -1
    while time.time() - start < timeout:
        if proc.poll() is not None:
            return expect.exists()
        if expect.exists():
            size = expect.stat().st_size
            if size > 0 and size == last:
                proc.terminate()
                return True
            last = size
        time.sleep(0.5)
    proc.kill()
    print(f"  ! Chrome timed out after {timeout}s", file=sys.stderr)
    return expect.exists()


def detect_ratio(html):
    m = re.search(r"\.stage\s*\{[^}]*?aspect-ratio\s*:\s*([\d.]+)\s*/\s*([\d.]+)", html, re.S)
    return (float(m.group(1)), float(m.group(2))) if m else None


def parse_size(spec, html):
    if spec in (None, "auto"):
        r = detect_ratio(html) or (16, 9)
    elif spec in SIZES:
        r = SIZES[spec]
    elif re.fullmatch(r"\d+x\d+", spec):
        w, h = map(int, spec.split("x"))
        return w, h
    else:
        sys.exit(f"Unknown --size {spec!r}. Use auto, 16:9, 9:16, 1:1, letter, or WxH.")
    w, h = r
    # long side = BASE_W: 16:9 → 1600×900, 9:16 → 900×1600, letter → 1236×1600
    return (BASE_W, round(BASE_W * h / w)) if w >= h else (round(BASE_W * w / h), BASE_W)


def inject(html, snippet):
    i = html.lower().rfind("</body>")
    return html[:i] + snippet + html[i:] if i >= 0 else html + snippet


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("html")
    ap.add_argument("--slides", help="comma list of slide labels/numbers, or 'all'")
    ap.add_argument("--full-page", action="store_true", help="capture the whole scrolling page")
    ap.add_argument("--size", default="auto")
    ap.add_argument("--scale", type=float, default=2)
    ap.add_argument("--pdf", action="store_true")
    ap.add_argument("--out", help="output file (single image) or folder")
    a = ap.parse_args()

    src = Path(a.html).expanduser().resolve()
    if not src.exists():
        sys.exit(f"Not found: {src}")
    if not Path(CHROME).exists():
        sys.exit("Google Chrome not found. Install it from google.com/chrome and try again.")
    html = src.read_text(errors="ignore")
    w, h = parse_size(a.size, html)

    out = Path(a.out).expanduser() if a.out else None
    outdir = out if (out and (out.is_dir() or not out.suffix)) else (out.parent if out else src.parent)
    outdir.mkdir(parents=True, exist_ok=True)

    # temp copy next to the source so relative files (multi-file artifacts) still resolve
    tmp = src.parent / f".create-png-{uuid.uuid4().hex[:8]}.html"
    made = []
    try:
        slides = []
        if a.slides and a.slides != "all":
            slides = [s.strip() for s in a.slides.split(",") if s.strip()]
            print(f"slides: {', '.join(slides)}")
        if a.slides == "all" or a.full_page:
            tmp.write_text(inject(html, PROBE_JS))
            r = chrome(["--virtual-time-budget=8000", "--dump-dom", tmp.as_uri()])
            probe = {}
            if r and (m := re.search(r"data-probe=\"([^\"]*)\"", r.stdout)):
                probe = json.loads(html_lib.unescape(m.group(1)))
            if a.slides == "all":
                slides = probe.get("slides", [])
                if not slides:
                    sys.exit("Couldn't find slides on this page.")
                print(f"slides: {', '.join(slides)}")
            if a.full_page:
                h = min(max(int(probe.get("h") or h), h), 16000)

        tmp.write_text(inject(html, GOTO_JS) if slides else html)
        stem = out.stem if (out and out.suffix) else src.stem
        targets = [(f"{stem}-slide{s}", f"#{s}") for s in slides] or [(stem, "")]
        for name, frag in targets:
            png = (out if (out and out.suffix and len(targets) == 1) else outdir / f"{name}.png")
            ok = chrome([f"--force-device-scale-factor={a.scale}", f"--window-size={w},{h}", "--virtual-time-budget=8000",
                         f"--screenshot={png}", tmp.as_uri() + frag], expect=png)
            if ok:
                made.append(png); print(f"  ✓ {png}  ({round(w * a.scale)}×{round(h * a.scale)})")
            else:
                print(f"  ✗ {name} failed", file=sys.stderr)
            if a.pdf:
                pdf = png.with_suffix(".pdf")
                page = f"<style>@page{{size:{w}px {h}px;margin:0}}html,body{{-webkit-print-color-adjust:exact;print-color-adjust:exact}}</style>"
                tmp.write_text(inject(inject(html, GOTO_JS) if slides else html, page))
                if chrome(["--no-pdf-header-footer", "--virtual-time-budget=8000", f"--window-size={w},{h}",
                           f"--print-to-pdf={pdf}", tmp.as_uri() + frag], expect=pdf):
                    made.append(pdf); print(f"  ✓ {pdf}")
                tmp.write_text(inject(html, GOTO_JS) if slides else html)
    finally:
        tmp.unlink(missing_ok=True)
    if not made:
        sys.exit(1)


if __name__ == "__main__":
    main()
