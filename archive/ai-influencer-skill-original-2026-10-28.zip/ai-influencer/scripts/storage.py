#!/usr/bin/env python3
"""Where every video is saved. One folder per video: Videos/<Character>/<YYYY-MM>/<Video topic>/

  python3 storage.py setup [--mode drive|computer|both] [--local ~/Videos]  first run (default: drive)
  python3 storage.py status                                                  show the settings
  python3 storage.py folder <Character> "<Video topic>"                      make/find the video's folder, print its path
  python3 storage.py save <video folder>                                     copy that folder to Google Drive (mode drive/both)
  python3 storage.py deliver <file>                                          copy a finished file the student wants into ~/Downloads

Settings live in ~/.simple-media/storage.json. On a computer, the video folder is the ONLY copy:
every skill writes straight into it (never a second copy elsewhere on the same machine).
Mode "drive" (default): Drive is the organized home. Work happens in a hidden working folder
(~/.simple-media/work/...), cleared after a successful save. Finished files the student wants
(e.g. a Seedance video) go straight to ~/Downloads, no folder structure on the computer.
Modes "computer"/"both" keep the Videos/ structure on the computer too (offer it, never push it).
"""
import sys, json, base64, datetime, mimetypes, pathlib, argparse

CFG = pathlib.Path.home() / ".simple-media/storage.json"
HERE = pathlib.Path(__file__).parent
MAX_MB = 35  # Apps Script request limit is ~50 MB after base64


def load():
    if not CFG.exists():
        sys.exit("Storage isn't set up yet. Run the onboarding: python3 storage.py setup --mode both")
    return json.loads(CFG.read_text())


def sheet():
    sys.path.insert(0, str(HERE))
    from sheet import Sheet
    p = pathlib.Path.home() / "SimpleMedia" / "settings.txt"
    url = next((l.split("=", 1)[1].strip() for l in (open(p) if p.exists() else []) if l.startswith("SHEET_SCRIPT_URL=")), "")
    if not url:
        raise SystemExit("Your Video Database sheet is not connected yet (no SHEET_SCRIPT_URL in settings.txt). "
                         "Ask Claude to 'connect my sheet' first.")
    return Sheet(url)


def clean(name):
    return "".join(c for c in name.strip() if c not in '/\\:*?"<>|').strip() or "Untitled"


def setup(mode, local):
    if mode == "drive": local = "~/.simple-media/work"
    root = pathlib.Path(local).expanduser()
    root.mkdir(parents=True, exist_ok=True)
    cfg = {"mode": mode, "local": str(root)}
    if mode in ("drive", "both"):
        r = sheet()._call("videos", expect="folderId")
        cfg.update(driveFolderId=r["folderId"], driveUrl=r.get("url", f"https://drive.google.com/drive/folders/{r['folderId']}"))
    CFG.parent.mkdir(parents=True, exist_ok=True)
    CFG.write_text(json.dumps(cfg, indent=2))
    print(json.dumps(cfg, indent=2))


def folder(character, topic):
    cfg = load()
    month = datetime.date.today().strftime("%Y-%m")
    d = pathlib.Path(cfg["local"]) / clean(character.title()) / month / clean(topic)
    for sub in ("images", "clips"):
        (d / sub).mkdir(parents=True, exist_ok=True)
    meta = d / "video.json"
    if not meta.exists():
        meta.write_text(json.dumps({"character": character.title(), "topic": topic, "month": month,
                                    "started": datetime.datetime.now().isoformat(timespec="minutes")}, indent=2))
    print(d)


def save(path):
    cfg = load(); d = pathlib.Path(path).expanduser().resolve()
    if cfg["mode"] == "computer":
        print(f"Saved on this computer only: {d}"); return
    rel = d.relative_to(pathlib.Path(cfg["local"]).resolve())  # Character/YYYY-MM/Topic
    s = sheet(); n = 0; skipped = []
    for f in sorted(p for p in d.rglob("*") if p.is_file() and not p.name.startswith(".")):
        if f.stat().st_size > MAX_MB * 2**20:
            skipped.append(f.name); continue
        mime = mimetypes.guess_type(f.name)[0] or "application/octet-stream"
        s._call("upload", expect="ids", folderId=cfg["driveFolderId"],
                files=[{"path": f"{rel.as_posix()}/{f.relative_to(d).as_posix()}", "mimeType": mime,
                        "data": base64.b64encode(f.read_bytes()).decode()}])
        n += 1
    print(f"Saved {n} files to Drive: {cfg['driveUrl']} → {rel.as_posix()}")
    if cfg["mode"] == "drive" and not skipped:
        import shutil; shutil.rmtree(d); print("Cleared the working copy on this computer (Drive has it).")
    if skipped: print(f"Too big to send through the script (>{MAX_MB} MB), upload by hand: {', '.join(skipped)}")


def deliver(path):
    import shutil; src = pathlib.Path(path).expanduser(); dst = pathlib.Path.home() / "Downloads" / src.name
    shutil.copy2(src, dst); print(dst)


def estimate(videos):
    mb = 80  # ~ original 10 + images 7 + clips 30 + final 30 + notes
    print(f"About {mb} MB per video → {videos} videos ≈ {videos*mb/1024:.1f} GB. Google gives 15 GB free.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("setup"); a.add_argument("--mode", choices=["drive", "computer", "both"], default="drive"); a.add_argument("--local", default="~/Videos")
    sub.add_parser("status")
    a = sub.add_parser("folder"); a.add_argument("character"); a.add_argument("topic")
    a = sub.add_parser("save"); a.add_argument("path")
    a = sub.add_parser("deliver"); a.add_argument("path")
    a = sub.add_parser("estimate"); a.add_argument("videos", type=int, nargs="?", default=150)
    x = ap.parse_args()
    if x.cmd == "setup": setup(x.mode, x.local)
    elif x.cmd == "status": print(json.dumps(load(), indent=2))
    elif x.cmd == "folder": folder(x.character, x.topic)
    elif x.cmd == "save": save(x.path)
    elif x.cmd == "deliver": deliver(x.path)
    else: estimate(x.videos)
