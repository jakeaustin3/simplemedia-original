"""/stitch: put Omni (or any ~10s) clips in script order, trim dead air, join.

python3 stitch.py <clips folder or files...> --script script.txt --out out.mp4 [--speed 1.0] [--pad 0.3]
- Transcribes every clip (whisper base.en, cached next to the clip as .json).
- Orders clips by where their first words appear in the script (fuzzy); no script = filename order.
- Trims each clip `pad` s after its last word. If a clip repeats its final phrase
  ("right now, right now") it cuts after the first one.
- Joins (re-encode, 30fps), optional speed-up with pitch kept, levels voice to -16 LUFS.
Prints the order table so it can be shown to the student.
"""
import sys, os, json, glob, subprocess, argparse, difflib, re

ap = argparse.ArgumentParser()
ap.add_argument("inputs", nargs="+"); ap.add_argument("--script"); ap.add_argument("--out", required=True)
ap.add_argument("--speed", type=float, default=1.0); ap.add_argument("--pad", type=float, default=0.3)
a = ap.parse_args()

files = []
for p in a.inputs:
    files += sorted(glob.glob(os.path.join(p, "*.mp4")) + glob.glob(os.path.join(p, "*.mov"))) if os.path.isdir(p) else [p]
norm = lambda s: re.sub(r"[^a-z0-9 ]", "", s.lower())

def words(f):
    j = os.path.splitext(f)[0] + ".json"
    if not os.path.exists(j):
        subprocess.run(["whisper", f, "--model", "base.en", "--output_format", "json", "--word_timestamps", "True",
                        "--fp16", "False", "--output_dir", os.path.dirname(f) or "."], capture_output=True)
    d = json.load(open(j))
    return [w for s in d["segments"] for w in s.get("words", [])]

clips = []
for f in files:
    w = words(f)
    if not w: print("! no speech:", f); continue
    toks = [norm(x["word"]).strip() for x in w]
    end = w[-1]["end"]
    for n in (4, 3, 2):  # repeated tail phrase → cut after first copy
        if len(toks) >= 2 * n and toks[-n:] == toks[-2 * n:-n]:
            end = w[-n - 1]["end"]; break
    clips.append({"f": f, "text": " ".join(x["word"].strip() for x in w), "end": end + a.pad})

if a.script:
    sc = norm(open(a.script).read())
    def pos(c):
        head = norm(c["text"])[:60]
        m = difflib.SequenceMatcher(None, sc, head, autojunk=False).find_longest_match(0, len(sc), 0, len(head))
        return m.a
    clips.sort(key=pos)

print("| # | clip | starts with | trimmed to |")
print("|---|---|---|---|")
for i, c in enumerate(clips):
    print(f"| {i+1} | {os.path.basename(c['f'])} | {c['text'][:50]}… | {c['end']:.2f}s |")

ins, fl = [], []
for i, c in enumerate(clips):
    ins += ["-i", c["f"]]
    fl.append(f"[{i}:v]trim=0:{c['end']:.2f},setpts=PTS-STARTPTS,fps=30[v{i}];[{i}:a]atrim=0:{c['end']:.2f},asetpts=PTS-STARTPTS[a{i}]")
n = len(clips)
fl.append("".join(f"[v{i}][a{i}]" for i in range(n)) + f"concat=n={n}:v=1:a=1[vc][ac]")
fl.append(f"[vc]setpts=PTS/{a.speed}[v]" if a.speed != 1 else "[vc]null[v]")
fl.append(f"[ac]atempo={a.speed},loudnorm=I=-16:TP=-1.5[a]" if a.speed != 1 else "[ac]loudnorm=I=-16:TP=-1.5[a]")
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", *ins, "-filter_complex", ";".join(fl), "-map", "[v]", "-map", "[a]",
                "-r", "30", "-c:v", "libx264", "-crf", "18", "-c:a", "aac", "-ar", "48000", a.out], check=True)
d = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", a.out], capture_output=True, text=True).stdout.strip()
print(f"\n→ {a.out} ({float(d):.1f}s, {a.speed}x)")
