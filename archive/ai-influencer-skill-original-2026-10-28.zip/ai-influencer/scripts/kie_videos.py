"""Generate the green screen clips on kie.ai from prompts.md (run inside <folder>/make/).
  python3 kie_videos.py VO1 CLIP1          # PREVIEW only: jobs, start frames, prompts, credits. Nothing spent.
  python3 kie_videos.py VO1 CLIP1 --go     # generate
VO n   = avatar clip: Gemini Omni 1.1 Flash (Google Omni, as in Flow), start frame = images/CHARACTER.png, 10s, 9:16, 720p, voice from the prompt.
CLIP n = B-roll: Veo 3.1 Fast, start frame = images/IMAGE_nn.png, 8s, 9:16, 720p, 60 credits (sound always on at kie: mute it in the edit).
"""
import re, sys, concurrent.futures as cf
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))  # kie_video.py sits next to this file
import requests, kie_video as kie

HERE = Path.cwd(); IMG = HERE / "images"; OUT = HERE / "clips"; OUT.mkdir(exist_ok=True)
PRICE = {"VO": None, "CLIP": 60}  # Gemini Omni price unknown until the first run reports creditsConsumed


def jobs():
    lines = (HERE / "prompts.md").read_text().split("\n"); out = {}
    for i, ln in enumerate(lines):
        m = re.match(r"^(VO|CLIP) (\d+) · ", ln)
        if not m: continue
        j = i + 1
        while not lines[j].startswith("```"):
            if re.match(r"^(VO|CLIP|IMAGE|CHARACTER|#)", lines[j]): raise SystemExit(f"STOP: no prompt block right under '{ln}'")
            j += 1
        k = j + 1
        while not lines[k].startswith("```"): k += 1
        key = f"{m.group(1)}{int(m.group(2))}"
        frame = IMG / "CHARACTER.png" if m.group(1) == "VO" else IMG / f"IMAGE_{int(m.group(2)):02d}.png"
        out[key] = dict(label=ln, prompt="\n".join(lines[j + 1:k]).strip(), frame=frame, kind=m.group(1))
    return out


def check(key, j):
    p = j["prompt"]; bad = []
    if not j["frame"].exists(): bad.append(f"start frame {j['frame'].name} missing (approve/generate stills first)")
    if j["kind"] == "VO" and "as she says" not in p: bad.append("VO prompt has no dialogue ('as she says')")
    if j["kind"] == "CLIP" and ("as she says" in p or "Natural movement, no music" not in p): bad.append("B-roll prompt must be the 2-line motion prompt, no dialogue")
    if p.startswith(("Use the character", "Same exact image")): bad.append("this is an IMAGE prompt, not a video prompt")
    if bad: raise SystemExit(f"STOP {j['label']}: " + "; ".join(bad))


def body(j, url):
    if j["kind"] == "VO":
        return {"model": "google/gemini-omni-flash-1-1", "input": {"prompt": j["prompt"], "first_frame_url": url,
                "duration": "10", "aspect_ratio": "9:16", "resolution": "720p"}}
    return {"model": "veo3_fast", "input": {"prompt": j["prompt"], "image_urls": [url], "generation_type": "FIRST_AND_LAST_FRAMES_2_VIDEO",
            "aspect_ratio": "9:16", "resolution": "720p", "duration": 8}}


def run(key, j):
    if (OUT / f"{key}.mp4").exists():
        print(f"= {key} already done, skipped (no credits)", flush=True); return
    try:
        _run(key, j)
    except Exception as e:  # one failure never stops the batch
        print(f"✗ {key} FAILED: {e}  (kie does not charge failed tasks; re-run just this one)", flush=True)


def _run(key, j):
    url = kie.upload(str(j["frame"]))
    r = requests.post(kie.CREATE_URL, headers={**kie._headers(), "Content-Type": "application/json"}, json=body(j, url), timeout=60).json()
    if r.get("code") != 200: raise RuntimeError(f"{key}: {r}")
    with open(OUT / "tasks.log", "a") as f: f.write(f"{key}\t{r['data']['taskId']}\n")
    res, credits = kie.poll(r["data"]["taskId"], timeout=1800, interval=15)
    dest = kie.download(res, OUT, key)
    print(f"✓ {key} -> {dest.name} ({credits} credits)", flush=True)


if __name__ == "__main__":
    go = "--go" in sys.argv
    J = jobs(); want = [a.upper() for a in sys.argv[1:] if a != "--go"]
    print(f"Read {sum(1 for k in J if k.startswith('VO'))} VO + {sum(1 for k in J if k.startswith('CLIP'))} CLIP prompts.")
    est, unknown = 0, 0
    for k in want:
        if k not in J: raise SystemExit(f"STOP: no prompt for {k}")
        check(k, J[k]); p = PRICE[J[k]["kind"]]
        est += p or 0; unknown += p is None
        print(f"  {J[k]['label']}\n    start frame: {J[k]['frame'].name}\n    prompt: {J[k]['prompt'][:100]}…")
    print(f"Total: {est} credits" + (f" + {unknown} Gemini Omni clip(s) at an unknown price" if unknown else "") + ".")
    if not go: raise SystemExit("PREVIEW only, nothing spent. Re-run with --go to generate.")
    with cf.ThreadPoolExecutor(6) as ex:
        list(ex.map(lambda k: run(k, J[k]), want))
